﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grpBox1 = New System.Windows.Forms.GroupBox()
        Me.txtBox6 = New System.Windows.Forms.TextBox()
        Me.txtBox5 = New System.Windows.Forms.TextBox()
        Me.txtBox4 = New System.Windows.Forms.TextBox()
        Me.txtBox3 = New System.Windows.Forms.TextBox()
        Me.txtBox2 = New System.Windows.Forms.TextBox()
        Me.txtBox1 = New System.Windows.Forms.TextBox()
        Me.txtBox0 = New System.Windows.Forms.TextBox()
        Me.btnVerify = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.grpBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpBox1
        '
        Me.grpBox1.Controls.Add(Me.txtBox6)
        Me.grpBox1.Controls.Add(Me.txtBox5)
        Me.grpBox1.Controls.Add(Me.txtBox4)
        Me.grpBox1.Controls.Add(Me.txtBox3)
        Me.grpBox1.Controls.Add(Me.txtBox2)
        Me.grpBox1.Controls.Add(Me.txtBox1)
        Me.grpBox1.Controls.Add(Me.txtBox0)
        Me.grpBox1.Location = New System.Drawing.Point(12, 12)
        Me.grpBox1.Name = "grpBox1"
        Me.grpBox1.Size = New System.Drawing.Size(268, 50)
        Me.grpBox1.TabIndex = 0
        Me.grpBox1.TabStop = False
        Me.grpBox1.Text = "Enter the PIN"
        '
        'txtBox6
        '
        Me.txtBox6.Location = New System.Drawing.Point(228, 19)
        Me.txtBox6.Name = "txtBox6"
        Me.txtBox6.Size = New System.Drawing.Size(31, 20)
        Me.txtBox6.TabIndex = 6
        Me.txtBox6.Text = "0"
        '
        'txtBox5
        '
        Me.txtBox5.Location = New System.Drawing.Point(191, 19)
        Me.txtBox5.Name = "txtBox5"
        Me.txtBox5.Size = New System.Drawing.Size(31, 20)
        Me.txtBox5.TabIndex = 5
        Me.txtBox5.Text = "0"
        '
        'txtBox4
        '
        Me.txtBox4.Location = New System.Drawing.Point(154, 19)
        Me.txtBox4.Name = "txtBox4"
        Me.txtBox4.Size = New System.Drawing.Size(31, 20)
        Me.txtBox4.TabIndex = 4
        Me.txtBox4.Text = "0"
        '
        'txtBox3
        '
        Me.txtBox3.Location = New System.Drawing.Point(117, 19)
        Me.txtBox3.Name = "txtBox3"
        Me.txtBox3.Size = New System.Drawing.Size(31, 20)
        Me.txtBox3.TabIndex = 3
        Me.txtBox3.Text = "0"
        '
        'txtBox2
        '
        Me.txtBox2.Location = New System.Drawing.Point(80, 19)
        Me.txtBox2.Name = "txtBox2"
        Me.txtBox2.Size = New System.Drawing.Size(31, 20)
        Me.txtBox2.TabIndex = 2
        Me.txtBox2.Text = "0"
        '
        'txtBox1
        '
        Me.txtBox1.Location = New System.Drawing.Point(43, 19)
        Me.txtBox1.Name = "txtBox1"
        Me.txtBox1.Size = New System.Drawing.Size(31, 20)
        Me.txtBox1.TabIndex = 1
        Me.txtBox1.Text = "0"
        '
        'txtBox0
        '
        Me.txtBox0.Location = New System.Drawing.Point(6, 19)
        Me.txtBox0.Name = "txtBox0"
        Me.txtBox0.Size = New System.Drawing.Size(31, 20)
        Me.txtBox0.TabIndex = 0
        Me.txtBox0.Text = "0"
        '
        'btnVerify
        '
        Me.btnVerify.Location = New System.Drawing.Point(18, 68)
        Me.btnVerify.Name = "btnVerify"
        Me.btnVerify.Size = New System.Drawing.Size(80, 48)
        Me.btnVerify.TabIndex = 7
        Me.btnVerify.Text = "Verify"
        Me.btnVerify.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(104, 68)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(83, 48)
        Me.btnClear.TabIndex = 8
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(193, 68)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(78, 48)
        Me.btnExit.TabIndex = 9
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(291, 125)
        Me.Controls.Add(Me.btnVerify)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.grpBox1)
        Me.Name = "frmMain"
        Me.Text = "Form1"
        Me.grpBox1.ResumeLayout(False)
        Me.grpBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents grpBox1 As GroupBox
    Friend WithEvents txtBox6 As TextBox
    Friend WithEvents txtBox5 As TextBox
    Friend WithEvents txtBox4 As TextBox
    Friend WithEvents txtBox3 As TextBox
    Friend WithEvents txtBox2 As TextBox
    Friend WithEvents txtBox1 As TextBox
    Friend WithEvents txtBox0 As TextBox
    Friend WithEvents btnVerify As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
End Class
