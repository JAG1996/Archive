﻿Public Class frmMain
    Dim intMinimum() As Integer = {7, 5, 0, 0, 6, 3, 4}
    Dim intMaximum() As Integer = {9, 7, 4, 9, 9, 6, 8}
    Dim intCounter As Integer

    Private Sub btnVerify_Click(sender As Object, e As EventArgs) Handles btnVerify.Click
        intCounter = 0

        If txtBox0.Text >= intMinimum(0) Then
            If txtBox0.Text <= intMaximum(0) Then
                intCounter += 1
            End If
        End If

        If txtBox1.Text >= intMinimum(1) Then
            If txtBox1.Text <= intMaximum(1) Then
                intCounter += 1
            End If
        End If

        If txtBox2.Text >= intMinimum(2) Then
            If txtBox2.Text <= intMaximum(2) Then
                intCounter += 1
            End If
        End If

        If txtBox3.Text >= intMinimum(3) Then
            If txtBox3.Text <= intMaximum(3) Then
                intCounter += 1
            End If
        End If

        If txtBox4.Text >= intMinimum(4) Then
            If txtBox4.Text <= intMaximum(4) Then
                intCounter += 1
            End If
        End If

        If txtBox5.Text >= intMinimum(5) Then
            If txtBox5.Text <= intMaximum(5) Then
                intCounter += 1
            End If
        End If

        If txtBox6.Text >= intMinimum(6) Then
            If txtBox6.Text <= intMaximum(6) Then
                intCounter += 1
            End If
        End If

        If intCounter = 7 Then
            MessageBox.Show("This is an acceptable PIN.")
        Else
            MessageBox.Show("This is NOT an acceptable PIN.")
        End If
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtBox0.Text = 0
        txtBox1.Text = 0
        txtBox2.Text = 0
        txtBox3.Text = 0
        txtBox4.Text = 0
        txtBox5.Text = 0
        txtBox6.Text = 0
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
