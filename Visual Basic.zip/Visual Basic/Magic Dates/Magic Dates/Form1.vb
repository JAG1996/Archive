﻿Public Class Form1

    Dim intMonth As Integer
    Dim intDay As Integer
    Dim intYear As Integer

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        lblResult.Text = ""
        intMonth = Integer.Parse(txtBoxMonth.Text)
        intDay = Integer.Parse(txtBoxDay.Text)
        intYear = Integer.Parse(txtBoxYear.Text)

        If (intMonth * intDay) = intYear Then
            lblResult.Text = "This is a magic date."
        Else
            lblResult.Text = "This is not a magic date."
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        txtBoxMonth.Text = ""
        txtBoxDay.Text = ""
        txtBoxYear.Text = ""
        lblResult.Text = ""
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub
End Class
