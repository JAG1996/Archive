﻿Public Class Form1
    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click

        'Collects data and performs calculation
        Dim intSpeed As Integer = InputBox("Enter the Vehicle's Speed:", "Vehicle Speed", "25")
        Dim intTime As Integer = InputBox("Enter the Time Traveled:", "Distance Traveled", "1")
        Dim intDistance As Integer = (intSpeed * intTime)

        'Resets the ListBox 
        '(In case of multiple calculations during one program execution)
        Dim intCount As Integer = 1
        lstBox.Items.Clear()

        'Sets the Display
        lstBox.Items.Insert(0, "Vehicle Speed: " & intSpeed & " MPH")
        lstBox.Items.Insert(1, "Time Traveled: " & intTime & " hours")
        lstBox.Items.Insert(2, "Hours       Distance Traveled")
        lstBox.Items.Insert(3, "-----------------------------------------------")

        'Makes the calculations visible
        Do While intCount <= intTime
            intDistance = (intCount * intSpeed)
            lstBox.Items.Add(intCount & "            " & intDistance)
            intCount = (intCount + 1)
        Loop
        lstBox.Items.Insert((intCount + 3), "Total Distance: " & intDistance)
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
