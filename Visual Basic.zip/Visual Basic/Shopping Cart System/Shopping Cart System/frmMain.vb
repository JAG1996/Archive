﻿Public Class frmMain
    Dim dblSubtotal As Double = 0.0
    Dim dblTax As Double = 0.0
    Dim dblShipping As Double = 0.0
    Dim dblTotal As Double = 0.0
    Dim dblBook As Double = 0.0

    Private Sub ResetToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ResetToolStripMenuItem.Click
        lstBoxMain.Items.Clear()
        dblSubtotal = 0.0
        dblTax = 0.0
        dblShipping = 0.0
        dblTotal = 0.0
        Calculate()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub PrintBooksToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PrintBooksToolStripMenuItem.Click
        frmPrintBooks.Show()
    End Sub

    Private Sub AudioBooksToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AudioBooksToolStripMenuItem.Click
        frmAudioBooks.Show()
    End Sub

    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        MessageBox.Show("This program is a preview of how one would shop online!")
    End Sub

    Private Sub btnRemove_Click(sender As Object, e As EventArgs) Handles btnRemove.Click
        Decide(lstBoxMain.SelectedItem)
        If dblBook > 0 Then
            lstBoxMain.Items.Remove(lstBoxMain.SelectedItem)
            RemoveBook(lstBoxMain.SelectedItem)
        End If
    End Sub

    Public Sub Calculate()
        lblSubtotalDisplay.Text = (dblSubtotal.ToString("C"))
        lblTaxDisplay.Text = (dblTax.ToString("C"))
        lblShippingDisplay.Text = (dblShipping.ToString("C"))
        lblTotalDisplay.Text = (dblTotal.ToString("C"))
    End Sub

    Public Sub AddBook(ByVal strBook As String)
        Decide(strBook)
        dblSubtotal += dblBook
        dblTax = (dblSubtotal * 0.06)
        dblShipping += 2.0
        dblTotal = (dblSubtotal + dblTax + dblShipping)
        Calculate()
    End Sub

    Public Sub RemoveBook(ByVal strBook As String)
        dblSubtotal -= dblBook
        dblTax = (dblSubtotal * 0.06)
        dblShipping -= 2.0
        dblTotal = (dblSubtotal + dblTax + dblShipping)
        If dblShipping <= 0.0 Then
            dblSubtotal = 0.0
            dblTax = 0.0
            dblShipping = 0.0
            dblTotal = 0.0
        End If
        Calculate()
    End Sub

    Public Sub Decide(ByVal strChoice As String)
        If strChoice = "I Did It Your Way (Print)" Then
            dblBook = 11.95
        ElseIf strChoice = "The History of Scotland (Print)" Then
            dblBook = 14.5
        ElseIf strChoice = "Learn Calculus in One Day (Print)" Then
            dblBook = 29.95
        ElseIf strChoice = "Feel the Stress (Print)" Then
            dblBook = 18.5
        ElseIf strChoice = "Learn Calculus in One Day (Audio)" Then
            dblBook = 29.95
        ElseIf strChoice = "The History of Scotland (Audio)" Then
            dblBook = 14.5
        ElseIf strChoice = "The Science of Body Language (Audio)" Then
            dblBook = 12.95
        ElseIf strChoice = "Relaxtion Techniques (Audio)" Then
            dblBook = 11.5
        Else
            dblBook = 0.0
        End If
    End Sub
End Class
