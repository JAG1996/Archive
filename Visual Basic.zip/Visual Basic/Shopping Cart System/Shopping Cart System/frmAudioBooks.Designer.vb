﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAudioBooks
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.btnAddBook = New System.Windows.Forms.Button()
        Me.grpBoxAudio = New System.Windows.Forms.GroupBox()
        Me.lstBoxAudio = New System.Windows.Forms.ListBox()
        Me.grpBoxAudio.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnClose
        '
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.Location = New System.Drawing.Point(237, 193)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(107, 57)
        Me.btnClose.TabIndex = 6
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'btnAddBook
        '
        Me.btnAddBook.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddBook.Location = New System.Drawing.Point(56, 193)
        Me.btnAddBook.Name = "btnAddBook"
        Me.btnAddBook.Size = New System.Drawing.Size(139, 57)
        Me.btnAddBook.TabIndex = 5
        Me.btnAddBook.Text = "Add Book to Cart"
        Me.btnAddBook.UseVisualStyleBackColor = True
        '
        'grpBoxAudio
        '
        Me.grpBoxAudio.Controls.Add(Me.lstBoxAudio)
        Me.grpBoxAudio.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpBoxAudio.Location = New System.Drawing.Point(12, 12)
        Me.grpBoxAudio.Name = "grpBoxAudio"
        Me.grpBoxAudio.Size = New System.Drawing.Size(394, 148)
        Me.grpBoxAudio.TabIndex = 4
        Me.grpBoxAudio.TabStop = False
        Me.grpBoxAudio.Text = "Select an Audio Book"
        '
        'lstBoxAudio
        '
        Me.lstBoxAudio.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstBoxAudio.FormattingEnabled = True
        Me.lstBoxAudio.ItemHeight = 16
        Me.lstBoxAudio.Items.AddRange(New Object() {"Learn Calculus in One Day (Audio)", "Relaxtion Techniques (Audio)", "The History of Scotland (Audio)", "The Science of Body Language (Audio)"})
        Me.lstBoxAudio.Location = New System.Drawing.Point(18, 25)
        Me.lstBoxAudio.Name = "lstBoxAudio"
        Me.lstBoxAudio.Size = New System.Drawing.Size(358, 100)
        Me.lstBoxAudio.TabIndex = 0
        '
        'frmAudioBooks
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(418, 262)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnAddBook)
        Me.Controls.Add(Me.grpBoxAudio)
        Me.Name = "frmAudioBooks"
        Me.Text = "Audio Books"
        Me.grpBoxAudio.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnClose As Button
    Friend WithEvents btnAddBook As Button
    Friend WithEvents grpBoxAudio As GroupBox
    Friend WithEvents lstBoxAudio As ListBox
End Class
