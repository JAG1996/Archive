﻿Public Class frmPrintBooks
    Private Sub btnAddBook_Click(sender As Object, e As EventArgs) Handles btnAddBook.Click
        frmMain.lstBoxMain.Items.Add(lstBoxPrint.SelectedItem)
        frmMain.AddBook(lstBoxPrint.SelectedItem)
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub
End Class