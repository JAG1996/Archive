﻿Public Class frmAudioBooks
    Public Sub btnAddBook_Click(sender As Object, e As EventArgs) Handles btnAddBook.Click
        frmMain.lstBoxMain.Items.Add(lstBoxAudio.SelectedItem)
        frmMain.AddBook(lstBoxAudio.SelectedItem)
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

End Class