﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPrintBooks
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grpBoxPrint = New System.Windows.Forms.GroupBox()
        Me.lstBoxPrint = New System.Windows.Forms.ListBox()
        Me.btnAddBook = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.grpBoxPrint.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpBoxPrint
        '
        Me.grpBoxPrint.Controls.Add(Me.lstBoxPrint)
        Me.grpBoxPrint.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpBoxPrint.Location = New System.Drawing.Point(12, 12)
        Me.grpBoxPrint.Name = "grpBoxPrint"
        Me.grpBoxPrint.Size = New System.Drawing.Size(341, 148)
        Me.grpBoxPrint.TabIndex = 0
        Me.grpBoxPrint.TabStop = False
        Me.grpBoxPrint.Text = "Select a Print Book"
        '
        'lstBoxPrint
        '
        Me.lstBoxPrint.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstBoxPrint.FormattingEnabled = True
        Me.lstBoxPrint.ItemHeight = 16
        Me.lstBoxPrint.Items.AddRange(New Object() {"I Did It Your Way (Print)", "The History of Scotland (Print)", "Learn Calculus in One Day (Print)", "Feel the Stress (Print)"})
        Me.lstBoxPrint.Location = New System.Drawing.Point(18, 25)
        Me.lstBoxPrint.Name = "lstBoxPrint"
        Me.lstBoxPrint.Size = New System.Drawing.Size(305, 100)
        Me.lstBoxPrint.TabIndex = 0
        '
        'btnAddBook
        '
        Me.btnAddBook.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddBook.Location = New System.Drawing.Point(56, 193)
        Me.btnAddBook.Name = "btnAddBook"
        Me.btnAddBook.Size = New System.Drawing.Size(139, 57)
        Me.btnAddBook.TabIndex = 3
        Me.btnAddBook.Text = "Add Book to Cart"
        Me.btnAddBook.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.Location = New System.Drawing.Point(201, 193)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(107, 57)
        Me.btnClose.TabIndex = 3
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'frmPrintBooks
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(366, 262)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnAddBook)
        Me.Controls.Add(Me.grpBoxPrint)
        Me.Name = "frmPrintBooks"
        Me.Text = "Print Books"
        Me.grpBoxPrint.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents grpBoxPrint As GroupBox
    Friend WithEvents lstBoxPrint As ListBox
    Friend WithEvents btnAddBook As Button
    Friend WithEvents btnClose As Button
End Class
