﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblMessage = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.pic5 = New System.Windows.Forms.PictureBox()
        Me.pic1 = New System.Windows.Forms.PictureBox()
        Me.pic3 = New System.Windows.Forms.PictureBox()
        Me.pic4 = New System.Windows.Forms.PictureBox()
        Me.pic2 = New System.Windows.Forms.PictureBox()
        CType(Me.pic5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(145, 26)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(210, 16)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Click a Card to See It's Name"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblMessage
        '
        Me.lblMessage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblMessage.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMessage.Location = New System.Drawing.Point(20, 197)
        Me.lblMessage.Name = "lblMessage"
        Me.lblMessage.Size = New System.Drawing.Size(444, 33)
        Me.lblMessage.TabIndex = 2
        Me.lblMessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(191, 251)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(108, 23)
        Me.Button1.TabIndex = 3
        Me.Button1.Text = "Exit"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'pic5
        '
        Me.pic5.ErrorImage = Global.Card_Identifier.My.Resources.Resources.Ace_Diamonds
        Me.pic5.Image = Global.Card_Identifier.My.Resources.Resources.Ace_Diamonds
        Me.pic5.Location = New System.Drawing.Point(380, 62)
        Me.pic5.Name = "pic5"
        Me.pic5.Size = New System.Drawing.Size(84, 110)
        Me.pic5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic5.TabIndex = 8
        Me.pic5.TabStop = False
        '
        'pic1
        '
        Me.pic1.ErrorImage = Global.Card_Identifier.My.Resources.Resources.Ace_Spades
        Me.pic1.Image = Global.Card_Identifier.My.Resources.Resources.Ace_Spades
        Me.pic1.Location = New System.Drawing.Point(20, 62)
        Me.pic1.Name = "pic1"
        Me.pic1.Size = New System.Drawing.Size(84, 110)
        Me.pic1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic1.TabIndex = 7
        Me.pic1.TabStop = False
        '
        'pic3
        '
        Me.pic3.ErrorImage = Global.Card_Identifier.My.Resources.Resources.Joker_Black
        Me.pic3.Image = Global.Card_Identifier.My.Resources.Resources._8_Clubs
        Me.pic3.Location = New System.Drawing.Point(200, 62)
        Me.pic3.Name = "pic3"
        Me.pic3.Size = New System.Drawing.Size(84, 110)
        Me.pic3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic3.TabIndex = 6
        Me.pic3.TabStop = False
        '
        'pic4
        '
        Me.pic4.Image = Global.Card_Identifier.My.Resources.Resources._2_Clubs
        Me.pic4.Location = New System.Drawing.Point(290, 62)
        Me.pic4.Name = "pic4"
        Me.pic4.Size = New System.Drawing.Size(84, 110)
        Me.pic4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic4.TabIndex = 5
        Me.pic4.TabStop = False
        '
        'pic2
        '
        Me.pic2.Image = Global.Card_Identifier.My.Resources.Resources._5_Hearts
        Me.pic2.Location = New System.Drawing.Point(110, 62)
        Me.pic2.Name = "pic2"
        Me.pic2.Size = New System.Drawing.Size(84, 110)
        Me.pic2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic2.TabIndex = 4
        Me.pic2.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(492, 286)
        Me.Controls.Add(Me.pic5)
        Me.Controls.Add(Me.pic1)
        Me.Controls.Add(Me.pic3)
        Me.Controls.Add(Me.pic4)
        Me.Controls.Add(Me.pic2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.lblMessage)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Card Identifier"
        CType(Me.pic5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents lblMessage As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents pic2 As PictureBox
    Friend WithEvents pic4 As PictureBox
    Friend WithEvents pic3 As PictureBox
    Friend WithEvents pic1 As PictureBox
    Friend WithEvents pic5 As PictureBox
End Class
