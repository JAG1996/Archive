﻿Public Class Form1
    Private Sub pic1_Click(sender As Object, e As EventArgs) Handles pic1.Click
        lblMessage.Text = "Ace of Spades"
    End Sub

    Private Sub pic2_Click(sender As Object, e As EventArgs) Handles pic2.Click
        lblMessage.Text = "Five of Hearts"
    End Sub

    Private Sub pic3_Click(sender As Object, e As EventArgs) Handles pic3.Click
        lblMessage.Text = "Eight of Clubs"
    End Sub

    Private Sub pic4_Click(sender As Object, e As EventArgs) Handles pic4.Click
        lblMessage.Text = "Two of Clubs"
    End Sub

    Private Sub PictureBox5_Click(sender As Object, e As EventArgs) Handles pic5.Click
        lblMessage.Text = "Ace of Diamonds"
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub
End Class
