import java.util.Scanner;

public class SumOfDigits { // Start of Class
   public static void main(String[] args) { // Start of Main
      Scanner keyboard = new Scanner(System.in);
      
      int extract = 0;
      int highest = 0;
      int lowest = 9;
      int result = 0;
      
      System.out.print("Enter numbers without characters seperating them." + "\n" +
                       "( Example: 424567 )" + "\n" + "\n");
      String input = keyboard.nextLine();
      
      for (int i = 0; i < input.length(); i++) { // Start of For Loop
         if (input.charAt(i) == '1') { // Start of If
            extract = 1;
            result++;
         } // End of If
         if (input.charAt(i) == '2') { // Start of If
            extract = 2;
            result += 2;
         } // End of If
         if (input.charAt(i) == '3') { // Start of If
            extract = 3;
            result += 3;
         } // End of If
         if (input.charAt(i) == '4') { // Start of If
            extract = 4;
            result += 4;
         } // End of If
         if (input.charAt(i) == '5') { // Start of If
            extract = 5;
            result += 5;
         } // End of If
         if (input.charAt(i) == '6') { // Start of If
            extract = 6;
            result += 6;
         } // End of If
         if (input.charAt(i) == '7') { // Start of If
            extract = 7;
            result += 7;
         } // End of If
         if (input.charAt(i) == '8') { // Start of If
            extract = 8;
            result += 8;
         } // End of If
         if (input.charAt(i) == '9') { // Start of If
            extract = 9;
            result += 9;
         } // End of If
         if (lowest >= extract) { // Start of If
            lowest = extract;
         } // End of If 
         if (highest <= extract) { // Start of If
            highest = extract;
         } // End of If 
      } // End of For Loop
      
      System.out.print("Within that group of digits..." + "\n" +
                       "The lowest number is: " + lowest + "\n" +
                       "the highest number is: " + highest + "\n" +
                       "and the sum is: " + result);
   } // End of Main
} // End of Class