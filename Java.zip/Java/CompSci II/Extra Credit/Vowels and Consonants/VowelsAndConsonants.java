import java.util.Scanner;

public class VowelsAndConsonants { // Start of Class
   private String original;
   
   public VowelsAndConsonants() { // Start of no arg Constructor
      original = "";
   } // End of no arg Constructor
   
   public VowelsAndConsonants(String str) { // Start of no arg Constructor
      original = str;
   } // End of no arg Constructor
   
   public int getVowels(String str) { // Start of Method
      int count = 0;
      for (int i = 0; i < (str.length()); i++) { // Start of For Loop
         if (str.charAt(i) == 'A' ||
                str.charAt(i) == 'E' ||
                str.charAt(i) == 'I' ||
                str.charAt(i) == 'O' ||
                str.charAt(i) == 'U') { // Start of If
            count++;         
         } // End of If
      } // End of For Loop
      return count;                                  
   } // End of Method
   
   public int getConsonants(String str) { // Start of Method
      int count = 0;
      for (int i = 0; i < (str.length()); i++) { // Start of For Loop
         if (str.charAt(i) == 'B' ||
                str.charAt(i) == 'C' ||
                str.charAt(i) == 'D' ||
                str.charAt(i) == 'F' ||
                str.charAt(i) == 'G' ||
                str.charAt(i) == 'H' ||
                str.charAt(i) == 'J' ||
                str.charAt(i) == 'K' ||
                str.charAt(i) == 'L' ||
                str.charAt(i) == 'M' ||
                str.charAt(i) == 'N' ||
                str.charAt(i) == 'P' ||
                str.charAt(i) == 'Q' ||
                str.charAt(i) == 'R' ||
                str.charAt(i) == 'S' ||
                str.charAt(i) == 'T' ||
                str.charAt(i) == 'V' ||
                str.charAt(i) == 'W' ||
                str.charAt(i) == 'X' ||
                str.charAt(i) == 'Y' ||
                str.charAt(i) == 'Z') { // Start of If
            count++;         
         } // End of If
      } // End of For Loop
      return count;                                  
   } // End of Method
   
   public static void main(String[] args) { // Start of Main
      Scanner keyboard = new Scanner(System.in);
      
      VowelsAndConsonants vac = new VowelsAndConsonants();
      
      int result = 0;
      
      boolean maintaining = true;
      
      System.out.print("Enter a string: ");
      String str = keyboard.nextLine();
      
      while (maintaining) { // Start of While Loop
      
         System.out.print("\n" + "Enter one of the following:" + "\n" + "\n" +
                              "1. Count the number of vowels in the string" + "\n" +
                              "2. Count the number of consonants in the string" + "\n" +
                              "3. Count both the vowels and consonants in the string" + "\n" +
                              "4. Enter another string" + "\n" +
                              "5. Exit the program" + "\n" + "\n");
         int selection = keyboard.nextInt();
      
         while (selection < 1 || selection > 5) { // Start of While Loop
            System.out.println("INVALID. Please enter a number between 1 and 5.");
            selection = keyboard.nextInt();
         } // End of While Loop
      
         String capital = str.toUpperCase();
      
         if (selection == 1) { // Start of If
            result = vac.getVowels(capital); 
            System.out.print("The number of vowels the string \"" + str + "\" contains is " + result + ".\n\n");
         } // End of If
      
         if (selection == 2) { // Start of If
            result = vac.getConsonants(capital); 
            System.out.print("The number of consonants the string \"" + str + "\" contains is " + result + ".\n\n");
         } // End of If
      
         if (selection == 3) { // Start of If
            result = vac.getVowels(capital) + vac.getConsonants(capital); 
            System.out.print("The number of vowels & consonants the string \"" + str + "\" contains is " + result + ".\n\n");
         } // End of If
      
         
         if (selection == 5) { // Start of If
            System.out.print("Closing at your request.");
            System.exit(0);      
         } // End of If
         
         // This was the only way I could get the program to operate properly.         
         System.out.print("Enter a string: ");
         str = keyboard.nextLine();
         capital = str.toUpperCase();
         str = keyboard.nextLine();
         capital = str.toUpperCase();
      } // End of While Loop
   } // End of Main
} // End of Class