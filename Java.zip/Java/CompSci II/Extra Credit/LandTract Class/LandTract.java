import java.util.Scanner;

public class LandTract { // Start of Class
   private double length;
   private double width;
   
   public LandTract() { // Start of no arg Constructor
      length = 0.0;
      width = 0.0;
   } // End of no arg Constructor
   
   public LandTract(double l, double w) { // Start of Constructor
      length = l;
      width = w;
   } // End of Constructor
   
   public double getArea() { // Start of Method
      return length * width;
   } // End of Method
   
   public boolean equals(double a1, double a2) { // Start of Method
      if (a1 == a2)
         return true;
      else
         return false;
   } // End of Method
   
   public String toString() { // Start of Method
      return "Area of Land Tract: " + (width * length) + ""; 
   } // End of Method
   
   public static void main(String[] args) { // Start of Method
      Scanner keyboard = new Scanner(System.in);
      
      LandTract landTract = new LandTract();
      
      System.out.print("Enter the length for Land Tract #1: ");
      double length1 = keyboard.nextDouble();
      
      System.out.print("Enter the width for Land Tract #1: ");
      double width1 = keyboard.nextDouble();
      
      System.out.println();
      
      System.out.print("Enter the length for Land Tract #2: ");
      double length2 = keyboard.nextDouble();
      
      System.out.print("Enter the width for Land Tract #2: ");
      double width2 = keyboard.nextDouble();
      
      double area1 = length1 * width1;
      double area2 = length2 * width2;
      
      System.out.println();
      System.out.println("The area of land tract #1 is " + area1);
      System.out.println("The area of land tract #2 is " + area2);
      System.out.println();
      
      if (landTract.equals(area1, area2) == true) { // Start of If
         System.out.print("The land tracts are equivalent.");
      } // End of If
      else { // Start of Else
         System.out.print("The land tracts are NOT equivalent.");
      } // End of Else
   } // End of Method
} // End of Class