import java.util.Scanner;

public class PasswordVerifier { // Start of Class
   public static void main(String[] args) { // Start of Main
      Scanner keyboard = new Scanner(System.in);
      
      boolean lower = false;
      boolean upper = false;
      boolean digit = false;
      
      System.out.print("Enter a password that contains at least 6 characters," + "\n" +
                       "one upper and one lower case letter, " + "\n" +
                       "and at least one digit:" + "\n" + "\n");
      String password = keyboard.nextLine();
      
      for (int i = 0; i < password.length(); i++) { // Start of For Loop
         if (password.charAt(i) >= 'a' && password.charAt(i) <= 'z') { // Start of If
            lower = true;
         } // End of If
         if (password.charAt(i) >= 'A' && password.charAt(i) <= 'Z') { // Start of If
            upper = true;
         } // End of If
         if (password.charAt(i) >= '0' && password.charAt(i) <= '9') { // Start of If
            digit = true;
         } // End of If
      } // End of For Loop
      
      if ((password.length() > 6) && lower && upper && digit) { // Start of If
         System.out.print("Password acceptable.");
      } // End of If
      else { // Start of Else
         System.out.print("Password unacceptable.");
      } // End of Else
   } // End of Main
} // End of Class