import java.util.Scanner;

public class Geometry { // Start of Class
   static Scanner keyboard = new Scanner(System.in);

   public static double getCircleArea(double r) { // Start of Method
      while (r < 0.0) { // Start of While Loop
         System.out.print("INVALID. Enter any non-negative number: ");
         r = keyboard.nextDouble();
      } // End of While Loop
      return (Math.PI * (r * r));
   } // End of Method
   
   public static double getRectangleArea(double l, double w) { // Start of Method
      while (l < 0.0) { // Start of While Loop
         System.out.print("INVALID. Enter any non-negative number: ");
         l = keyboard.nextDouble();
      } // End of While Loop
      while (w < 0.0) { // Start of While Loop
         System.out.print("INVALID. Enter any non-negative number: ");
         w = keyboard.nextDouble();
      } // End of While Loop
      return (l * w);
   } // End of Method
   
   public static double getTriangleArea(double b, double h) { // Start of Method
      while (b < 0.0) { // Start of While Loop
         System.out.print("INVALID. Enter any non-negative number: ");
         b = keyboard.nextDouble();
      } // End of While Loop
      while (h < 0.0) { // Start of While Loop
         System.out.print("INVALID. Enter any non-negative number: ");
         h = keyboard.nextDouble();
      } // End of While Loop
      return (b * h * 0.5);
   } // End of Method

   public static void main(String[] args) { // Start of Main
      System.out.print("Geometry Calculator\n" +
                       "1. Calculate the Area of a Circle" + "\n" +
                       "2. Calculate the Area of a Rectangle" + "\n" +
                       "3. Calculate the Area of a Triangle" + "\n" +
                       "4. Quit " + "\n" + 
                       "\n" +
                       "Enter your choice (1-4):");
      int selection = keyboard.nextInt();
      
      while (selection < 1 || selection > 4) { // Start of While Loop
         System.out.print("INVALID. Enter a number between 1 and 4: ");
         selection = keyboard.nextInt();
      } // End of While Loop
      
      System.out.println();
      
      if (selection == 1) { // Start of If
         System.out.print("Enter the radius of the Circle: ");
         System.out.print("The area of the circle is " + getCircleArea(keyboard.nextDouble()));
      } // End of If
      
      if (selection == 2) { // Start of If
         System.out.print("Enter the length of the Rectangle: ");
         double length = keyboard.nextDouble();
         
         System.out.print("Enter the width of the Rectangle: ");
         double width = keyboard.nextDouble();
         
         System.out.print("The area of the rectangle is " + getRectangleArea(length, width));
      } // End of If
      
      if (selection == 3) { // Start of If
         System.out.print("Enter the base of the Triangle: ");
         double base = keyboard.nextDouble();
         
         System.out.print("Enter the height of the Triangle: ");
         double height = keyboard.nextDouble();
         
         System.out.print("The area of the triangle is " + getTriangleArea(base, height));
      } // End of If
      
      if (selection == 4) { // Start of If
         System.exit(0);
      } // End of If
   } // End of Main
} // End of Class