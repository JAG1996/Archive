import java.util.Scanner;

public class BackwardString { // Start of Class
   public static void main(String[] args) { // Start of Main
      String reverse = "";
      
      Scanner keyboard = new Scanner(System.in);
      
      System.out.print("Enter the string to be reversed: ");
      String original = keyboard.nextLine();
      
      System.out.println();
      
      for (int i = (original.length() - 1); i >= 0; i--) { // Start of For Loop
         reverse += original.charAt(i);
      } // End of For Loop   
      
      System.out.print("       When the string \"" + original + "\"," + "\n" +
                       "is reversed it becomes \"" + reverse + "\".");    
   } // End of Main
} // End of Class