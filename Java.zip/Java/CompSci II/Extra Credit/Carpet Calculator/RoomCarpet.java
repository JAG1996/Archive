public class RoomCarpet { // Start of Class
   RoomDimension size;
   private double carpetCost;
      
   public RoomCarpet(RoomDimension dim, double cost) { // Start of Method
      size = dim;
      carpetCost = cost;
   } // End of Method
   
   public double getTotalCost() { // Start of Method
      return size.getArea() * carpetCost;
   } // End of Method
   
   public String toString() { // Start of Method
      return getTotalCost() + "";
   } // End of Method
} // End of Class