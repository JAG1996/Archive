public class RoomDimension { // Start of Class
   private double length;
   private double width;
   
   public RoomDimension(double len, double w) { // Start of Constructor
      length = len;
      width = w;
   } // End of Constructor
   
   public double getArea() { // Start of Method
      return length * width;
   } // End of Method
   
   public String toString() { // Start of Method
      return (length * width) + "";
   } // End of Method
} // End of Class