import java.util.Scanner;

public class CarpetCalculator { // Start of Class
   public static void main(String[] args) { // Start of Main
      Scanner keyboard = new Scanner(System.in);
   
      System.out.print("Enter the length of the carpet: ");
      double length = keyboard.nextDouble();
   
      System.out.print("Enter the width of the carpet: ");
      double width = keyboard.nextDouble();
      
      System.out.print("Enter the price of the carpet: ");
      double carpetCost = keyboard.nextDouble();
   
      RoomDimension size = new RoomDimension(length, width);
      RoomCarpet carpet = new RoomCarpet(size, carpetCost);
      
      System.out.println();
      System.out.printf("Total cost of carpet: $%,.2f",carpet.getTotalCost()); 
   } // End of Main
} // End of Class