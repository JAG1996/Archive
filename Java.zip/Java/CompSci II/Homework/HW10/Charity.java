import java.text.DecimalFormat;

public class Charity 
{//Start of class
   private double total;
   private int count;
   private double smallest;
   private double largest;

   public Charity()
   {//Start of constructor
      total  = 0;
      count = 0;
      smallest = 0;
      largest = 0;
   }//End of constructor

   public void makeContribution(double c)
   {//Start of method
      total = total + c;
      count++;
      if (count == 1)
      {
         smallest = c;
         largest = c;
      }
      else 
      {
         if (c < smallest) smallest = c;
         if (c > largest)  largest = c;	
      }
   }//End of method

   public int getCount()
   {
      return count;
   }

   public double getSmallest()
   {
      return smallest;
   }
	
   public double getLargest()
   {
      return largest;
   }

   public double getTotal()
   {
      return total;
   }

   public double getAverage()
   {//Start of method
      if (count == 0)
         return 0;
      else	
         return total / count;
   }//End of method
   
   public String toString()
   {//Start of method
      DecimalFormat dollar = new DecimalFormat("$#,###.00");
      
      return "-- the total is " + dollar.format(getTotal()) + 
           "\n-- the count was " + count + 
           "\n-- the smallest was " + dollar.format(getSmallest()) + 
           "\n-- the largest was " + dollar.format(getLargest()) + 
           "\n-- the average was " + dollar.format(getAverage()) + "";
   }//End of method
   
}//End of class