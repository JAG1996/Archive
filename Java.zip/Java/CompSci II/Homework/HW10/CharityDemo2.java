public class CharityDemo2
{//Start of class
   public static void main(String[] args)
   {//Start of main

      //Instansiate the Charity objects.
      Charity redCross = new Charity();
      Charity heartFund = new Charity();
      Charity unitedFund = new Charity();
   	
      //Test the redCross object.
      redCross.makeContribution(20);
      redCross.makeContribution(15);
      redCross.makeContribution(10);
      System.out.println("For the Red Cross:\n" + redCross);
      System.out.println();
         	
      //Test the unitedFund object.
      unitedFund.makeContribution(12);
      unitedFund.makeContribution(16);
      unitedFund.makeContribution(18);
      unitedFund.makeContribution(22);
      System.out.println("For the United Fund:\n" + unitedFund);
      System.out.println();

      //Test the heartFund object.
      heartFund.makeContribution(14);
      heartFund.makeContribution(24);
      heartFund.makeContribution(19);
      heartFund.makeContribution(19);
      heartFund.makeContribution(19);
      System.out.println("For the Heart Fund:\n" + heartFund);
      System.out.println();
      
   }//End of main
}//End of class