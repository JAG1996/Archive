public class HW11
{//Start of class
   public static void main(String[] args)
   {//Start of main
   
      int man1 = 0;
      int man2 = 0;
      int man3 = 0;
      int man4 = 0;
      int morn = 0;
      int pig1 = 0;
      int pig2 = 0;
      int pig3 = 0;
      int pig4 = 0;
      int pig5 = 0;
      
     for (int apples = 1; apples <= 10000; apples++)
      {//Start of for loop
         man1 = apples / 4;
         pig1 = apples % 4;
         man1 *= 3;
         
         man2 = man1 / 4;
         pig2 = man1 % 4;;
         man2 *= 3;
         
         man3 = man2 / 4;
         pig3 = man2 % 4;
         man3 *= 3;
         
         man4 = man3 / 4;
         pig4 = man3 % 4;
         man4 *= 3;
         
         pig5 = man4 % 4;
         
         if (pig1 == 1 && pig2 == 1 && pig3 == 1 && pig4 == 1 && pig5 == 1)
         {//Start of if
            System.out.printf("%,d\n", apples);
         }//End of if
      }//End of for loop      
   }//End of main
}//End of class