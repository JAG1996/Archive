import javax.swing.*;
import java.awt.*;

/* 
                  Developed by Jacob Garrett
                                                            */

public class NonroutineServicesPanel extends JPanel { // Start of Class
   private JLabel lblPartsCharges;
   private JLabel lblHoursOfLabor;
   private JTextField partsCharges;
   private JTextField hoursOfLabor;
   
   public NonroutineServicesPanel() { // Start of Constructor
      setLayout(new GridLayout(2, 2));
      
      lblPartsCharges = new JLabel("Parts Charges:");
      lblHoursOfLabor = new JLabel("Hours of Labor:");
      
      partsCharges = new JTextField(10);
      hoursOfLabor = new JTextField(10);
      
      partsCharges.setText("0.0");
      hoursOfLabor.setText("0.0");
      
      setBorder(BorderFactory.createTitledBorder("Nonroutine Services"));
      
      add(lblPartsCharges);
      add(partsCharges);
      add(lblHoursOfLabor);
      add(hoursOfLabor);
   } // End of Constructor

   public double getPartsCharges() {
      return Double.parseDouble(partsCharges.getText());
   }
   
   public double getHoursOfLabor() {
      return Double.parseDouble(hoursOfLabor.getText());
   }
} // End of Class