import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.text.DecimalFormat;

/* 
                  Developed by Jacob Garrett
                                                            */

public class JoesAutomotive extends JFrame { // Start of Class
   private RoutineServicesPanel routine;
   private NonroutineServicesPanel nonroutine;
   private JPanel buttonPanel;
   private JButton calcButton;
   private JButton exitButton;
   private JTextField totalField;
   private JLabel lblTotal;
   private double totalAmount = 0.0;
   
   public JoesAutomotive() { // Start of Constructor
      setTitle("Joe's Automotive");
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setLayout(new BorderLayout());
      
      routine = new RoutineServicesPanel();
      nonroutine = new NonroutineServicesPanel();      
      buildButtonPanel();
      
      add(routine, BorderLayout.NORTH);
      add(nonroutine, BorderLayout.CENTER);
      add(buttonPanel, BorderLayout.SOUTH);
      
      pack();
      setVisible(true);
   } // End of Constructor
   
   private void buildButtonPanel() { // Start of method
      buttonPanel = new JPanel();
         
      calcButton = new JButton("Calculate Revenue");
      exitButton = new JButton("Exit");
      
      lblTotal = new JLabel("Total cost>>");
      totalField = new JTextField(10);
      totalField.setText("0.0");
      
      calcButton.addActionListener(new CalcButtonListener());
      exitButton.addActionListener(new ExitButtonListener());
   
      buttonPanel.add(calcButton);
      buttonPanel.add(lblTotal);
      buttonPanel.add(totalField);
      buttonPanel.add(exitButton);
   } // End of Method 
   
   private class CalcButtonListener implements ActionListener { // Start of Class
      public void actionPerformed(ActionEvent e) { // Start of Method
      } // End of Method
         double totalAmount = nonroutine.getPartsCharges() + (nonroutine.getHoursOfLabor() * 20) + routine.getRoutineCost();
         DecimalFormat dollar = new DecimalFormat("0.00");
//         totalField.setText("$" + dollar.format(totalAmount)); //  <--------   Not too sure why Identifier is expected
      
   } // End of Class
   
   private class ExitButtonListener implements ActionListener { // Start of Class
      public void actionPerformed(ActionEvent e) { // Start of Method
         System.exit(0);
      } // End of Method
   } // End of Class
      
   public static void main(String[] args) { // Start of Main
     new JoesAutomotive();
   } // End of Main
} // End of Class