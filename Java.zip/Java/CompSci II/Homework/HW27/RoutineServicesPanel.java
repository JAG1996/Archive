import javax.swing.*;
import java.awt.*;

/* 
                  Developed by Jacob Garrett
                                                            */

public class RoutineServicesPanel extends JPanel { // Start of Class
   public final double OIL_CHANGE = 26.0;
   public final double LUBE_JOB = 18.0;
   public final double RADIATOR_FLUSH = 30.0;
   public final double TRANSMISSION_FLUSH = 80.0;
   public final double INSPECTION = 15.0;
   public final double MUFFLER_REPLACEMENT = 100.0;
   public final double TIRE_ROTATION = 20.0;

   private JCheckBox oilChange; 
   private JCheckBox lubeJob;       
   private JCheckBox radiatorFlush;   
   private JCheckBox transmissionFlush; 
   private JCheckBox inspection;
   private JCheckBox mufflerReplacement;
   private JCheckBox tireRotation;
   
   public RoutineServicesPanel() { // Start of Constructor
      setLayout(new GridLayout(7, 1));
   
      oilChange = new JCheckBox("Oil Change ($26.00)");
      lubeJob = new JCheckBox("Lube Job ($18.00)");
      radiatorFlush = new JCheckBox("Radiator Flush ($30.00)");
      transmissionFlush = new JCheckBox("Transmission Flush ($80.00)");
      inspection = new JCheckBox("Inspection ($15.00)");
      mufflerReplacement = new JCheckBox("Muffler Replacement ($100.00)");
      tireRotation = new JCheckBox("Tire Rotation ($20.00)");
      
      setBorder(BorderFactory.createTitledBorder("Routine Services"));
   
      add(oilChange);
      add(lubeJob);
      add(radiatorFlush);
      add(transmissionFlush);
      add(inspection);
      add(mufflerReplacement);
      add(tireRotation);
   } // End of Constructor

   public double getRoutineCost()
   {//Start of Method
      double routineCost = 0.0;
   
      if (oilChange.isSelected())
         routineCost += OIL_CHANGE;
      if (lubeJob.isSelected())
         routineCost += LUBE_JOB;
      if (radiatorFlush.isSelected())
         routineCost += RADIATOR_FLUSH;
      if (transmissionFlush.isSelected())
         routineCost += TRANSMISSION_FLUSH;
      if (inspection.isSelected())
         routineCost += INSPECTION;
      if (mufflerReplacement.isSelected())
         routineCost += MUFFLER_REPLACEMENT;
      if (tireRotation.isSelected())
         routineCost += TIRE_ROTATION;
   
      return routineCost;
   } // End of Method
} // End of Class