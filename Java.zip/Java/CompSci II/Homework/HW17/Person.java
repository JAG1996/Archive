/**
   The Person class stores data about a person for 
   the PreferredCustomer Class programming challenge.
*/

public class Person
{//Start of class
   private String name;       // The person's name
   private String address;    // The person's address
   private String phone;      // The person's phone number

   /**
      The no-arg constructor initializes the object with
      empty strings for name, address, and phone.
   */

   public Person()
   {//Start of constructor
      name = "";
      address = "";
      phone = "";
   }//End of constructor

   /**
      This constructor initializes the object with
      a name, address, and a phone number.
      @param n The name.
      @param a The address.
      @param p The phone number.
   */

   public Person(String n, String a, String p)
   {//Start of constructor
      name = n;
      address = a;
      phone = p;
   }//End of constructor

   /**
      The setName method sets the name field.
      @param n The name to use.
   */

   public void setName(String n)
   {//Start of method
      name = n;
   }//End of constructor

   /**
      The setAddress method sets the address field.
      @param a The address to use.
   */

   public void setAddress(String a)
   {//Start of method
      address = a;
   }//End of constructor

   /**
      The setPhone method sets the phone field.
      @param p The phone number to use.
   */

   public void setPhone(String p)
   {//Start of method
      phone = p;
   }//End of constructor

   /**
      The getName method returns the name field.
      @return The name.
   */
   
   public String getName()
   {//Start of method
      return name;
   }//End of constructor

   /**
      The getAddress method returns the address field.
      @return The address.
   */
   
   public String getAddress()
   {//Start of method
      return address;
   }//End of constructor

   /**
      The getPhone method returns the phone field.
      @return The phone number.
   */
   
   public String getPhone()
   {//Start of method
      return phone;
   }//End of constructor
   
}//End of class