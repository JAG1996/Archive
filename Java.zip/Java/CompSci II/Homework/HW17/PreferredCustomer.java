public class PreferredCustomer extends Customer
{//Start of Class
   private double purchases;
   private double discountLevel;
   
   public PreferredCustomer()
   {//Start of no arg Constructor
      super();
      purchases = 0.0;
      discountLevel = 0.0;
   }//End of no arg Constructor
   
   public PreferredCustomer(String n, String a, String p, 
                            String c, boolean m, double pur)
   {//Start of no arg Constructor
      super(n, a, p, c, m);
      purchases = pur;
      discountLevel = getDiscountLevel();
   }//End of no arg Constructor
   
   public void setPurchases(double p)
   {//Start of Method
      purchases = p;
   }//End of Method
   
   public double getPurchases()
   {//Start of Method
      return purchases;
   }//End of Method
   
   public double getDiscountLevel()
   {//Start of Method
      return 0.07;   //<-- Wasn't sure if I was to put
   }//End of Method                a calculation or not
}//End of Class