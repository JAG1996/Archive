import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/* 
               Developed by Jacob Garrett
                                                          */

public class MagicSpot extends JFrame { // Start of Class
   String distanceString;
   
   boolean magicFound;
   
   int clickX;
   int clickY;
   
   int magicX;
   int magicY;
   
   int endX;
   int endY;
   
   int count = 0;
   
   private final int WINDOW_WIDTH = 400;
   private final int WINDOW_HEIGHT = 400;
   
   public MagicSpot() { // Start of Constructor
      this.setTitle("Magic Spot");
      this.setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
      this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      
      this.getContentPane().setBackground(Color.WHITE);
      
      this.addMouseListener(new MyMouseListener());
      selectMagicSpot();
      this.setVisible(true);
   } // End of Constructor
   
   public void selectMagicSpot() { // Start of Method
      Dimension d = this.getSize();
      double w = d.getWidth();
      double h = d.getHeight();
      
      magicX = (int) (w * 0.8 * Math.random() + (w * 0.1));
      magicY = (int) (h * 0.8 * Math.random() + (h * 0.1));
   } // End of Method
   
   private class MyMouseListener implements MouseListener { // Start of Private Class
      public void mousePressed(MouseEvent e) { // Start of Method
         clickX = e.getX();
         clickY = e.getY();
         int diffX = magicX - clickX;
         int diffY = magicY - clickY;
         int distanceNumber = (int) Math.sqrt((diffX * diffX) + (diffY * diffY));
                  
            double ratio = 40.0 / ((double) distanceNumber);
            endX = clickX - (int) (diffX * ratio);
            endY = clickY - (int) (diffY * ratio);

         if (distanceNumber < 20) { // Start of If
            magicFound = true;
            distanceString = "*Magic";
            count++;
            repaint();
            JOptionPane.showMessageDialog(null, 
               "You found the magic spot at " + magicX + ", " + magicY + 
               " in " + count + " tries!", "Congradulations!", 
               JOptionPane.PLAIN_MESSAGE);
            count = 0;
            selectMagicSpot();
            repaint();
         } // End of If
         else { // Start of Else
            distanceString = "*" + distanceNumber;
            count++;
            repaint();
         } // End of Else
      } // End of Method
      
      public void mouseClicked(MouseEvent e) { // Start of Method
      } // End of Method
      
      public void mouseReleased(MouseEvent e) { // Start of Method
      } // End of Method
      
      public void mouseEntered(MouseEvent e) { // Start of Method
      } // End of Method
      
      public void mouseExited(MouseEvent e) { // Start of Method
      } // End of Method 
   } // End of Private Class
   
   public void paint(Graphics g) { // Start of Method
      if (count == 0) { // Start of If
         super.paint(g);
      } // End of if
      else { // Start of Else
         if (magicFound) { // Start of If
            g.drawString(distanceString, clickX, clickY);
            magicFound = false;
            return;
         } // End of If
         g.drawLine(endX, endY, clickX, clickY);
      } // End of Else
   } // End of Method
   
   public static void main(String[] args) { // Start of Main
      new MagicSpot();
   } // End of Main
} // End of Class