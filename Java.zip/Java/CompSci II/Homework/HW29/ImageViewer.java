import java.awt.*;
import java.io.File;
import javax.swing.*;
import java.awt.event.*;

/*
               Developed by Jacob Garrett
                                                       */
                                                         
public class ImageViewer extends JFrame { // Start of Class
   private JPanel imagePanel;
   private JPanel buttonPanel;
   private JLabel imageLabel;
   private JButton button;
   private JFileChooser fileChooser;
   
   public ImageViewer() { // Start of Constructor
      setTitle("Image Viewer");
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setLayout(new BorderLayout());
      
      buildImagePanel();
      buildButtonPanel();
      
      add(imagePanel, BorderLayout.CENTER);
      add(buttonPanel, BorderLayout.SOUTH);
      
      fileChooser = new JFileChooser(".");
      
      pack();
      setVisible(true);
   } // End of Constructor
   
   private void buildImagePanel() { // Start of Method
      imagePanel = new JPanel();
      imageLabel = new JLabel("Click the button to get an image.");
      imagePanel.add(imageLabel);
   } // End of Method
   
   private void buildButtonPanel() { // Start of Method
      buttonPanel = new JPanel();
      
      button = new JButton("Get Image");
      button.setMnemonic(KeyEvent.VK_G);
      button.setToolTipText("Click here to laod an image.");
      
      button.addActionListener(new ButtonListener());
      
      buttonPanel.add(button);
   } // End of Method
   
   private class ButtonListener implements ActionListener { // Start of Class
      public void actionPerformed(ActionEvent e) { // Start of Method
         File selectedFile;
         ImageIcon image;
         String filename;
         int fileChooserStatus;
         
         fileChooserStatus = fileChooser.showOpenDialog(ImageViewer.this);
         
         if (fileChooserStatus == JFileChooser.APPROVE_OPTION) { // Start of If
            selectedFile = fileChooser.getSelectedFile();
            
            filename = selectedFile.getPath();
            
            image = new ImageIcon(filename);
            
            imageLabel.setIcon(image);
            
            imageLabel.setText(null);
            
            pack();
         } // End of If
      } // End of Method
   } // End of Class
   
   public static void main(String[] args) { // Start of Main
      new ImageViewer();
   } // End of Main
} // End of Class