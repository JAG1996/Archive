import java.text.DecimalFormat;

public class ProductionWorker extends Employee
{// Start of class
   public static final int DAY_SHIFT = 1;
   public static final int NIGHT_SHIFT = 2;
   
   private int shift;
   private double payRate;
   
   public ProductionWorker(String n, String num, String date, int sh, double rate)
   {//Start of method
      super(n, num, date);
      shift = sh;
      payRate = rate;
   }//End of method
   
   public ProductionWorker()
   {//Start of method
      super();
      shift = DAY_SHIFT;
      payRate = 0.0;
   }//End of method
   
   public void setShift(int s)
   {//Start of method
      shift = s;
   }//End of method
   
   public void setPayRate(double p)
   {//Start of method
      payRate = p;
   }//End of method
   
   public int getShift()
   {//Start of method
      return shift;
   }//End of method
   
   public double getPayRate()
   {//Start of method
      return payRate;
   }//End of method
   
   public String toString()
   {//Start of method
      DecimalFormat dollar = new DecimalFormat("#,##0.00");
      
      String str = super.toString();
      
      str += "\nShift: ";
      if (shift == DAY_SHIFT)
      {//Start of if
         str += "Day";
      }//End of if
      else if (shift == NIGHT_SHIFT)
      {//Start of else if
         str += "Night";
      }//End of else if
      else
      {//Start of else
         str += "INVALID SHIFT NUMBER";
      }//End of else
      
      str += ("\nHourly Pay Rate: $" + dollar.format(payRate));
      
      return str;
   }//End of method
   
}// End of class