public class Employee
{// Start of class
   private String name;
   private String employeeNumber;
   private String hireDate;
   
   public Employee(String n, String num, String date)
   {//Start of constructor
      name = n;
      employeeNumber = num;
      hireDate = date;
   }//End of constructor
   
   public Employee()
   {//Start of no arg constructor
      name = "";
      employeeNumber = "";
      hireDate = "";
   }//End of no arg constructor
   
   public void setName(String n)
   {//Start of method
      name = n;
   }//End of method
   
   public void setEmployeeNumber(String e)
   {//Start of method
      if (isValidEmpNum(e))
      {//Start of if
         employeeNumber = e;
      }//End of if
      else
      {//Start of else
         employeeNumber = "";
      }//End of else
   }//End of method
   
   public void setHireDate(String h)
   {//Start of method
      hireDate = h;
   }//End of method
   
   public String getName()
   {//Start of method
      return name;
   }//End of method
   
   public String getEmployeeNumber()
   {//Start of method
      return employeeNumber;
   }//End of method
   
   public String getHireDate()
   {//Start of method
      return hireDate;
   }//End of method
   
   private boolean isValidEmpNum(String e)
   {//Start of method
      boolean status = true;
      
      if (e.length() != 5)
      {//Start of if
         status = false;
      }//End of if
      else
      {//Start of else
         if ((!Character.isDigit(e.charAt(0)))          ||
             (!Character.isDigit(e.charAt(1)))          ||
             (!Character.isDigit(e.charAt(2)))          ||
             (e.charAt(3) != '-')                       ||
             (Character.toUpperCase(e.charAt(4)) < 'A') ||
             (Character.toUpperCase(e.charAt(4)) > 'M'))
               status = false;
      }//End of else
      
      return status;
   }//End of method
   
   public String toString()
   {//Start of method
      String str = "Name: " + name + " \nEmployee Number: ";
      
      if (employeeNumber == "")
      {//Start of if
         str += "INVALID EMPLOYEE NUMBER";
      }//End of if
      else
      {//Start of else
         str += employeeNumber;
      }//End of else
      str += ("\nHireDate: " + hireDate);
      return str;
   }//End of method
   
}// End of class