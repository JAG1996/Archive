import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class DormAndMealPlanCalc extends JFrame  //Lab20
{//Start public class
   private JPanel dormPanel;
   private JPanel mealPanel;
   private JPanel totalPanel;
      
   private JTextField dormText;
   private JTextField mealText;
   private JTextField totalText;
   
   private JRadioButtonMenuItem dorm0Item;
   private JRadioButtonMenuItem dorm1Item;
   private JRadioButtonMenuItem dorm2Item;
   private JRadioButtonMenuItem dorm3Item;
   
   private JRadioButtonMenuItem meal0Item;
   private JRadioButtonMenuItem meal1Item;
   private JRadioButtonMenuItem meal2Item;
   
   private JMenuBar menuBar;
   
   private JMenu fileMenu;
   private JMenu dormMenu;
   private JMenu mealMenu;
   
   private JMenuItem exitItem;
   
   public DormAndMealPlanCalc()
   {//Start constructor
      setTitle("Dorm and Meal Plan Calculator");
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      
      buildMenuBar();
      setJMenuBar(menuBar);
   
      buildDormPanel();
      buildMealPanel();
      buildTotalPanel();
      
      setLayout(new GridLayout(3,1));
      
      add(dormPanel);
      add(mealPanel);
      add(totalPanel);
      
      pack();
      setVisible(true);
   }//End constructor

   private void buildMenuBar() { // Start of Method
      menuBar = new JMenuBar();
      
      buildFileMenu();
      buildDormMenu();
      buildMealMenu();
      
      menuBar.add(fileMenu);
      menuBar.add(dormMenu);
      menuBar.add(mealMenu);
   } // End of Method
   
   private void buildFileMenu() { // Start of Method
      exitItem = new JMenuItem("Exit");
      exitItem.addActionListener(new ExitListener());
         
      fileMenu = new JMenu("File");
      
      fileMenu.add(exitItem);
   } // End of Method
    
   private void buildDormMenu() { // Start of Method
      dormMenu = new JMenu("Dorms");
         
      dorm0Item = new JRadioButtonMenuItem("Allen Hall", true);
      dorm0Item.addActionListener(new TotalCalcListener());
            
      dorm1Item = new JRadioButtonMenuItem("Pike Hall");
      dorm1Item.addActionListener(new TotalCalcListener());
      
      dorm2Item = new JRadioButtonMenuItem("Farthing Hall");
      dorm2Item.addActionListener(new TotalCalcListener());
         
      dorm3Item = new JRadioButtonMenuItem("University Suites");
      dorm3Item.addActionListener(new TotalCalcListener());
      
      ButtonGroup group = new ButtonGroup();
      group.add(dorm0Item);
      group.add(dorm1Item);
      group.add(dorm2Item);
      group.add(dorm3Item);
         
      dormMenu.add(dorm0Item);
      dormMenu.add(dorm1Item);
      dormMenu.add(dorm2Item);
      dormMenu.add(dorm3Item);
   } // End of Method
   
   private void buildMealMenu() { // Start of Method
      mealMenu = new JMenu("Meal Plans");
         
      meal0Item = new JRadioButtonMenuItem("7 meals per week", true);
      meal0Item.addActionListener(new TotalCalcListener());
            
      meal1Item = new JRadioButtonMenuItem("14 meals per week");
      meal1Item.addActionListener(new TotalCalcListener());
      
      meal2Item = new JRadioButtonMenuItem("Unlimited meals per week");
      meal2Item.addActionListener(new TotalCalcListener());
      
      ButtonGroup group = new ButtonGroup();
      group.add(meal0Item);
      group.add(meal1Item);
      group.add(meal2Item);
         
      mealMenu.add(meal0Item);
      mealMenu.add(meal1Item);
      mealMenu.add(meal2Item);
   } // End of Method
     
   private void buildDormPanel()
   {//Start method
      dormPanel = new JPanel();
      
      JLabel dormMsg = new JLabel("Dorm cost:");
   
      dormText = new JTextField(10);
      dormText.setText("$1,500.00");
      dormText.setEditable(false);
      
      dormPanel.add(dormMsg);
      dormPanel.add(dormText);
   }//End method

   private void buildMealPanel()
   {//Start method
      mealPanel = new JPanel();
      
      JLabel mealMsg = new JLabel("Meal Plan cost:");
      
      mealText = new JTextField(10);
      mealText.setText("$560.00");
      mealText.setEditable(false);
      
      mealPanel.add(mealMsg);
      mealPanel.add(mealText);
   }//End method
   
   private void buildTotalPanel() { // Start of Method
      totalPanel = new JPanel();
      
      JLabel totalMsg = new JLabel("Total cost:");
      
      totalText = new JTextField(10);
      totalText.setText("$2,060.00");
      totalText.setEditable(false);
      
      totalPanel.add(totalMsg);
      totalPanel.add(totalText);
   } // End of Method
   
   private class TotalCalcListener implements ActionListener
   {//Start inner class
      public void actionPerformed(ActionEvent e)
      {//start method
         if (dorm0Item.isSelected() && meal0Item.isSelected()) { // Start of If
            dormText.setText("$1,500.00");
            mealText.setText("$560.00");
            totalText.setText("$2,060.00");
         } // End of If
         
         if (dorm0Item.isSelected() && meal1Item.isSelected()) { // Start of If
            dormText.setText("$1,500.00");
            mealText.setText("$1,095.00");
            totalText.setText("$2,595.00");
         } // End of If
         
         if (dorm0Item.isSelected() && meal2Item.isSelected()) { // Start of If
            dormText.setText("$1,500.00");
            mealText.setText("$1,500.00");
            totalText.setText("$3,000.00");
         } // End of If
         
         if (dorm1Item.isSelected() && meal0Item.isSelected()) { // Start of If
            dormText.setText("$1,600.00");
            mealText.setText("$560.00");
            totalText.setText("$2,160.00");
         } // End of If
         
         if (dorm1Item.isSelected() && meal1Item.isSelected()) { // Start of If
            dormText.setText("$1,600.00");
            mealText.setText("$1,095.00");
            totalText.setText("$2,695.00");
         } // End of If
         
         if (dorm1Item.isSelected() && meal2Item.isSelected()) { // Start of If
            dormText.setText("$1,600.00");
            mealText.setText("$1,500.00");
            totalText.setText("$3,100.00");
         } // End of If
         
         if (dorm2Item.isSelected() && meal0Item.isSelected()) { // Start of If
            dormText.setText("$1,200.00");
            mealText.setText("$560.00");
            totalText.setText("$1,760.00");
         } // End of If
         
         if (dorm2Item.isSelected() && meal1Item.isSelected()) { // Start of If
            dormText.setText("$1,200.00");
            mealText.setText("$1,095.00");
            totalText.setText("$2,295.00");
         } // End of If
         
         if (dorm2Item.isSelected() && meal2Item.isSelected()) { // Start of If
            dormText.setText("$1,200.00");
            mealText.setText("$1,500.00");
            totalText.setText("$1,700.00");
         } // End of If
         
         if (dorm3Item.isSelected() && meal0Item.isSelected()) { // Start of If
            dormText.setText("$1,800.00");
            mealText.setText("$560.00");
            totalText.setText("$2,360.00");
         } // End of If
         
         if (dorm3Item.isSelected() && meal1Item.isSelected()) { // Start of If
            dormText.setText("$1,800.00");
            mealText.setText("$1,095.00");
            totalText.setText("$2,895.00");
         } // End of If
         
         if (dorm3Item.isSelected() && meal2Item.isSelected()) { // Start of If
            dormText.setText("$1,800.00");
            mealText.setText("$1,500.00");
            totalText.setText("$3,300.00");
         } // End of If            
      }//End method
   }//End inner class 
   
   private class MealListener implements ActionListener
   {//Start inner class
      public void actionPerformed(ActionEvent e)
      {//start method
         if (meal0Item.isSelected()) { // Start of If
            mealText.setText("$560.00");
         } // End of If
         
         if (meal1Item.isSelected()) { // Start of If
            mealText.setText("$1,095.00");
         } // End of If
         
         if (meal2Item.isSelected()) { // Start of If
            mealText.setText("$1,500.00");
         } // End of If
      }//End method
   }//End inner class 
   
   private class ExitListener implements ActionListener
   {//Start inner class
      public void actionPerformed(ActionEvent e)
      {//Start method
         System.exit(0);
      }//End method
   } //End inner class
   
   public static void main(String[] args)
   {//Start of main()
      new DormAndMealPlanCalc();
   }//End of main()
}//End public class