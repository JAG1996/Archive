public class Doors100
{// Start of class
   public static void main(String[] args)
   {// Start of main
   
      boolean[] lockers = new boolean[100 + 1];
      
      for (int s = 1; s <= 100; s++) 
      {//Start of 's' for loop
         for (int l = s; l <= 100; l += s) 
         {//Start of embedded 'l' for loop
            lockers[l] = !lockers[l];
         }//End of embedded 'l' for loop
      }//End of 's' for loop
   
      System.out.println("At the end of the experiment, these lockers are open:\n");

      
      for (int d = 1; d < lockers.length; d++) 
      {//Start of 'd' for loop
         if (lockers[d] == true)
         {//Start of if
            System.out.println("Locker " + d + " is open.");
         }//End of if
               
      }//End of 'd' for loop
      
   }// End of main
}// End of class