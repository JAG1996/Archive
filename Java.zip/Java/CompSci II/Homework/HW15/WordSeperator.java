import java.util.Scanner;

public class WordSeperator
{//Start of class
   public static void main(String[] args)
   {//Start of main
      Scanner keyboard = new Scanner(System.in);
      
      System.out.println("Please enter a sentence, " + 
                         "that begins each word with a capital letter, \n" +
                         "without spaces in between: (ThisIsAnExample,OfWhatIsBeingAsked.)");
      String str = keyboard.nextLine();
      
      /*** The following for loop is a 
                 'Validation for loop' to deter
                         the use of a space character. ***/
      
      for (int i = 0; i < str.length(); i++)
      {//Start of 'Validation' for loop
         if (str.charAt(i) == ' ')
         {//Start of if
            System.out.println("\n>>> INVALID. PLEASE DO NOT ENTER A SPACE CHARACTER. <<<\n");
            System.out.println("Please enter a sentence, " + 
                         "that begins each word with a capital letter, \n" +
                         "without spaces in between: (ThisIsAnExample,OfWhatIsBeingAsked.)");
            str = keyboard.nextLine();
         }//End of if
      }//End of 'Validation' for loop
      
      for (int i = 0; i < str.length(); i++)
      {//Start of for loop
      
         /*** Step One ***/
         if (i == 0)
         {//Start of if
            System.out.print(Character.toUpperCase(str.charAt(i)));
            continue;
         }//End of if
         
         /*** Step Two ***/
         if (i == 1)
         {//Start of if
            if (Character.isUpperCase(str.charAt(i)))
            {//Start of if
               System.out.print(" ");
            }//End of if
            System.out.print(Character.toLowerCase(str.charAt(i)));
            continue;
         }//End of if
         
         /*** Reoccuring Steps ***/
         if (Character.isUpperCase(str.charAt(i)))
         {//Start of if
            if (str.charAt(i - 1) == '.' || str.charAt(i - 1) == '!' ||
                str.charAt(i - 1) == ',' || str.charAt(i - 1) == '?')
            {//Start of if
               System.out.print(" " + str.charAt(i));
               continue;
            }//End of if
            System.out.print(" " + Character.toLowerCase(str.charAt(i)));
            continue;
         }//End of if
         System.out.print(str.charAt(i));
      }//End of for loop  
         
   }//End of main
}//End of class