import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.text.DecimalFormat;

/* 
                  Developed by Jacob Garrett
                                                             */
  
public class TheaterRevenue extends JFrame { // Start of Class
   private DataPanel data;
   private JPanel buttonPanel;
   private JButton calcButton;
   private JButton resetButton;
   
//   private final int WINDOW_WIDTH = 360;
//   private final int WINDOW_HEIGHT = 180;
   
   private final double TAX_DIFFERENCE = 0.8;
   
   public TheaterRevenue() { // Start of Constructor
      setTitle("Theater Revenue");
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      
      data = new DataPanel();
      buildButtonPanel();
      
      add(data, BorderLayout.NORTH);
      add(buttonPanel, BorderLayout.SOUTH);
      
//      setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
      pack();
      setVisible(true);
   } // End of Constructor

   private void buildButtonPanel() { // Start of method
      buttonPanel = new JPanel();
      buttonPanel.setLayout(new FlowLayout());
         
      resetButton = new JButton("Reset");
      calcButton = new JButton("Calculate Revenue");
      
      calcButton.addActionListener(new CalcButtonListener());
      resetButton.addActionListener(new ResetButtonListener());
   
      buttonPanel.add(resetButton);
      buttonPanel.add(calcButton);
   } // End of Method    
     
   private class CalcButtonListener implements ActionListener { // Start of Class
      public void actionPerformed(ActionEvent e) { // Start of Method
         double calcAdultPrice = data.getAdultPrice();
         double calcAdultSold = data.getAdultSold();
         double calcChildPrice = data.getChildPrice();
         double calcChildSold = data.getChildSold();
         
         double grossAdult = (calcAdultPrice * calcAdultSold);
         double netAdult = (grossAdult * TAX_DIFFERENCE);
         double grossChild = (calcChildPrice * calcChildSold);
         double netChild = (grossChild * TAX_DIFFERENCE);
         double grossTotal = (grossAdult + grossChild);
         double netTotal = (netAdult + netChild);
         
         DecimalFormat dollar = new DecimalFormat("#,##0.00");
         
         JOptionPane.showMessageDialog(null, "Gross revenue for adult tickets sold: $" + dollar.format(grossAdult) +
                                             "\nNet revenue for adult tickets sold: $" + dollar.format(netAdult) + 
                                             "\nGross revenue for child tickets sold: $" + dollar.format(grossChild) +
                                             "\nNet revenue for child tickets sold: $" + dollar.format(netChild) + 
                                             "\nTotal gross revenue: $" + dollar.format(grossTotal) + 
                                             "\nTotal net revenue: $" + dollar.format(netTotal));
      } // End of Method
   } // End of Class
   
   private class ResetButtonListener implements ActionListener { // Start of Class
      public void actionPerformed(ActionEvent e) { // Start of Method
         data.reset();
      } // End of Method
   } // End of Class
   
   public static void main(String[] args) { // Start of Main
      new TheaterRevenue();
   } // End of Main
} // End of Class