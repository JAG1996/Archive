import java.awt.*;
import javax.swing.*;

/* 
                  Developed by Jacob Garrett
                                                             */
  
public class DataPanel extends JPanel { // Start of Class
   private JTextField adultPrice;
   private JTextField adultSold;
   private JTextField childPrice;
   private JTextField childSold;

   public DataPanel() { // Start of Constructor
      setLayout(new GridLayout(4, 2));
      
      JLabel lblAdultPrice = new JLabel("Enter the adult ticket price:");
      JLabel lblAdultSold = new JLabel("Enter the number of adult tickets sold:");
      JLabel lblChildPrice = new JLabel("Enter the child ticket price:");
      JLabel lblChildSold = new JLabel("Enter the number of child tickets sold:");
      
      adultPrice = new JTextField(10);
      adultSold = new JTextField(10);
      childPrice = new JTextField(10);
      childSold = new JTextField(10);
       
      add(lblAdultPrice);
      add(adultPrice);
      add(lblAdultSold);
      add(adultSold);
      add(lblChildPrice);
      add(childPrice);
      add(lblChildSold);
      add(childSold);     
   } // End of Constructor 
   
   public void reset() {
      adultPrice.setText("");
      adultSold.setText("");
      childPrice.setText("");
      childSold.setText("");
   }
   
   public double getAdultPrice() {
      return Double.parseDouble(adultPrice.getText());
   }     
   
   public double getAdultSold() {
      return Double.parseDouble(adultSold.getText());
   }     
   
   public double getChildPrice() {
      return Double.parseDouble(childPrice.getText());
   }     
   
   public double getChildSold() {
      return Double.parseDouble(childSold.getText());
   }     
} // End of Class