import java.io.*;

public class ReadBinaryData throws IOException
{//Start of Class
   public static void main(String[] args)
   {//Start of Main
      FileInputStream inFile = new FileInputStream("Binary.dat");
      DataInputStream inData = new DataInputStream(inFile);  
      
      boolean eof = false;  
      
      byte[] inputBytes = new byte[48];
      int ibCount = 0;
      
      while (!eof)
      {//Start of While Loop
         try
         {//Start of Try
            inputBytes[ibCount] = inData.readByte();
            ibCount++;
         }//End of Try
         catch (Exception e)
         {//Start of Catch
            eof = true;
         }//End of Catch
      }//End of While Loop  
   }//End of Main
}//End of Class