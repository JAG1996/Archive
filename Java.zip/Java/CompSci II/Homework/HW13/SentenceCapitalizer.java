import javax.swing.JOptionPane;

public class SentenceCapitalizer
{//Start of class
   public static void main(String[] args)
   {//Start of main
      String input;
      
      input = JOptionPane.showInputDialog("Enter a string. ");
      
      JOptionPane.showMessageDialog(null, sentenceCap(input));
      
      System.exit(0);
   }//End of main
   
   public static String sentenceCap(String str)
   {//Start of method
      int i;
      
      StringBuilder temp = new StringBuilder(str);
      
      if (temp.length() > 0)
          temp.setCharAt(0, Character.toUpperCase(temp.charAt(0)));
          
      i = temp.indexOf(". ");
      
      while (i != -1)
      {//Start of outer while loop
         i++;
         
         while (i < temp.length() && temp.charAt(i) == ' ')
         {//Start of inner while loop
            i++;
         }//End of inner while loop
         
         temp.setCharAt(i, Character.toUpperCase(temp.charAt(i)));
         
         i = temp.indexOf(". ", i);
         
      }//End of outer while loop
      
      return temp.toString();
      
   }//End of method
   
}//End of class