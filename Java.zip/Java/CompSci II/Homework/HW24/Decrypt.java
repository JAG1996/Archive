import java.io.*;

public class Decrypt
{//Start of Class
   public static void main(String[] args) throws IOException
   {//Start of Main
      FileInputStream inFile = new FileInputStream("Encrypted.dat");
      DataInputStream inData = new DataInputStream(inFile);
      
      FileOutputStream outFile = new FileOutputStream("Decrypted.txt");
      DataOutputStream outData = new DataOutputStream(outFile);
      
      byte encryptedByte = 0;
      byte decryptedByte = 0;
      
      while (true)
      {//Start of While loop
         try
         {//Start of Try
            encryptedByte = inData.readByte();
            decryptedByte = (byte) ((encryptedByte * 185) % 256);
            outData.writeByte(decryptedByte);
         }//End of Try
         catch (EOFException e)
         {//Start of Catch
            break;
         }//End of Catch
      }//End of While loop
      inFile.close();
      outFile.close();
   }//End of Main
}//End of Class