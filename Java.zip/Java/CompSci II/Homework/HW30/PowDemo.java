public class PowDemo { // Start of Class
   public static void main(String[] args) { // Start of Main
      double x = 2, y = 10;
      
      System.out.println(x + " raised to the power of " + y + " is " + pow(x, y));
   } // End of Main
   
   public static double pow(double x, double y) { // Start of Method
      if (y > 0)
         return x * pow(x, y-1);
      else
         return 1;
   } // End of Method
} // End of Class