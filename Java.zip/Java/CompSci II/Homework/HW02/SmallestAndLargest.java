import java.util.Scanner; 
//Here is an example of how to find the smallest and the largest 
//of a series of values without keeping a list of all of them 
//or needing to do a sort.

public class SmallestAndLargest   
{//Start of class
   public static void main(String[] args)
   {//Start of main
   
       // Create a Scanner object to read input.
      Scanner keyboard = new Scanner(System.in);
      int count = 0;
      double value = 0;
      double smallest = 0;
      double largest = 0;
      
      while (true)
      {//Start of loop
         System.out.print("Enter a number (or -1 to quit.)");
         value = keyboard.nextDouble();
         if (value == -1.0) break;
         count++;
         if (count == 1)
         {
            smallest = value;
            largest = value;
         }
         if (value < smallest) smallest = value; 
         if (value > largest) largest = value;  
      }//End of loop
      
      System.out.println("You typed in " + count + " numbers before -1.");
      System.out.println("The smallest number you typed in was " + smallest + ".");       
      System.out.println("The largest  number you typed in was " + largest + ".");       
      
   }//End of main
}//End of class