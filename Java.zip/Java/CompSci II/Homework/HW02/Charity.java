public class Charity
{// Start of class

   private int count = 0;
   private double smallest = 0.0;
   private double largest = 0.0;
   private double total = 0.0;
   private double average = 0.0;

   public Charity()
   {//Start of 'Charity' method
      count = 0;
      smallest = Math.pow(10.0, 14.0);
      largest = 0.0;
      total = 0.0;
      average = 0.0;
   }//End of 'Charity' method
   
   public void makeContribution(double c)
   {//Start of 'makeContribution' method
      if (largest <= c)
      {//Start of if
         largest = c;
      }//End of if
      if (smallest >= c)
      {//Start of if
         smallest = c;
      }//End of if
      count++;
      total += c;
      average = (total / count);
      return;
   }//End of 'makeContribution' method
   
   public int getCount()
   {//Start of 'getCount' method
      return count;
   }//End of 'getCount' method
   
   public double getSmallest()
   {//Start of 'getSmallest' method
      return smallest;
   }//End of 'getSmallest' method
   
   public double getLargest()
   {//Start of 'getLargest' method
      return largest;
   }//End of 'getLargest' method
   
   public double getTotal()
   {//Start of 'getTotal' method
      return total;
   }//End of 'getTotal' method
   
   public double getAverage()
   {//Start of 'getAverage' method
      return average;
   }//End of 'getAverage' method

}// End of class