import java.util.Scanner;
import java.util.StringTokenizer;

public class RecursiveFind
{//Start of class
   private static int index;
   private static String[] validationArray;
      
   public static void main(String[] args)
   {//Start of main   
      Scanner in = new Scanner(System.in);
      System.out.print("Enter the string  being searched: ");
      String string = in.nextLine();
      System.out.print("Enter the word we're looking for: ");
      String word = in.nextLine();
      
      boolean b = find(string, word);
   		
      if (b) 
      {
         System.out.println("The word \"" + word + "\" is found in that string.");
      }
      else
      {
         System.out.println("The word \"" + word + "\" is not found in that string.");
      }
   }//End of main

   public static boolean find(String str, String word)
   {//Start of the find method.
      boolean found = false;
      validationArray = str.split("\\b+");
      Arrays.asList(validationArray).contains(word);
      
      if (index >= 0) { // Start of If
         
         find(str, word);
      } // End of If
      return found;
   }//End of the find method.
}//End of class