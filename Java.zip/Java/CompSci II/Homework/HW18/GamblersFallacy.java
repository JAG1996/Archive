import java.util.Random;

public class GamblersFallacy
{//Start of Class
   public static void main(String[] args)
   {//Start of Main
      Random rand = new Random();
         
      int fiveCount = 0;
      int headCount = 0;
      int tailCount = 0;
      int[] toss = new int[6];
      
      for (int i = 0; i < 6; i++)
      {//Start of for loop
         toss[i] = rand.nextInt(2);
      }//End of for loop
 
      for (int n = 1; n <= 8000; n++)
      {//Start of "tosses" for loop
         for (int i = 0; i < 5; i++)
         {//Start of for loop
            toss[i] = toss[i + 1];
         }//End of for loop
         toss[5] = rand.nextInt(2);
         
         if (toss[0] == 1 && toss[1] == 1 && toss[2] == 1 && toss[3] == 1 && toss[4] == 1)
         {//Start of "threeCount" if
            fiveCount++;
            if (toss[5] == 1)
            {//Start of "nested if" if
               headCount++;
            }//End of "nested if" if
            else
            {//Start of "nested if" else
               tailCount++;
            }//End of "nested if" else
         }//End of "threeCount" if
      }//End of "tosses" for loop
      
      System.out.println("In 8,000 tosses, five heads in a row\n" +
                         "occured " + fiveCount + " times. After five heads\n" +
                         "in a row, the next toss was:\n" +
                         "- A head " + headCount + " times, and\n" +
                         "- A tail " + tailCount + " times.");
      
   }//End of Main
}//End of Class