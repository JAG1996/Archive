public class RaggedArray   //HW08
{//Start of class
   public static void main(String[] args)
   {//Start of main
      int[][] array = { 
                        {  1},
                        {  2,  3},
                        {  4,  5,  6},
                        {  7,  8,  9, 10},
                        { 11, 12, 13, 14, 15},
                        { 16, 17, 18, 19},
                        { 20, 21, 22},
                        { 23, 24},
                        { 25}
                      };
      
      System.out.println("Processing the array.");
      System.out.println("Total : " + getTotal(array));
      System.out.println("Average : " + getAverage(array));
      System.out.println("Total of row 0 : " + getRowTotal(array, 0));
      System.out.println("Total of row 2 : " + getRowTotal(array, 2));
      System.out.println("Total of col 0 : " + getColumnTotal(array, 0));
      System.out.println("Total of col 2 : " + getColumnTotal(array, 2));
      System.out.println("Highest in row 0 : " + getHighestInRow(array, 0));
      System.out.println("Highest in row 2 : " + getHighestInRow(array, 2));
      System.out.println("Lowest in row 0 : " + getLowestInRow(array, 0));
      System.out.println("Lowest in row 2 : " + getLowestInRow(array, 2));
      System.out.println("Highest in col 0 : " + getHighestInColumn(array, 0));
      System.out.println("Highest in col 2 : " + getHighestInColumn(array, 2));
      System.out.println("Lowest in col 0 : " + getLowestInColumn(array, 0));
      System.out.println("Lowest in col 2 : " + getLowestInColumn(array, 2));
      System.out.println("Elements in array : " + getElementCount(array));
   
   }//End of main
   
   public static int getTotal(int[][] array)
   {//Start of method
      int total = 0;
      
      for (int row = 0; row < array.length; row++)
      {//Start of 'row' for loop
         total = total + getRowTotal(array, row);
      }//End of 'row' for loop
      
      return total;
   }//End of method

      
   public static double getAverage(int[][] array)
   {//Start of method
      double average = 0.0;
      
         average = (double) getTotal(array) / (double) getElementCount(array);
      
      return average;
   }//End of method


   public static int getRowTotal(int[][] array, int row)
   {//Start of method
      int total = 0;
      
      for (int col = 0; col < array[row].length; col++)
      {//Start of 'col' for loop
         total = total + array[row][col];
      }//End of 'col' for loop
      
      return total;
   }//End of method

   
   public static int getColumnTotal(int[][] array, int col)
   {//Start of method
      int total = 0;
      
      for (int row = 0; row < array.length; row++)
      {//Start of 'row' for loop
         if (array[row].length > col)
         {//Start of if
            total = total + array[row][col];
         }//End of if
      }//End of 'row' for loop
   
      return total;
   }//End of method

  
   public static int getHighestInRow(int[][] array, int row)
   {//Start of method
      int highest = array[row][0];
      
      for (int col = 1; col < array[row].length; col++)
      {//Start of 'col' for loop
         if (array[row][col] > highest)
         {//Start of if
            highest = array[row][col];
         }//End of if
      }//End of 'col' for loop 
      
      return highest;
   }//End of method

   
   public static int getLowestInRow(int[][] array, int row)
   {//Start of method
      int lowest = array[row][0];
      
      for (int col = 1; col < array[row].length; col++)
      {//Start of 'col' for loop
         if (array[row][col] < lowest)
         {//Start of if
            lowest = array[row][col];
         }//End of if
      }//End of 'col' for loop 
      
      return lowest;
   }//End of method

   
   public static int getHighestInColumn(int[][] array, int col)
   {//Start of getHighestInColumn() method
      int highest = 0;
      boolean first = true;
      
      for (int row = 0; row < array.length; row++)
      {//Start of row "for" loop
         if (array[row].length > col)
         {//if this column exists in this row 
            if (first) 
            {//if this is the first value we've found in this column
               first = false;
               highest = array[row][col];
            }
            else         
            {//if this is NOT the first value we've found in this column.
               if (array[row][col] > highest)
                  highest = array[row][col];
            }
         }//End of "if this column exists in this row"
      }//End of row "for" loop
      
      return highest;
   }//End of getHighestInColumn() method


   public static int getLowestInColumn(int[][] array, int col)
   {//Start of getLowestInColumn() method
      int lowest = 0;
      boolean first = true;
      
      for (int row = 0; row < array.length; row++)
      {//Start of row "for" loop
         if (array[row].length > col)
         {//if this column exists in this row
            if (first) 
            {//if this is the first value we've found in this column
               first = false;
               lowest = array[row][col];
            }
            else         
            {//if this is NOT the first value we've found in this column.
               if (array[row][col] < lowest)
                  lowest = array[row][col];
            }
         }//End of "if this column exists in this row"
      }//End of for loop
      
      return lowest;
   }//End of getLowestInColumn() method
   
   public static int getElementCount(int[][] array)
   {//Start of method
      int count = 0;
      
      for (int row = 0; row < array.length; row++)
      {//Start of 'row' for loop
         count = count + array[row].length;
      }//End of 'row' for loop
      
      return count;
   }//End of method
   
}//End of class