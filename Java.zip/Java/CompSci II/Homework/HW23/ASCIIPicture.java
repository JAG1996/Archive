import java.util.Scanner;
import java.io.*;

public class ASCIIPicture
{//Start of Class
   public static void main(String[] args) throws IOException
   {//Start of Main
      Scanner keyboard = new Scanner(System.in);
      
      char[][] inputChars = new char[23][63];
      int column = 0;
      int row = 0;
       
      for (int r = 0; r < 23; r++)
      {//Start of 'Column' for loop
         for (int c = 0; c < 63; c++)
         {//Start of 'Row' for loop
            inputChars[r][c] = ' ';
         }//End of 'Row' for loop
      }//End of 'Column' for loop
      
      FileInputStream inFile = new FileInputStream("PictureData.dat");
      DataInputStream inData = new DataInputStream(inFile);
      
      while (true)
      {//Start of while loop
         try
         {//Start of Try
            for (int r = 0; r < 23; r++)
            {//Start of 'Row' for loop
               for (int c = 0; c < 63; c++)
               {//Start of 'Column' for loop
                  row = inData.readShort();
                  column = inData.readShort();
                  inputChars[row][column] = inData.readChar();
               }//End of 'Column' for loop
            }//End of 'Row' for loop
         }//End of Try
         catch (EOFException e)
         {//Start of Catch
            break;
         }//End of Catch
      }//End of while loop
      inFile.close();
      
      for (int r = 0; r < 23; r++)
      {//Start of 'Row' for loop
         for (int c = 0; c < 63; c++)
         {//Start of 'Column' for loop
            System.out.print(inputChars[r][c]);
         }//End of 'Column' for loop
         System.out.println();
      }//End of 'Row' for loop
   }//End of Main
}//End of Class