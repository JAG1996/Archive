public class InvalidIDException extends Exception
{//Start of Class
   public InvalidIDException()
   {//Start of Constructor
      super("Invalid ID number: ");
   }//End of Constructor
   
   public InvalidIDException(int number)
   {//Start of Constructor
      super("Invalid ID number: " + number);
   }//End of Constructor
}//End of Class