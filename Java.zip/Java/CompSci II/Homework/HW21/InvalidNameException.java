public class InvalidNameException extends Exception
{//Start of Class
   public InvalidNameException()
   {//Start of Constructor
      super("Invalid name");
   }//End of Constructor
   
   public InvalidNameException(String name)
   {//Start of Constructor
      super("Invalid name" + name);
   }//End of Constructor
}//End of Class