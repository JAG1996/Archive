public class InvalidHoursException extends Exception
{//Start of Class
   public InvalidHoursException()
   {//Start of Constructor
      super("Invalid number of hours: ");
   }//End of Constructor
   
   public InvalidHoursException(double number)
   {//Start of Constructor
      super("Invalid number of hours: " + number);
   }//End of Constructor
}//End of Class