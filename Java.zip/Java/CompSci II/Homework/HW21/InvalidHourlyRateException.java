public class InvalidHourlyRateException extends Exception
{//Start of Class
   public InvalidHourlyRateException()
   {//Start of Constructor
      super("Invalid hourly rate: ");
   }//End of Constructor
   
   public InvalidHourlyRateException(double number)
   {//Start of Constructor
      super("Invalid hourly pay rate: " + number);
   }//End of Constructor
}//End of Class