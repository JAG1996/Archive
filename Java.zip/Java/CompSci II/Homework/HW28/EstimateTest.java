import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.Random;

/*
                 Developed by Jacob Garrett
                                                           */

public class EstimateTest extends JFrame { // Start of Class
   private JPanel topPanel;
   private JPanel bottomPanel;

   private JLabel lblSetSlider;
   private JLabel lblClickCheck;
   private JLabel lblEstimate;   
   private JLabel lblResult; 
   
   private JTextField targetField;
   private JTextField estimateField;
   private JTextField resultField;
   
   private JButton restartButton;
   private JButton checkButton;
   
   private JSlider slider;

   private int compare;
   private int intResult;
   
   private String strResult;
   
   Random rand = new Random();
   
   public EstimateTest() { // Start of Constructor
    //  Random rand = new Random(100 + 1);
      
      setTitle("Estimate Test");
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      
      setLayout(new GridLayout(3, 1));
      
      buildTopPanel();
      buildSlider();
      buildBottomPanel();
      
      topPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
      bottomPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
      
      add(topPanel);
      add(slider);
      add(bottomPanel);
      
      pack();
      setVisible(true);
   } // End of Constructor
   
   private void buildTopPanel() { // Start of Method
      restartButton = new JButton("Restart");
      restartButton.addActionListener(new RestartButtonListener());
      
      lblSetSlider = new JLabel("Try to set the slider to this number:");
      targetField = new JTextField(5);
      lblClickCheck = new JLabel("and then click on the \"Check\" button below to see how accurate you were.");
      compare = rand.nextInt(101);
      targetField.setText(Integer.toString(compare));
      targetField.setHorizontalAlignment(JTextField.CENTER);
      
      topPanel = new JPanel();
      topPanel.add(restartButton);
      topPanel.add(lblSetSlider);
      topPanel.add(targetField);
      topPanel.add(lblClickCheck);
   } // End of Method
   
   private void buildSlider() { // Start of Method
      slider = new JSlider(JSlider.HORIZONTAL, 0, 100, 0);
      slider.setMajorTickSpacing(100);
      slider.setPaintLabels(true);
   } // End of Method
   
   private void buildBottomPanel() { // Start of Method
      checkButton = new JButton("Check");
      checkButton.addActionListener(new CheckButtonListener());
      
      lblEstimate = new JLabel("Your estimate was");
      estimateField = new JTextField(5);
      estimateField.setHorizontalAlignment(JTextField.CENTER);
      lblResult = new JLabel("which means that you were");
      resultField = new JTextField(10);
      
      bottomPanel = new JPanel();
      bottomPanel.add(checkButton);
      bottomPanel.add(lblEstimate);
      bottomPanel.add(estimateField);
      bottomPanel.add(lblResult);
      bottomPanel.add(resultField);
   } // End of Method
   
   public class RestartButtonListener implements ActionListener { // Start of Class
      public void actionPerformed(ActionEvent e) { // Start of Method
         compare = rand.nextInt(101);
         targetField.setText(Integer.toString(compare));
         estimateField.setText("");
         resultField.setText("");
         slider.setValue(0);
      } // End of Method
   } // End of Class
   
   public class CheckButtonListener implements ActionListener { // Start of Class
      public void actionPerformed(ActionEvent e) { // Start of Method
         estimateField.setText(Integer.toString(slider.getValue()));
         if (slider.getValue() > compare) { // Start of If
            resultField.setText(((slider.getValue()) - compare) + " unit(s) too high.");
         } // End of If
         else if (slider.getValue() < compare) { // Start of Else If
            resultField.setText((compare - (slider.getValue())) + " unit(s) too low.");
         } // End of Else If
         else { // Start of else
            resultField.setText("exactly right!");
         } // End of else
      } // End of Method
   } // End of Class
   
   public static void main(String[] args) { // Start of Main
      new EstimateTest();
   } // End of Main
} // End of Class