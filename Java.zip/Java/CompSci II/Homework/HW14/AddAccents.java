/* Program: 111B HW14 Accent Adder - processes .txt files and adds French language accents
 * Programmer: Peter Hanes
 * Mapping: 	(e)1 - acute accent
 * 				(a/e/i/o/u)2 - circumflex
 * 				(e/u)3 - grave accent
 * 				(e/i)4 - umlaut
 * 				(c)5 - cedilla
 * 				
 */

import java.util.Scanner;
import java.io.*;

public class AddAccents {
	
	public static void main(String[] args) throws IOException {
		
		String inFilename; // Input file name
		String outFilename; // Output file name
		StringBuilder input; // Holds program input
		Scanner keyboard = new Scanner(System.in); // Scanner object
		//char[] lettersWithAccents = new char{ 'a', 'e', 'i', 'o', 'u', 'c' };
		
		System.out.println("Enter the name(.txt) of the file you wish to convert: ");
		inFilename = keyboard.next();
		
		System.out.println("Enter the name(.txt) of the new file: ");
		outFilename = keyboard.next();
		
		File file = new File(inFilename);
		Scanner inFile = new Scanner(file);
		
		PrintWriter outFile = new PrintWriter(outFilename);

		System.out.print("\nProcessing... ");
		
		while (inFile.hasNextLine()) {
			
			input = new StringBuilder(inFile.nextLine());
			
			for (int i = 0; i < input.length(); i++) {
				int j = i-1;
				char chNum = input.charAt(i);
				
				if (isOneToFive(chNum)) {
					if (Character.isAlphabetic(input.charAt(j))) {
						char chLetter = input.charAt(j);
						
						// if statements or for loops
						if(chLetter == 'e' && chNum == '1')
							input.replace(j, i+1, "�");
						
						
					}
				} // if (isOneToFive(c))
			} // for1
			
			outFile.println(input);
			
		} // while (inFile.hasNextLine())
		
		System.out.println("Done. \n");
		
		inFile.close();
		outFile.close();
		keyboard.close();
	} // main()
	
	public static boolean isOneToFive(char ch) {
		if (ch=='1' || ch=='2' || ch=='3' || ch=='4' || ch=='5')
			return true;
		else return false;
	} // hasAccent()
	
} // AddAccents class
