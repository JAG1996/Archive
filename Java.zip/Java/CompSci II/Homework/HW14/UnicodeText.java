// Here are some samples of how to deal with Unicode or ASCII 
// characters that are not on the standard US keyboard. 
   public class UnicodeText
   {//Start of class
      public static void main(String[] args)
      {//Start of main
         char c1;
         char c2;
         char c3;
         char c4;
         
         c1 = 241;
         c2 = 0xF1;  //hex F1 = decimal 241'
         c3 = '�'; // Typed by holding down ALT while typing 00241 on the numeric keypad. 
         c4 = '\u00F1';
         System.out.println(c1 + "  m" + c2 + "o  " + c3 + "  " + c4); 

         c1 = 209;
         c2 = 0xD1;   //hex D1 = decimal 209.
         c3 = '�'; // Typed by holding down ALT while typing 00209 on the numeric keypad. 
         c4 = '\u00D1';
         System.out.println(c1 + "  M" + c2 + "O  " + c3 + "  " + c4); 

         // These methods also work for characters that are on the US keyboard.
         c1 = 66;
         c2 = 0x42;  //hex 42 = decimal 66.
         c3 = 'B'; // Typed by holding down ALT while typing 0066 on the numeric keypad. 
         c4 = '\u0042';
         System.out.println(c1 + "  M" + c2 + "O  " + c3 + "  " + c4); 
         
      }//End of main
   }//End of class