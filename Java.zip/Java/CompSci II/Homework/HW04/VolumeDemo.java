   import java.util.Scanner;

   public class VolumeDemo
   {//Start of class
      public static void main(String[] args)
      {//Start of main
         Scanner keyboard = new Scanner(System.in);
         int shape;
         
         System.out.println("What do you want to calculate the volume of? ");
         System.out.println("If the volume of a sphere .... enter 1");
         System.out.println("If the volume of a cylinder .. enter 2");
         System.out.println("If the volume of a block .. .. enter 3");
         System.out.print(">>>> ");
         shape = keyboard.nextInt();
         
         if (shape == 1)
         {//Start of sphere
            System.out.print("What is the radius of the sphere? ");
            double radius = keyboard.nextDouble();
            double volume = Volume.getVolume(radius);
            System.out.println("The volume of the sphere is " + volume + ".");
         }//End of sphere

         if (shape == 2)
         {//Start of cylinder
            System.out.print("What is the radius of the cylinder? ");
            double radius = keyboard.nextDouble();
            System.out.print("What is the height of the cylinder? ");
            double height = keyboard.nextDouble();
            double volume = Volume.getVolume(radius, height);
            System.out.println("The volume of the cylinder is " + volume + ".");
         }//End of cylinder

         if (shape == 3)
         {//Start of block
            System.out.print("What is the length of the block? ");
            double length = keyboard.nextDouble();
            System.out.print("What is the width of the block? ");
            double width = keyboard.nextDouble();
            System.out.print("What is the height of the block? ");
            double height = keyboard.nextDouble();
            double volume = Volume.getVolume(length, width, height);
            System.out.println("The volume of the block is " + volume + ".");
         }//End of block

      }//End of main
   }//End of class