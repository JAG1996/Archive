public class Volume
{// Start of class

   public static double getVolume(double radius)
   {//Start of 'getVolume' method
      return ((4.0/3.0) * Math.PI * (radius * radius * radius));
   }//End of 'getVolume' method
   
   public static double getVolume(double length, double width, double height)
   {//Start of 'getVolume' method
      return (length * width * height);
   }//End of 'getVolume' method
   
   public static double getVolume(double radius, double height)
   {//Start of 'getVolume' method
      return (Math.PI * radius * radius * height);
   }//End of 'getVolume' method

}// End of class