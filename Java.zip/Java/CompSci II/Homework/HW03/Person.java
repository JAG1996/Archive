public class Person
{// Start of class
        
   private String name = "";   
   private String address = "";
   private int age = 0;
   private String phone = "";
   
   public Person()
   {//Start of 'Person' method
      name = "";
      address = "";
      age = 0;
      phone = "";
   }//End of 'Person' method
   
   public Person(String myName, String myAddress, int myAge, String myPhone)
   {//Start of 'Person' method
      name = myName;
      address = myAddress;
      age = myAge;
      phone = myPhone;
   }//End of 'Person' method

   public void setName(String myName)
   {//Start of 'setName' method
      name = myName;
   }//End of 'setName' method
   
   public void setAddress(String myAddress)
   {//Start of 'setAddress' method
      address = myAddress;
   }//End of 'setAddress' method
   
   public void setAge(int myAge)
   {//Start of 'setAge' method
      age = myAge;
   }//End of 'setAge' method
   
   public void setPhone(String myPhone)
   {//Start of 'setPhone' method
      phone = myPhone;
   }//Emd of 'setPhone' method
   
   public String getName()
   {//Start of 'getName' method
      return name;
   }//End of 'getName' method
   
   public String getAddress()
   {//Start of 'getAddress' method
      return address;
   }//End of 'getAddress' method
   
   public int getAge()
   {//Start of 'getAge' method
      return age;
   }//End of 'getAge' method
   
   public String getPhone()
   {//Start of 'getPhone' method
      return phone;
   }//End of 'getPhone' method

}// End of class