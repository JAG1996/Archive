public class InvalidPayRate extends Exception
{//Start of Class
   public InvalidPayRate()
   {//Start of Constructor
      super("ERROR: Negative pay rate.");
   }//End of Constructor
}//End of Class