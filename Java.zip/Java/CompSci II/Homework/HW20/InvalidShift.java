public class InvalidShift extends Exception
{//Start of Class
   public InvalidShift()
   {//Start of Constructor
      super("ERROR: Invalid shift number.");
   }//End of Constructor
}//End of Class