public class InvalidEmployeeNumber extends Exception
{//Start of Class
   public InvalidEmployeeNumber()
   {//Start of Constructor
      super("ERROR: Invalid employee number.");
   }//End of Constructor
}//End of Class