import java.util.Random;

public class Coin
{// Start of class

   private int sideUp;
   private double value;
   
   public Coin(double v)
   {//Start of 'Coin' method
      value = v;
      toss();
   }//End of 'Coin' method
   
   public void toss()
   {//Start of 'toss' method
      Random rand = new Random();
      sideUp = rand.nextInt(2);
   }//End of 'toss' method
   
   public double getContribution()
   {//Start of 'getContribution' method
      return sideUp * value;
   }//End of 'getContribution' method
   
}// End of class