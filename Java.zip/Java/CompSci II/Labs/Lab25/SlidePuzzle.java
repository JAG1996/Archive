import javax.swing.JFrame;

public class SlidePuzzle { // Start of Class
   public static void main(String[] args) { // Start of Main
      JFrame window = new JFrame("Slide Puzzle");
      window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      
      window.setContentPane(new SlidePuzzleGUI());
      
      window.pack();
      window.setVisible(true);
      window.setResizable(false);
   } // End of Main
} // End of Class