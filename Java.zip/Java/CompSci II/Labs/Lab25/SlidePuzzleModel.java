import java.util.Random;
import javax.swing.*;

class SlidePuzzleModel 
{//Start of public class
   
   private Tile[][] contents;  // All tiles.
   private Tile     emptyTile; // The empty space.
   
   public SlidePuzzleModel() 
   {//Start of constructor
      contents = new Tile[4][4];
      reset();               // Initialize and shuffle tiles.
   }//End of constructor

   
   String getFace(int row, int col) 
   {
      return contents[row][col].getFace();
   }
   
   
   public void reset() 
   {
      //Reinitialize all of the tiles
      for (int r = 0; r < 4; r++) 
      {
         for (int c = 0; c < 4; c++) 
         {
            int number = (r * 4) + c + 1;
            contents[r][c] = new Tile(r, c, "" + number);
         }
      }
      //--- Set last tile face to null to mark empty space
      emptyTile = contents[3][3];
      emptyTile.setFace(null);
      
      //Move the empty spot around randomly
      Random rand = new Random();
      int re = 3; //Current row of empty spot.
      int ce = 3; //Current column of empty spot.
      boolean upAllowed = true;
      boolean downAllowed = true;
      boolean leftAllowed = true;
      boolean rightAllowed = true;
      
      for (int n = 1; n <= 100; n++)
      {//Move the empty tile around.
         String choices = "";

         if (upAllowed)
         {
            if (re > 0) choices = choices + "U";
         }
         else
            upAllowed = true;
            
         if (downAllowed)
         {
             if (re < 3) choices = choices + "D";
         }
         else
            downAllowed = true;

         if (leftAllowed)
         {   
            if (ce > 0) choices = choices + "L";
         }
         else
            leftAllowed = true;
         
         if (rightAllowed)
         {      
            if (ce < 3) choices = choices + "R";
         }
         else
            rightAllowed = true;
               
         int numberOfChoices = choices.length();
         int pick = rand.nextInt(numberOfChoices);
         char move = choices.charAt(pick);
         switch (move)
         {//Start of switch
            case 'U':
               exchangeTiles(re, ce, re - 1, ce);
               re--; 
               downAllowed = false;       
               break;            
            case 'D':
               exchangeTiles(re, ce, re + 1, ce);
               re++;
               upAllowed = false;        
               break;            
            case 'L':
               exchangeTiles(re, ce, re, ce - 1);
               ce--;
               rightAllowed = false;        
               break;            
            case 'R':
               exchangeTiles(re, ce, re, ce + 1);
               ce++;
               leftAllowed = false;        
               break;            
         }//End of switch
         
      }//End of the for loop
      return;
   }//end reset
   
   
   //==================================================== moveTile
   // Move a tile to empty position beside it, if possible.
   // Return true if it was moved, false if not legal.
   public boolean moveTile(int r, int c) 
   {
      boolean moved = false;
      
      //--- It's a legal move if the empty cell is next to it.
      moved = checkEmpty(r, c, -1, 0) || checkEmpty(r, c, 1, 0)
            || checkEmpty(r, c, 0, -1) || checkEmpty(r, c, 0, 1);
      
      return moved;            
   }//end moveTile
   
   
   //================================================== checkEmpty
   // Check to see if there is an empty position beside tile.
   // Return true and exchange if possible, else return false.
   private boolean checkEmpty(int row, int col, int rowChange, int colChange) 
   {
      boolean exchanged;
      int rowNeighbor = row + rowChange;
      int colNeighbor = col + colChange;
      //--- Check to see if this neighbor is on board and is empty.
      if (
            isLegalRowCol(rowNeighbor, colNeighbor)  && 
             contents[rowNeighbor][colNeighbor] == emptyTile
         ) 
      {
         exchangeTiles(row, col, rowNeighbor, colNeighbor);
         exchanged = true;
      }
      else
      {
         exchanged = false;
      }
      
      return exchanged;
   }//end checkEmpty
   
   
   //=============================================== isLegalRowCol
   // Check for legal row, col
   public boolean isLegalRowCol(int r, int c) 
   {
      return (r >= 0) && (r < 4) && (c >= 0) && (c < 4);
   }//end isLegalRowCol
   
   
   //=============================================== exchangeTiles
   // Exchange two tiles.
   private void exchangeTiles(int r1, int c1, int r2, int c2) 
   {
      Tile temp = contents[r1][c1];
      contents[r1][c1] = contents[r2][c2];
      contents[r2][c2] = temp;
   }//end exchangeTiles
       
   
   //=================================================== isGameOver
   public boolean isGameOver() 
   {
      for (int r = 0; r < 4; r++) 
      {
         for (int c = 0; c < 4; c++) 
         {
            Tile trc = contents[r][c];
            if (!trc.isInFinalPosition(r, c))
               return false;
         }
      }
      
      //--- Falling thru loop means nothing out of place.
      return true;
   }//end isGameOver
}//end class SlidePuzzleModel
