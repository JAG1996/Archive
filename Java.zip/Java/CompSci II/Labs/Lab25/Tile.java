public class Tile { // Start of Class
   private int finalRow;
   private int finalCol;
   private String face;
   
   public Tile(int r, int c, String f) { // Start of Constructor
      finalRow = r;
      finalCol = c;
      face = f;
   } // End of Constructor
   
   public void setFace(String newFace) { // Start of Method
      face = newFace;
   } // End of Method
   
   public String getFace() { // Start of Method
      return face;
   } // End of Method
   
   public boolean isInFinalPosition(int r, int c) { // Start of Method
      return r == finalRow && c == finalCol;
   } // End of Method
} // End of Class