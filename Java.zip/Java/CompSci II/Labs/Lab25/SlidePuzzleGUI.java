import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class SlidePuzzleGUI extends JPanel { // Start of Class
   private GraphicsPanel puzzleGraphics;
   private SlidePuzzleModel puzzleModel;
   
   public SlidePuzzleGUI() { // Start of Constructor
      JButton newGameButton = new JButton("New Game");
      newGameButton.addActionListener(new NewGameAction());
      
      JPanel controlPanel = new JPanel();
      controlPanel.setLayout(new FlowLayout());
      controlPanel.add(newGameButton);
      
      puzzleModel = new SlidePuzzleModel();
      puzzleGraphics = new GraphicsPanel();
      
      this.setLayout(new BorderLayout());
      this.add(controlPanel, BorderLayout.NORTH);
      this.add(puzzleGraphics, BorderLayout.CENTER);
   } // End of Constructor
   
   class GraphicsPanel extends JPanel implements MouseListener { // Start of Inner Class
      private static final int CELL_SIZE = 80;
      private Font biggerFont;
      
      public GraphicsPanel() { // Start of Constructor
         biggerFont = new Font("SanSerif", Font.BOLD, CELL_SIZE/2);
         this.setPreferredSize(new Dimension(CELL_SIZE * 4, CELL_SIZE * 4));
         this.setBackground(Color.BLACK);
         this.addMouseListener(this);
      } // End of Constructor
      
      public void paintComponent(Graphics g) { // Start of Method
         super.paintComponent(g);
         for (int row = 0; row < 4; row++) { // Start of Row For Loop
            for (int col = 0; col < 4; col++) { // Start of Col For Loop
               int x = col * CELL_SIZE;
               int y = row * CELL_SIZE;
               String text = puzzleModel.getFace(row, col);
               if (text != null) { // Start of If
                  g.setColor(Color.GRAY);
                  g.fillRect(x + 2, y + 2, CELL_SIZE - 4, CELL_SIZE - 4);
                  g.setColor(Color.BLACK);
                  g.setFont(biggerFont);
                  g.drawString(text, x + 20, y + (3 * CELL_SIZE) / 4);
               } // End of If
            } // End of Col For Loop
         } // End of Row For Loop
      } // End of Method
      
      public void mousePressed(MouseEvent e) { // Start of Method
         int col = e.getX() / CELL_SIZE;
         int row = e.getY() / CELL_SIZE;
         
         if (puzzleModel.moveTile(row, col)) { // Start of If
            this.repaint();
            if (puzzleModel.isGameOver()) { // Start of If
               JOptionPane.showMessageDialog(null, "Game is over.\ncongradulations. You solved it.");
            } // End of If
         } // End of If
      } // End of method
      
      public void mouseClicked(MouseEvent e) {}
      public void mouseReleased(MouseEvent e) {}
      public void mouseEntered(MouseEvent e) {}
      public void mouseExited(MouseEvent e) {}      
   } // End of Inner Class
   
   public class NewGameAction implements ActionListener { // Start of Inner Class
      public void actionPerformed(ActionEvent e) { // Start of Method
         puzzleModel.reset();
         puzzleGraphics.repaint();
      } // End of Method
   } // End of Inner Class
} // End of Class