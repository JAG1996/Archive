import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class PropertyTax extends JFrame { // Start of Class
   private JPanel panel;
   private JTextField propertyValue;
   private JButton calcButton;
   private JTextField assessedValue;
   private JTextField propertyTax;
   
   private final double ASSESSMENT_RATE = 0.6;
   private final double TAXES_PER_HUNDRED = 0.64;
   
   private final int WINDOW_WIDTH = 360;
   private final int WINDOW_HEIGHT = 130;
   
   public PropertyTax() { // Start of 'no arg' Constructor
      this.setTitle("Property Taxes");
      this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      this.setLayout(new GridLayout(4, 2));
      
      propertyValue = new JTextField(10);
      calcButton = new JButton("Calculate Property Tax");
      calcButton.addActionListener(new CalcButtonListener());
      
      assessedValue = new JTextField(5);
      propertyTax = new JTextField(5);
      
      // Adds controls to the Pane
      this.add(new JLabel("Enter the property value"));
      this.add(propertyValue);
      
      this.add(calcButton);
      this.add(new JLabel("   "));
      
      this.add(new JLabel("Assessed value:"));
      this.add(assessedValue);
      
      this.add(new JLabel("Property Tax:"));
      this.add(propertyTax);
      
      this.setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
      this.setVisible(true);
   } // End of 'no arg' Constructor

   private class CalcButtonListener implements ActionListener { // Start of Class
      public void actionPerformed(ActionEvent e) { // Start of Method
         double actualValue;
         double assessmentValue;
         double tax;
         
         try { // Start of Try
            actualValue = Double.parseDouble(propertyValue.getText());
         } // End of Try
         catch (Exception e2) { // Start of Catch
            actualValue = 0.0;
         } // End of Catch
         
         assessmentValue = actualValue * ASSESSMENT_RATE;
         tax = (assessmentValue / 100.0) * TAXES_PER_HUNDRED;
         
         assessedValue.setText(String.format("$%,.2f", assessmentValue));
         propertyTax.setText(String.format("$%,.2f", tax));         
      } // End of Method
   } // End of Class

   public static void main(String[] args) { // Start of Main
      new PropertyTax();
   } // End of Main
} // End of Class