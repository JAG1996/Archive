public class RoomDimension
{// Start of class

   private double length, width;
   
   public RoomDimension(double len, double w)
   {//Start of method
      this.length = len;
      this.width = w;
   }//End of method

   public double getLength()
   {//Start of method
      return length;
   }//End of method
   
   public double getWidth()
   {//Start of method
      return width;
   }//End of method
   
   public double getArea()
   {//Start of method
      return length * width;
   }//End of method
   
   public String toString()
   {//Start of method
      return "Length: " + this.length + " Width: " + width + "  Area: " + getArea();
   }//End of method

}// End of class