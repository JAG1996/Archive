import java.text.DecimalFormat;

public class RoomCarpet
{// Start of class

   private RoomDimension size;
   private double carpetCost;
   
   public RoomCarpet(RoomDimension dim, double cost)
   {//Start of method
      this.size = new RoomDimension(dim.getLength(), dim.getWidth());
      carpetCost = cost;
   }//End of method
   
   public double getTotalCost()
   {//Start of method
      return carpetCost * size.getArea();
   }//End of method
   
   public String toString()
   {//Start of method
      DecimalFormat dollar = new DecimalFormat("#,##0.00");
      
      String str = "Room dimension:\n" + size + "\nCarpet cost: $" + dollar.format(getTotalCost());
      
      return str;
   }//End of method

}// End of class