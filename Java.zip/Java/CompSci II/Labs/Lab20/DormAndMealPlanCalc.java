import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/* 
               Developed by Jacob Garrett
                                                          */

public class DormAndMealPlanCalc extends JFrame { // Start of Class
   private String[] dormNames = { "Allen Hall", 
                                  "Pike Hall", 
                                  "Farthing Hall",
                                  "University Suites" };
                                  
   private double[] dormCost = {  1500.00,       
                                  1600.00,     
                                  1200.00,        
                                  1800.00 };
                                  
   private String[] mealPlans = { "7 meals per week", 
                                  "14 meals per week", 
                                  "unlimited meals per week" };
                                  
   private double[] mealCost = { 560.00, 
                                 1095.00, 
                                 1500.00 };
                                 
   private JComboBox<String> dormCombo;
   private JComboBox<String> mealCombo;
   
   private JButton calcButton;
   private JButton exitButton;
   
   private JPanel dormPanel;
   private JPanel mealPanel;
   private JPanel buttonPanel;
   
   private JTextField chargesBox;
   
   public DormAndMealPlanCalc() { // Start of Constructor
      setTitle("Dorm and Meal Plan Calculator");
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      
      buildDormPanel();
      buildMealPanel();
      buildButtonPanel();
      
      this.add(dormPanel, BorderLayout.NORTH);
      this.add(mealPanel, BorderLayout.CENTER);
      this.add(buttonPanel, BorderLayout.SOUTH);
      
      this.pack();
      this.setVisible(true);
   } // End of Constructor
   
   private void buildDormPanel() { // Start of Method
      JLabel dormMsg = new JLabel("Select a dorm: ");
      dormCombo = new JComboBox<String>(dormNames);
      
      dormPanel = new JPanel();
      dormPanel.add(dormMsg);
      dormPanel.add(dormCombo);
   } // End of Method
   
   private void buildMealPanel() { // Start of Method
      JLabel mealMsg = new JLabel("Select a meal plan: ");
      mealCombo = new JComboBox<String>(mealPlans);
      
      mealPanel = new JPanel();
      mealPanel.add(mealMsg);
      mealPanel.add(mealCombo);   
   } // End of Method
   
   private void buildButtonPanel() { // Start of Method
      calcButton = new JButton("Calculate Charges");
      calcButton.addActionListener(new CalcButtonListener());
      JPanel cbPanel = new JPanel();
      cbPanel.add(calcButton);
      
      chargesBox = new JTextField(10);
      chargesBox.setHorizontalAlignment(JTextField.CENTER);
      JPanel chargePanel = new JPanel();
      chargePanel.add(chargesBox);
      
      exitButton = new JButton("Exit");
      exitButton.addActionListener(new ExitButtonListener());
      JPanel exPanel = new JPanel();
      exPanel.add(exitButton);
      
      buttonPanel = new JPanel();
      buttonPanel.setLayout(new GridLayout(3, 1));
      buttonPanel.add(cbPanel);
      buttonPanel.add(chargePanel);
      buttonPanel.add(exPanel);
   } // End of Method
   
   private class CalcButtonListener implements ActionListener { // Start of Private Class
      public void actionPerformed(ActionEvent e) { // Start of Method
         int selectedDormIndex;
         int selectedMealPlanIndex;
         double dormCharges;
         double mealCharges;
         double totalCharges;
         
         selectedDormIndex = dormCombo.getSelectedIndex();
         dormCharges = dormCost[selectedDormIndex];
         
         selectedMealPlanIndex = mealCombo.getSelectedIndex();
         mealCharges = mealCost[selectedMealPlanIndex];
         
         totalCharges = dormCharges + mealCharges;
         
         chargesBox.setText("$" + String.format("%,.2f", totalCharges));
      } // End of Method
   } // End of Private Class
   
   private class ExitButtonListener implements ActionListener { // Start of Private Class
      public void actionPerformed(ActionEvent e) { // Start of Method
         System.exit(0);
      } // End of Method
   } // End of Private Class
   
   public static void main(String[] args) { // Start of Main
      new DormAndMealPlanCalc();
   } // End of Main
} // End of Class