import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class CellPhonePackages extends JFrame { // Start of Class
   private JPanel packagePanel;
   private JPanel phonePanel;
   private JPanel optionPanel;
   
   private JTextField packageText;
   private JTextField phoneText;
   private JTextField optionText;
   
   private JMenuBar menuBar;
   
   private JMenu fileMenu;
   private JMenu packageMenu;
   private JMenu phoneMenu;
   private JMenu optionMenu;
   
   private JMenuItem exitItem;
   
   private JRadioButtonMenuItem packageAItem;
   private JRadioButtonMenuItem packageBItem;
   private JRadioButtonMenuItem packageCItem;
   
   private JRadioButtonMenuItem phone100Item;
   private JRadioButtonMenuItem phone110Item;
   private JRadioButtonMenuItem phone200Item;
   
   private JCheckBoxMenuItem voiceMailItem;
   private JCheckBoxMenuItem textMessagingItem;
   
   public CellPhonePackages() { // Start of Constructor
      this.setTitle("Cell Phone Packages");
      this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      
      buildMenuBar();
      this.setJMenuBar(menuBar);
      
      buildPackagePanel();
      buildPhonePanel();
      buildOptionPanel();
      
      this.setLayout(new GridLayout(3,1));
      
      this.add(packagePanel);
      this.add(phonePanel);
      this.add(optionPanel);
      
      this.pack();
      this.setVisible(true);
   } // End of Constructor
   
   private void buildMenuBar() { // Start of Method
      menuBar = new JMenuBar();
      
      buildFileMenu();
      buildPackageMenu();
      buildPhoneMenu();
      buildOptionMenu();
      
      menuBar.add(fileMenu);
      menuBar.add(packageMenu);
      menuBar.add(phoneMenu);
      menuBar.add(optionMenu);
   } // End of Method
   
   private void buildFileMenu() { // Start of Method
      exitItem = new JMenuItem("Exit");
      exitItem.addActionListener(new ExitListener());
         
      fileMenu = new JMenu("File");
      
      fileMenu.add(exitItem);
      } // End of Method
      
      private void buildPackageMenu() { // Start of Method
         packageMenu = new JMenu("Package");
         
         packageAItem = new JRadioButtonMenuItem("300 minutes", true);
         packageAItem.addActionListener(new PackageListener());

         packageBItem = new JRadioButtonMenuItem("800 minutes");
         packageBItem.addActionListener(new PackageListener());

         packageCItem = new JRadioButtonMenuItem("1500 minutes");
         packageCItem.addActionListener(new PackageListener());
         
         ButtonGroup group = new ButtonGroup();
         group.add(packageAItem);
         group.add(packageBItem);
         group.add(packageCItem);
         
         packageMenu.add(packageAItem);
         packageMenu.add(packageBItem);
         packageMenu.add(packageCItem);         
      } // End of Method
      
      private void buildPhoneMenu() { // Start of Method
         phoneMenu = new JMenu("Phone");
         
         phone100Item = new JRadioButtonMenuItem("Model 100", true);
         phone100Item.addActionListener(new PhoneListener());
         
         phone110Item = new JRadioButtonMenuItem("Model 110");
         phone110Item.addActionListener(new PhoneListener());
         
         phone200Item = new JRadioButtonMenuItem("Model 200");
         phone200Item.addActionListener(new PhoneListener());
         
         ButtonGroup group = new ButtonGroup();
         group.add(phone100Item);
         group.add(phone110Item);
         group.add(phone200Item);
         
         phoneMenu.add(phone100Item);
         phoneMenu.add(phone110Item);
         phoneMenu.add(phone200Item);                  
      } // End of Method
      
      private void buildOptionMenu() { // Start of Method
         optionMenu = new JMenu("Options");
         
         voiceMailItem = new JCheckBoxMenuItem("Voice Mail", false);
         voiceMailItem.addActionListener(new OptionListener());
         
         textMessagingItem = new JCheckBoxMenuItem("Text Messaging");
         textMessagingItem.addActionListener(new OptionListener());
         
         optionMenu.add(voiceMailItem);
         optionMenu.add(textMessagingItem);
      } // End of Method
      
      private void buildPackagePanel() { // Start of Method
         packagePanel = new JPanel();
         JLabel packageMsg = new JLabel("Package Cost:");
         packageText = new JTextField(10);
         packageText.setText("$45.00 per month");
         packageText.setEditable(false);
         packagePanel.add(packageMsg);
         packagePanel.add(packageText);
      } // End of Method
      
      private void buildPhonePanel() { // Start of Method
         phonePanel = new JPanel();
         JLabel phoneMsg = new JLabel("Phone Cost:");
         
         phoneText = new JTextField(10);
         phoneText.setText("$31.75");
         phoneText.setEditable(false);
         
         phonePanel.add(phoneMsg);
         phonePanel.add(phoneText);
      } // End of Method
      
      private void buildOptionPanel() { // Start of Method
         optionPanel = new JPanel();
         JLabel optionMsg = new JLabel("Options Cost:");
         
         optionText = new JTextField(10);
         optionText.setText("0.00");
         optionText.setEditable(false);
         
         optionPanel.add(optionMsg);
         optionPanel.add(optionText);
      } // End of Method
      
      private class PackageListener implements ActionListener { // Start of Private Class
         public void actionPerformed(ActionEvent e) { // Start of Method
            if (packageAItem.isSelected()) { // Start of If
               packageText.setText("$45.00 per month");
            } // End of If
            
            if (packageBItem.isSelected()) { // Start of If
               packageText.setText("$65.00 per month");
            } // End of If
            
            if (packageCItem.isSelected()) { // Start of If
               packageText.setText("$99.00 per month");
            } // End of If
         } // End of Method
      } // End of Private Class
      
      private class PhoneListener implements ActionListener { // Start of Private Class
         public void actionPerformed(ActionEvent e) { // Start of Method
            if (phone100Item.isSelected()) { // Start of If
               packageText.setText("$31.75");
            } // End of If
            
            if (phone110Item.isSelected()) { // Start of If
               packageText.setText("$52.95");
            } // End of If
            
            if (phone200Item.isSelected()) { // Start of If
               packageText.setText("$105.95");
            } // End of If
         } // End of Method
      } // End of Private Class
      
      private class OptionListener implements ActionListener { // Start of Private Class
         public void actionPerformed(ActionEvent e) { // Start of Method
            if (!voiceMailItem.isSelected() && !textMessagingItem.isSelected()) { // Start of If
               optionText.setText("$0.00 per month");
            } // End of If
            
            if (voiceMailItem.isSelected() && !textMessagingItem.isSelected()) { // Start of If
               optionText.setText("$5.00 per month");
            } // End of If
            
            if (!voiceMailItem.isSelected() && textMessagingItem.isSelected()) { // Start of If
               optionText.setText("$10.00 per month");
            } // End of If
            
            if (voiceMailItem.isSelected() && textMessagingItem.isSelected()) { // Start of If
               optionText.setText("$15.00 per month");
            } // End of If
         } // End of Method
      } // End of Private Class
      
      private class ExitListener implements ActionListener { // Start of Private Class
         public void actionPerformed(ActionEvent e) { // Start of Method
            System.exit(0);
         } // End of Method
      } // End of Private Class
      
      public static void main(String[] args) { // Start of Main
         new CellPhonePackages();
      } // End of Main
} // End of Class