import java.util.Scanner;

public class TranslateTelephoneNumbers
{//Start of Class
   public static void main(String[] args)
   {//Start of main
      Scanner keyboard = new Scanner(System.in);
      
      System.out.print("Enter a phone number containing letters: ");
      String encryption = keyboard.nextLine();
      int length = encryption.length();
      boolean valid = false;
      StringBuilder telephoneNumber = new StringBuilder("(");
      int digitCount = 0;
      
      for (int n = 0; n < length; n++)
      {//Start of for loop
         char c = Character.toUpperCase(encryption.charAt(n));
         if (Character.isLetter(c))
         {//Start of 'isLetter' if
            switch (c)
            {//Start of switch
               case 'A':
               case 'B':
               case 'C':
                  c = '2';
                  break;
               case 'D':
               case 'E':
               case 'F':
                  c = '3';
                  break;
               case 'G':
               case 'H':
               case 'I':
                  c = '4';
                  break;
               case 'J':
               case 'K':
               case 'L':
                  c = '5';
                  break;
               case 'M':
               case 'N':
               case 'O':
                  c = '6';
                  break;
               case 'P':
               case 'Q':
               case 'R':
               case 'S':
                  c = '7';
                  break;
               case 'T':
               case 'U':
               case 'V':
                  c = '8';
                  break;
               default:
                  c = '9';
            }//End of switch
         }//End of 'isLetter' if
         
         if (Character.isDigit(c))
         {//Start of 'isDigit' if
            digitCount++;
            switch (digitCount)
            {//Start of switch
               case 3: 
                  telephoneNumber.append(c);
                  telephoneNumber.append(")");
                  break;
               case 6: 
                  telephoneNumber.append(c);
                  telephoneNumber.append("-");
                  break;
               default:
                  telephoneNumber.append(c);
            }//End of switch
            if (digitCount == 10)
            {//Start of 'digitCount' if
               valid = true;
               break;
            }//End of 'digitCount' if
         }//End of 'isDigit' if
      }//End of for loop
      if (valid)
      {//Start of 'valid' if
         System.out.println("The numeric version of that is "
                        + telephoneNumber + ".");
      }//End of 'valid' if
      else
      {//Start of else
         System.out.println("No valid telephone number was found.");
      }//End of else   
   }//End of main
}//End of Class