import java.util.Scanner;

public class CryptoHelper
{// Start of class
   public static void main(String[] args)
   {// Start of main
   
      Scanner keyboard = new Scanner(System.in);
   
      System.out.println("Please enter the cryptogram.");
      String cryptoText = keyboard.nextLine();
      cryptoText = cryptoText.toUpperCase();
      int length = cryptoText.length();
      
      char[] crypto = new char[length];
      char[] solution = new char[length];
      
      for (int n = 0; n < length; n++)
      {//Start of 'length' for
         char t = cryptoText.charAt(n);
         crypto[n]= t;
         if (t >= 'A' && t <= 'Z')
         {//Start of if
            solution[n] = ' ';
         }//End of if
         else
         {//Start of else
            solution[n] = t;
         }//End of else
      }//End of 'length' for
      
      while (true)
      {//Start of while
      
         System.out.println();
         System.out.print("Cryptogram: ");
         for (int n = 0; n < length; n++)
         {//Start of for
            System.out.print(crypto[n]);
         }//End of for
         System.out.println();
         
         System.out.print("Solution:   ");
         for (int n = 0; n < length; n++)
         {//Start of for
            System.out.print(solution[n]);
         }//End of for
         System.out.println();
         
         System.out.print("Enter the character to decrypt (or 9 to quit):");
         String nextCryptoString = keyboard.nextLine();
         char nextCryptoChar = nextCryptoString.toUpperCase().charAt(0);
         if (nextCryptoChar == '9')
         {//Start of if
            break;
         }//End of if
         
         System.out.print("What letter should \"" + nextCryptoChar + "\" become in the solution? ");
         String nextSolutionString = keyboard.nextLine();
         char nextSolutionChar = nextSolutionString.toUpperCase().charAt(0);
         
         for(int n = 0; n < length; n++)
         {//Start of for
            if (solution[n] == nextSolutionChar)
            {//Start of if
               solution[n] = ' ';
            }//End of if
            if (crypto[n] == nextCryptoChar)
            {//Start of if
               solution[n] = nextSolutionChar;
            }//End of if
         }//End of for
         
      }//End of while
      
   }// End of main
}// End of class