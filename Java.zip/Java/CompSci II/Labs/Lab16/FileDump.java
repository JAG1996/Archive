import java.util.Scanner;
import java.io.*;

public class FileDump
{// Start of class
   public static void main(String[] args) throws IOException
   {//Start of main
      Scanner keyboard = new Scanner(System.in);
      
      System.out.print("Enter name of file: ");
      String inFileName = keyboard.nextLine();
      
      boolean eof = false;
      
      FileInputStream inFile = new FileInputStream(inFileName);
      DataInputStream inData = new DataInputStream(inFile);
      
      byte[] inputBytes = new byte[48];
      int ibCount = 0;
      
      while (!eof && ibCount < 48)
      {//Start of While Loop
         try
         {//Start of Try
            inputBytes[ibCount] = inData.readByte();
            ibCount++;
         }//End of Try
         catch (Exception e)
         {//Start of Catch
            eof = true;
         }//End of Catch
      }//End of While Loop
      inData.close();
      
      System.out.println("Disp | <------------ Bytes in Hexadecimal -----------> | <--- ASCII ---->");
      
      for (int row = 0; row <= 2; row++)
      {//Start of For Loop
         if (ibCount > row * 16)
         {//Start of If
            System.out.printf(" %02X  |", row * 16);
            for (int n = 0; n < 16; n++)
            {//Start of For Loop
               int s = n + (row * 16);
               if (s < ibCount)
               {//Start of If
                  System.out.printf(" %02X", inputBytes[s]);
               }//End of If
               else
               {//Start of Else
                  System.out.print("   ");
               }//End of Else
            }//End of For Loop
            System.out.print(" | ");
            for (int n = 0; n < 16; n++)
            {//Start of For Loop
               int s = n + (row * 16);
               if (s < ibCount)
               {//Start of If
                  if (Character.isISOControl(inputBytes[s]))
                  {//Start of If
                     System.out.print(".");
                  }//End of If
                  else
                  {//Start of Else
                     if (inputBytes[s] > 0)
                     {//Start of If
                        System.out.printf("%c", (char) inputBytes[s]);
                     }//End of If
                     else
                     {//Start of Else
                        System.out.printf("%c", 256 - inputBytes[s]);
                     }//End of Else
                  }//End of Else
               }//End of If
            }//End of For Loop
            System.out.println();
         }//End of If
      }//End of For Loop
   }//End of main
}// End of class