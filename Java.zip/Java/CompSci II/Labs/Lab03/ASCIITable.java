public class ASCIITable
{// Start of class
   public static void main(String[] args)
   {// Start of main

      System.out.println("This is the ASCII character set.");
      System.out.println();
      System.out.print("    |");
      
      for (int c = 0; c <= 15; c++)
      {//Start of for
         System.out.printf(" %1X_ |", c);
      }//End of for
      System.out.println();
      
      for (int c = 0; c <= 16; c++)
      {//Start of for
         System.out.print("----+");
      }//End of for
      System.out.println();
      
      for (int r = 0; r <= 15; r++)
      {//Start of 'r' for
         System.out.printf(" _%1X |", r);
         for (int c = 0; c <= 15; c++)
         {//Start of 'c' for
            char ch = (char) ((c * 16) + r);
            if (Character.isISOControl(ch))
            {//Start of if
               System.out.print(" cc |");
            }//End of if
            else
            {//Start of else
               System.out.print("  " + ch + " |");
            }//End of else
         }//End of 'c' for
         System.out.println();
      }//End of 'r' for
            
   }// End of main
}// End of class