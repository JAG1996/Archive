public class BankAccount
{//Start of Class
   private double balance;
   private int numDeposits;
   private int numWithdrawals;
   private double interestRate;
   private double monthlyServiceCharges;
   
   public BankAccount(double bal, double iR, double mon)
   {//Start of Method
      balance = bal;
      interestRate = iR;
      monthlyServiceCharges = mon;
      numDeposits = 0;
      numWithdrawals = 0;
   }//End of Method
   
   public void deposit(double amount)
   {//Start of Method
      balance += amount;
      numDeposits++;
   }//End of Method
   
   public void withdraw(double amount)
   {//Start of Method
      balance -= amount;
      numWithdrawals++;
   }//End of Method
   
   private void calcInterest()
   {//Start of Method
      double monthlyInterestRate = interestRate / 12;
      double monthInterest = balance * monthlyInterestRate;
      balance += monthInterest;
   }//End of Method
   
   public void monthlyProcess()
   {//Start of Method
      balance -= monthlyServiceCharges;
      calcInterest();
      numDeposits = 0; 
      numWithdrawals = 0;
   }//End of Method
   
   public void setMonthlyServiceCharges(double m)
   {//Start of Method
      monthlyServiceCharges = m;
   }//End of Method
   
   public double getBalance()
   {//Start of Method
      return balance;
   }//End of Method
   
   public int getNumDeposits()
   {//Start of Method
      return numDeposits;
   }//End of Method
   
   public int getNumWithdrawals()
   {//Start of Method
      return numWithdrawals;
   }//End of Method
   
   public double getInterestRate()
   {//Start of Method
      return interestRate;
   }//End of Method
   
   public double getMonthlyServiceCharges()
   {//Start of Method
      return monthlyServiceCharges;
   }//End of Method
}//End of Class