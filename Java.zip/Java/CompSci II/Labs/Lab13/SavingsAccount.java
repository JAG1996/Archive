public class SavingsAccount extends BankAccount
{//Start of Class
   private boolean status;
   
   public SavingsAccount(double bal, double iR, double mon)
   {//Start of Constructor
      super(bal, iR, mon);
      if (bal < 25.0)
      {//Start of If
         status = false;
      }//End of If
      else
      {//Start of Else
         status = true;
      }//End of Else
   }//End of Constructor
   
   @Override
   public void withdraw(double amount)
   {//Start of Method
      if (status)
      {//Start of If
         super.withdraw(amount);
         if (getBalance() < 25.0)
         {//Start of Nested If
            status = false;
         }//End of Nested If
      }//End of If
   }//End of Method
   
   @Override
   public void deposit(double amount)
   {//Start of Method
      super.deposit(amount);
      if (getBalance() < 25.0)
      {//Start of If
         status = false;
      }//End of If
      else
      {//Start of Else
         status = true;
      }//End of Else
   }//End of Method
   
   @Override
   public void monthlyProcess()
   {//Start of Method
      double msc;
      
      if (getNumWithdrawals() > 4)
      {//Start of If
         msc = getMonthlyServiceCharges();
         setMonthlyServiceCharges(msc + (getNumWithdrawals() - 4));
         super.monthlyProcess();
         setMonthlyServiceCharges(msc);
      }//End of If
      else
      {//Start of Else
         super.monthlyProcess();
      }//End of Else
   }//End of Method
}//End of Class