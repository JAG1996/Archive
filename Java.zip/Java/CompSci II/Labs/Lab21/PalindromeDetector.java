public class PalindromeDetector { // Start of Class
   public static void main(String[] args) { // Start of Main
      String[] testStrings = { "Able was I ere I saw Elba",
                               "Four score and seven years ago",
                               "Now is the time for all good men",
                               "Desserts I stressed",
                               "Ask not what your country can do for you",
                               "Kayak"
                              };
                              
      for (int n = 0; n < testStrings.length; n++) { // Start of For Loop
         System.out.print("\"" + testStrings[n] + "\"");
         if (isPalindrome(testStrings[n].toUpperCase())) { // Start of If
            System.out.println(" is a palindrome.");
         } // End of If
         else { // Start of Else
            System.out.println(" is not a palindrome.");
         } // End of Else
      } // End of For Loop
   } // End of Main
   
   public static boolean isPalindrome(String str) { // Start of Method
      boolean status = false;
         
      if (str.length() <= 1) { // Start of If
         status = true;
      } // End of If
      else { // Start of Else
         int last = str.length() - 1;
         if (str.charAt(0) == str.charAt(last)) { // Start of nested If 1
            String shorter = str.substring(1, last);
            status = isPalindrome(shorter);
         } // End of nested If 1
         else { // Start of nested Else 1
            status = false;
         } // End of nested Else 1
      } // End of Else
      
      for (int w = 0;w <= level; w++) {
         System.out.print("<<<");
      }
      System.out.println(" Leaving with \"" + str + "\" and status " + status);
      return status;
   } // End of Method
} // End of Class