import java.util.ArrayList;
import java.util.Random;

public class Solitaire
{// Start of class

   public static final int SIZE = 5;

   public static void main(String[] args)
   {// Start of main
   
      ArrayList<Integer> piles = createPiles();
      printPiles(piles);
      
      while(!finalConfig(piles))
      {// while
         rearrangePiles(piles);
         printPiles(piles);
      }// while
      System.out.println("Done");
      
   }// End of main
   
   public static ArrayList<Integer> createPiles()
   {// method
      ArrayList<Integer> p = new ArrayList<Integer>();
      Random rand = new Random();
      int numberOfCoins = SIZE * (SIZE + 1) / 2;
      
      while(numberOfCoins > 0)
      {// start while
         int temp = 1 + rand.nextInt(numberOfCoins);
         p.add(temp);
         numberOfCoins = numberOfCoins - temp;
      }// end while
      
      return p;
   }// method
   
   public static void printPiles(ArrayList<Integer> p)
   {// start method
      System.out.print("The piles are: ");
      for(int n : p)
      {// start for
         System.out.printf("%2d ", n);
      }// end for
      System.out.println();
   }// end method
   
   public static boolean finalConfig(ArrayList<Integer> p)
   {// start method
      if (p.size() != SIZE) return false;
      for(int n = 0; n < SIZE; n++)
      {//Start of for
         if (p.get(n) != (n + 1)) return false;
      }//End of for
      
      return true;
   }// end method
   
   
   public static void rearrangePiles(ArrayList<Integer> p)
   {//Start of method
      int sizeOfAddedPiles = p.size();
      
      for(int n = p.size() - 1; n >= 0; n--)
      {//Start of for
         int c = p.get(n);
         if (c == 1)
         {//Start of if
            p.remove(n);
         }//End of if
         else
         {//Start of else
            p.set(n, c - 1);
         }//End of else
      }//End of for
      
      p.add(sizeOfAddedPiles);
      
   }//End of method
   
}// End of class