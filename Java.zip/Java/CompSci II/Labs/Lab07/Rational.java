public class Rational 
{//Start of class

   private int num;   // the numerator
   private int den;   // the denominator

   public Rational(int n, int d)
   {//Start of method
      int g = gcd(n, d);
      num = n / g;
      den = d / g;
      if (den < 0)
      {//Start
         num = num * -1;
         den = den * -1;
      }//End
   }//End of method
   
   public Rational plus(Rational that)
   {//Start of method
      int answerNum = (this.num * that.den) + (that.num * this.den);
      int answerDen = this.den * that.den;
      Rational answer = new Rational(answerNum, answerDen);
      return answer;
   }//End of method
   
   public Rational minus(Rational that)
   {//Start of method
      int answerNum = (this.num * that.den) - (that.num * this.den);
      int answerDen = this.den * that.den;
      Rational answer = new Rational(answerNum, answerDen);
      return answer;
   }//End of method
   
   public Rational times(Rational that)
   {//Start of method
      int answerNum = this.num * that.num;
      int answerDen = this.den * that.den;
      Rational answer = new Rational(answerNum, answerDen);
      return answer;
   }//End of method
  
   public Rational dividedBy(Rational that)
   {//Start of method
      int answerNum = this.num * that.den;
      int answerDen = this.den * that.num;
      Rational answer = new Rational(answerNum, answerDen);
      return answer;
   }//End of method
   
   public Rational reciprocal()
   {//Start of method
      return new Rational(this.den, this.num);
   }//End of method
   
   public double value()
   {//Start of method
      double answer = ((double) num) / ((double) den);
      return answer;
   }//End of method
   
   public int compareTo(Rational that)
   {//Start of method
      Rational answer = this.minus(that);
      return answer.num;
   }//End of method
   
   public String toString() 
   {//Start of method
      if (den == 1) 
         return num + "";
      else
         return num + "/" + den; 
   }//End of method

   private int gcd(int a, int b)
   {//Start of method
      a = Math.abs(a);
      b = Math.abs(b);
      while(b > 0)
      {
         int c = a % b;
         a = b;
         b = c;
      }
      return a;
   }//End of method

}//End of class