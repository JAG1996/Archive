public class RationalDemo
{//Start of class
   public static void main(String[] args) 
   {//Start of main
   
      // values
      Rational x = new Rational(3, 4);
      Rational y = new Rational(1, 3);
      Rational z;
      
      // sum
      z = x.plus(y);
      System.out.println(x + "  +  " + y + "  =  " + z);
   
      // difference
      z = x.minus(y);
      System.out.println(x + "  -  " + y + "  =  " + z);

      // product
      z = x.times(y);
      System.out.println(x + "  *  " + y + "  =  " + z);

      // quotient
      z = x.dividedBy(y);
      System.out.println(x + "  /  " + y + "  =  " + z);

      // comparison
      int r = x.compareTo(y);
      if (r < 0) 
         System.out.println(x + "  <  " + y);
      else if (r > 0) 
         System.out.println(x + "  >  " + y);
      else      
         System.out.println(x + "  =  " + y);
      
      // value as a decimal fraction   
      System.out.println(x + "  =  " + x.value());
      System.out.println(y + "  =  " + y.value());
      
      // reciprocals
      System.out.println("The reciprocal of " + x + " is " + x.reciprocal() + ".");
      System.out.println("The reciprocal of " + y + " is " + y.reciprocal() + ".");
   }//End of main
}//End of class