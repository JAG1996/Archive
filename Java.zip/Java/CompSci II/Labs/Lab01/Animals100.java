import java.util.Scanner;

public class Animals100
{// Start of class
   public static void main(String[] args)
   {// Start of main
   
      int solutions = 0;
   
      Scanner keyboard = new Scanner(System.in);
      
      System.out.print("What is the price of a   cow? ");
      double cowPrice = keyboard.nextDouble();
      
      System.out.print("What is the price of a   pig? ");
      double pigPrice = keyboard.nextDouble();
      
      System.out.print("What is the price of a chick? ");
      double chickPrice = keyboard.nextDouble();
      
      System.out.println();
      System.out.println("Solutions");
      
      int cowLimit = (int) (100.00 / cowPrice);
      
      for (int cowCount = 1; cowCount <= cowLimit; cowCount++)
      {//Start of 'cow' for loop
         double spent = cowCount * cowPrice;
         double moneyLeft = 100.00 - spent;
         
         int pigLimit = (int) (moneyLeft / pigPrice);
         for (int pigCount = 1; pigCount <= pigLimit; pigCount++)
         {//Start of 'pig' for loop
            int chickCount = 100 - (cowCount + pigCount);
            double totalCost = (cowCount * cowPrice) + (pigCount * pigPrice) + (chickCount * chickPrice);
            if (totalCost == 100.00)
            {//Start of if
               System.out.printf(" %3d    %3d   %3d\n", cowCount, pigCount, chickCount);
               solutions++;
            }//End of if
         }//End of 'pig' for loop
      }//End of 'cow' for loop
      
      System.out.println();
      System.out.println(solutions + " solutions were found.");
      
   }// End of main
}// End of class