import java.io.*;

public class WriteFixedLengthStrings 
{// Start of class
   public static void main(String[] args) throws IOException
   {//Start of main
      final int RECORDLENGTH = 16;
      String words[] = {"zero", "one", "two", "three", "four", 
                        "five", "six", "seven", "eight", "nine"};
                        
      FileOutputStream fstream = new FileOutputStream("fixed.dat");
      DataOutputStream outputFile = new DataOutputStream(fstream);                
      
      System.out.println("Writing the strings to the file...");
      
      for (int n = 0; n <= 9; n++)
      {//Start of For Loop
         String longString = words[n] + "*            ";
         String record = longString.substring(0, RECORDLENGTH);
         outputFile.writeChars(record);
      }//End of For Loop
      
      System.out.println("Done.");
      
      outputFile.close();
   }//End of main
}// End of class