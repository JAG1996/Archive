import java.util.Scanner;
import java.io.*;

public class ReadRandomStrings
{// Start of class
   public static void main(String[] args) throws IOException
   {//Start of main
      final int RECORDLENGTH = 16;
      final int CHARLENGTH = 2;

      Scanner keyboard = new Scanner(System.in);
      
      RandomAccessFile randomFile = new RandomAccessFile("fixed.dat", "r");
      
      while (true)
      {//Start of While Loop
         System.out.print("Enter record number or -1 to quit: ");
         int r = keyboard.nextInt();
         
         if (r == -1) break;
         
         int bytePosition = r * RECORDLENGTH * CHARLENGTH;
         
         randomFile.seek(bytePosition);
         
         String record = "";
         for (int n = 1; n <= RECORDLENGTH; n++)
         {//Start of For Loop
            char c = randomFile.readChar();
            record += c;
         }//End of For Loop
         System.out.println("> " + record + " <");
      }//End of While Loop
      
      System.out.println("Program terminating at your request.");
   }//End of main
}// End of class