public class Customer extends Person
{// Start of class
   private String customerNumber;
   private boolean mailingList;
   
   public Customer()
   {//Start of no arg Constructor
      super();
      customerNumber = "";
      mailingList = false;
   }//End of no arg Constructor
   
   public Customer(String n, String a, String p, 
                   String c, boolean m)
   {//Start of Constructor
      super(n, a, p);
      customerNumber = c;
      mailingList = m;
   }//End of Constructor
   
   public void setCustomerNumber(String c)
   {//Start of method
      customerNumber = c;
   }//End of method
   
   public void setMailingList(boolean m)
   {//Start of method
      mailingList = m;
   }//End of method
   
   public String getCustomerNumber()
   {//Start of method
      return customerNumber;
   }//End of method
   
   public boolean getMailingList()
   {//Start of method
      return mailingList;
   }//End of method
   
}// End of class