public class Person
{// Start of class
   private String name;
   private String address;
   private String phone;
   
   public Person()
   {//Start of constructor
      name = "";
      address = "";
      phone = "";
   }//End of constructor
   
   public Person(String n, String a, String p)
   {//Start of constructor
      name = n;
      address = a;
      phone = p;
   }//End of constructor
   
   public void setName(String n)
   {//Start of method
      name = n;
   }//End of method
   
   public void setAddress(String a)
   {//Start of method
      address = a;
   }//End of method
   
   public void setPhone(String p)
   {//Start of method
      phone = p;
   }//End of method
   
   public String getName()
   {//Start of method
      return name;
   }//End of method
   
   public String getAddress()
   {//Start of method
      return address;
   }//End of method
   
   public String getPhone()
   {//Start of method
      return phone;
   }//End of method
   
}// End of class