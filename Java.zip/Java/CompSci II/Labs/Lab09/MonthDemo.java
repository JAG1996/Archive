/**
   This program demonstrates a solution to the
   Month Class programming challenge.
*/

public class MonthDemo
{//Start of HW07 class
   public static void main(String[] args)
   {//Start of main
      // Use the no-arg constructor.
      Month m = new Month();
      System.out.println("Month " + m.getMonthNumber() +
                         " is " + m);
      // Set the month number to the values 0 through 12
      // (0 is invalid), and display the resulting month name.
      m.setMonthNumber(5);
      System.out.println("Month " + m.getMonthNumber() + " is " + m);
      
      // Use the 2nd constructor to create two objects.
      Month m1 = new Month(10);
      Month m2 = new Month(5);
      System.out.println("Month " + m1.getMonthNumber() +
                         " is " + m1);
      System.out.println("Month " + m2.getMonthNumber() +
                         " is " + m2);

      // Test for equality.
      if (m1.equals(m2))
         System.out.println(m1 + " and " + m2 + " are equal.");
      else
         System.out.println(m1 + " and " + m2 + " are NOT equal.");

      // Is m1 greater than m2?
      if (m1.greaterThan(m2))
         System.out.println(m1 + " is greater than " + m2);
      else
         System.out.println(m1 + " is NOT greater than " + m2);

      // Is m1 less than m2?
      if (m1.lessThan(m2))
         System.out.println(m1 + " is less than " + m2);
      else
         System.out.println(m1 + " is NOT less than " + m2);


      // Use the 3rd constructor to create three objects.
      Month March = new Month("March");
      Month December = new Month("December");
      Month badMonth = new Month("Bad Month");
      System.out.println("Month " + March.getMonthNumber() +
                         " is " + March);
      System.out.println("Month " + December.getMonthNumber() +
                         " is " + December);
      System.out.println("Month " + badMonth.getMonthNumber() +
                         " is " + badMonth);
   }//End of main
}//End of HW07 class 
   
class Month
{//Start of Month class
   private int monthNumber;
   
   public Month()
   {//Start of method
      monthNumber = 1;
   }//End of method
   
   public Month(int m)
   {//Start of method
      if (m < 1 || m > 12)
      {//Start of if
         monthNumber = 1;
      }//End of if
      else
      {//Start of else
         monthNumber = m;
      }//End of else
   }//End of method
   
   public Month(String name)
   {//Start of method
      if (name.equalsIgnoreCase("January"))
      {//Start of if
         monthNumber = 1;
      }//End of if
      
      else if (name.equalsIgnoreCase("February"))
      {//Start of else if
         monthNumber = 2;
      }//End of else if
      
      else if (name.equalsIgnoreCase("March"))
      {//Start of else if
         monthNumber = 3;
      }//End of else if
      
      else if (name.equalsIgnoreCase("April"))
      {//Start of else if
         monthNumber = 4;
      }//End of else if
      
      else if (name.equalsIgnoreCase("May"))
      {//Start of else if
         monthNumber = 5;
      }//End of else if
      
      else if (name.equalsIgnoreCase("June"))
      {//Start of else if
         monthNumber = 6;
      }//End of else if
      
      else if (name.equalsIgnoreCase("July"))
      {//Start of else if
         monthNumber = 7;
      }//End of else if
      
      else if (name.equalsIgnoreCase("August"))
      {//Start of else if
         monthNumber = 8;
      }//End of else if
      
      else if (name.equalsIgnoreCase("September"))
      {//Start of else if
         monthNumber = 9;
      }//End of else if
      
      else if (name.equalsIgnoreCase("October"))
      {//Start of else if
         monthNumber = 10;
      }//End of else if
      
      else if (name.equalsIgnoreCase("November"))
      {//Start of else if
         monthNumber = 11;
      }//End of else if
      
      else if (name.equalsIgnoreCase("December"))
      {//Start of else if
         monthNumber = 12;
      }//End of else if
      
      else
      {//Start of else if
         monthNumber = 1;
      }//End of else if
      
   }//End of method

   public void setMonthNumber(int m)
   {//Start of method
      if (m < 1 || m > 12)
      {//Start of if
         monthNumber = 1;
      }//End of if
      else
      {//Start of else
         monthNumber = m;
      }//End of else
   }//End of method
   
   public int getMonthNumber()
   {//Start of method
      return monthNumber;
   }//End of method
   
   public String getMonthName()
   {//Start of method
      String name;
      
      switch (monthNumber)
      {//Start of switch
         case 1: name = "January";
         break;
         case 2: name = "February";
         break;
         case 3: name = "March";
         break;
         case 4: name = "April";
         break;
         case 5: name = "May";
         break;
         case 6: name = "June";
         break;
         case 7: name = "July";
         break;
         case 8: name = "August";
         break;
         case 9: name = "September";
         break;
         case 10: name = "October";
         break;
         case 11: name = "November";
         break;
         case 12: name = "December";
         break;
         default: name = "Unknown";
      }//End of switch
      return name;
   }//End of method

   public String toString()
   {//Start of method
      return getMonthName();
   }//End of method
   
   public boolean equals(Month thatMonth)
   {//Start of method
      return (this.monthNumber == thatMonth.monthNumber);
   }//End of method

   public boolean greaterThan(Month thatMonth)
   {//Start of method
      return (this.monthNumber > thatMonth.monthNumber);
   }//End of method

   public boolean lessThan(Month thatMonth)
   {//Start of method
      return (this.monthNumber < thatMonth.monthNumber);
   }//End of method

}//End of Month class