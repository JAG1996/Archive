public class InvalidMonthNameException extends Exception
{//Start of Class
   public InvalidMonthNameException()
   {//Start of Constructor
      super("Invalid name given for the month.");
   }//End of Constructor
   
   public InvalidMonthNameException(String name)
   {//Start of Constructor
      super("Invalid name given for the month: " + name);
   }//End of Constructor
}//End of Class