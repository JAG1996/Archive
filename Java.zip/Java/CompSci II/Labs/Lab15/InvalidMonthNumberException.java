public class InvalidMonthNumberException extends Exception
{//Start of Class
   public InvalidMonthNumberException()
   {//Start of Constructor
      super("Invalid number given for the month.");
   }//End of Constructor
   
   public InvalidMonthNumberException(double number)
   {//Start of Constructor
      super("Invalid number given for the month: " + number);
   }//End of Constructor
}//End of Class