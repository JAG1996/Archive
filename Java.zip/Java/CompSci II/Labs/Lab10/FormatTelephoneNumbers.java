import java.util.Scanner;
import java.io.*;

public class FormatTelephoneNumbers
{//Start of class
   public static void main(String[] args) throws IOException
   {//Start of main
      File file = new File("InputData.txt");
      Scanner inputFile = new Scanner(file);
                
      while (inputFile.hasNext())
      {//Start of while loop
         String inputLine = inputFile.nextLine();
         int length = inputLine.length();
         boolean valid = false;
         StringBuilder telephoneNumber = new StringBuilder("(");
         int digitCount = 0;
         
         for (int n = 0; n < length; n++)
         {//Start of for loop
            char c = inputLine.charAt(n);
            if (Character.isDigit(c))
            {//Start of 'isDigit' if
               digitCount++;
               telephoneNumber.append(c);
               switch(digitCount)
               {//Start of switch
                  case 3: 
                     telephoneNumber.append(")");
                     break;
                  case 6:
                     telephoneNumber.append("-");
                     break;
               }//End of switch
            }//End of 'isDigit' if
            if (digitCount == 10)
            {//Start of 'digitCount' if
               valid = true;
               break;
            }//End of 'digitCount' if
         }//End of for loop
         System.out.println("In this input line >>> " + inputLine);
         if (valid)
         {//Start of 'valid' if
            System.out.println("the number was " + telephoneNumber);
            System.out.println();
         }//End of 'valid' if
         else
         {//Start of else
            System.out.println("no valid telephone number was found.");
            System.out.println();
         }//End of else
      }//End of while loop   
   }//End of main
}//End of class