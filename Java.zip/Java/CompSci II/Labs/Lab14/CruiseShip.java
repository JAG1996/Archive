public class CruiseShip extends Ship
{//Start of Class
   private int passengers;
   
   public CruiseShip(String n, String y, int p)
   {//Start of Constructor
      super(n, y);
      passengers = p;
   }//End of Constructor
   
   public void setPassengers(int p)
   {//Start of Method
      passengers = p;
   }//End of Method
   
   public int getPassengers()
   {//Start of Method
      return passengers;
   }//End of Method
   
   public String toString()
   {//Start of Method
      return "Name: " + getName() + "\n" +
             "Maximum passengers: " + passengers;
   }//End of Method
}//End of Class