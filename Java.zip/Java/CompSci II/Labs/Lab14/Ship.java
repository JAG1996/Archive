public class Ship
{//Start of Class
   private String name;
   private String yearBuilt;
   
   public Ship(String n, String y)
   {//Start of Constructor
      name = n;
      yearBuilt = y;
   }//End of Constructor
   
   public void setName(String n)
   {//Start of Method
      name = n;
   }//End of Method
   
   public void setYearBuilt(String y)
   {//Start of Method
      yearBuilt = y;
   }//End of Method
   
   public String getName()
   {//Start of method
      return name;
   }//End of Method
   
   public String getYearBuilt()
   {//Start of Method
      return yearBuilt;
   }//End of Method
   
   public String toString()
   {//Start of Method
      return "Name: " + name + "\n" + 
             "Year Built: " + yearBuilt;
   }//End of Method
}//End of Class