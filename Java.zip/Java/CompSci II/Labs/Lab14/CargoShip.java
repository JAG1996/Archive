public class CargoShip extends Ship
{//Start of Class
   private int tonnage;
   
   public CargoShip(String n, String y, int t)
   {//Start of Constructor
      super(n, y);
      tonnage = t;
   }//End of Constructor
   
   public void setTonnage(int t)
   {//Start of Method
      tonnage = t;
   }//End of Method
   
   public int getTonnage()
   {//Start of Method
      return tonnage;
   }//End of Method
   
   public String toString()
   {//Start of Method
      return "Name: " + getName() + "\n" +
             "Cargo capacity: " + tonnage + " tons";
   }//End of Method
}//End of Class