import java.util.Scanner;
import java.io.*;

public class ListFiles { // Start of Class
   public static void main(String[] args) { // Start of Main
      Scanner keyboard = new Scanner(System.in);
      
      System.out.print("What directory should be listed? ");
      String inputName = keyboard.nextLine();
      File startingDirectory = new File(inputName);
      
      if (startingDirectory.isDirectory()) { // Start of If
         System.out.println();
         listFiles(startingDirectory);
      } // End of If
      else { // Start of Else
         System.out.println("That is not a directory.");
      } // End of Else
   } // End of Main
   
   public static void listFiles(File directory) { // Start of Method
      System.out.println();
      String header = "Contents of " + directory.getPath();
      System.out.println(header);
      for (int n = 1; n <= header.length(); n++) { // Start of For Loop
         System.out.print("-");
      } // End of For Loop
      System.out.println();
      
      File[] listOfFiles = directory.listFiles();
      
      int listLength = 0;
      try { // Start of Try
         listLength = listOfFiles.length;
      } // End of Try
      catch (Exception e) { // Start of Catch
         listLength = 0;
         System.out.println("(The contents of this directory are not accessible.)");
      } // End of Catch
      
      for (int n = 0; n < listLength; n++) { // Start of For Loop
         if (listOfFiles[n].isFile()) { // Start of If
            System.out.println("File       " + listOfFiles[n].getName());
         } // End of If
         if (listOfFiles[n].isDirectory()) { // Start of If
            System.out.println("Directory  " + listOfFiles[n].getName());
         } // End of If         
      } // End of For Loop
      
      for (int n = 0; n < listLength; n++) { // Start of For Loop
         if (listOfFiles[n].isDirectory()) { // Start of If
            listFiles(listOfFiles[n]);
         } // End of If
      } // End of For Loop
   } // End of Method
} // End of Class