import java.util.Scanner; // Needed for the Scanner class

public class PerfectSquares
{// Start of class
   public static void main(String[] args)
   {// Start of main
   
      double m = 0.0;
      double o = 0.0;
      double num1 = 0.0;
      double num2 = 0.0;
      double high = 0.0;
      int low = 0;
      
      // Create a Scanner object to read input.
      Scanner keyboard = new Scanner(System.in);
      
      System.out.print("Please enter the  first number: ");
      num1 = keyboard.nextDouble();
      
      System.out.print("Please enter the second number: ");
      num2 = keyboard.nextDouble();
      
      if (num1 <= num2)
      {//Start of if
         o = num1;
         low = (int) num1;
         high = num2;
      }//End of if
      
      else
      {//Start of else if
         o = num2;
         low = (int) num2;
         high = num1;
      }//End of else if
      
      if (o % low != 0)
      {//Start of if
         low++;
      }//End of if
      
      System.out.println("The perfect squares between those numbers are: ");
      
      
      for(int n = (int) low; n <= high; n++)
      {//Start of for loop
         m = Math.sqrt(n);
         if (n % m == 0 && n <= high)
         {//Start of if
            System.out.println(n);
         }//End of if
      }//End of for loop
      
      System.out.print("End of list.");
      
   }// End of main
}// End of class