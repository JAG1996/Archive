import java.util.Scanner; // Needed for the Scanner class
import java.io.*;

public class PercentAlphabetic
{// Start of class
   public static void main(String[] args) throws IOException
   {// Start of main
      
      int count = 0;
      int total = 0;
      
      int i = 0;
      
      double calc = 0.0;
      
      String s = "";
      
      char c = ' ';
            
      // Create a Scanner object to read input.
      Scanner keyboard = new Scanner(System.in);
            
      System.out.print("Please enter the filename: ");
      String filename = keyboard.nextLine();
      
      File file = new File(filename);
      Scanner inputFile = new Scanner(file);
      
      s = inputFile.next();
      
      while (total > -1)
      {//Start of while loop
         for (i = 0; i < s.length(); i++) 
         {//Start of for loop

            c = s.charAt(i);
         
            if (c == 'A' || c == 'a' ||
                c == 'B' || c == 'b' ||
                c == 'C' || c == 'c' ||
                c == 'D' || c == 'd' ||
                c == 'E' || c == 'e' ||
                c == 'F' || c == 'f' ||
                c == 'G' || c == 'g' ||
                c == 'H' || c == 'h' ||
                c == 'I' || c == 'i' ||
                c == 'J' || c == 'j' ||
                c == 'K' || c == 'k' ||
                c == 'L' || c == 'l' ||
                c == 'M' || c == 'm' ||
                c == 'N' || c == 'n' ||
                c == 'O' || c == 'o' ||
                c == 'P' || c == 'p' ||
                c == 'Q' || c == 'q' ||
                c == 'R' || c == 'r' ||
                c == 'S' || c == 's' ||
                c == 'T' || c == 't' ||
                c == 'U' || c == 'u' ||
                c == 'V' || c == 'v' ||
                c == 'W' || c == 'w' ||
                c == 'X' || c == 'x' ||
                c == 'Y' || c == 'y' || 
                c == 'Z' || c == 'z' )
            {//Start of if
               count++;
               total++;
            }//End of if
            else
            {//Start of else
               total++;
            }//End of else
                      
         }//End of for loop
            
         i = 0;   
          
         if (inputFile.hasNext())
         {//Start of if 
            s = inputFile.next(); 
         }//End of if
         else
         {//Start of else
            break;
         }//End of else 
          
      }//End of while loop
      
      if (total != 0 && count != 0)
      {//Start of if
         double cou = count;
         double nt = total;
         calc = cou / nt;
         calc *= 100;
      }//End of if
      
      System.out.printf("That file is %.1f%% alphabetic.\n", calc);
      
   }// End of main
}// End of class