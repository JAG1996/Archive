import java.util.Scanner; // Needed for the Scanner class

public class AcceptableNumbers
{// Start of class
   public static void main(String[] args)
   {// Start of main
      
      int count = 0;
      
      // Create a Scanner object to read input.
      Scanner keyboard = new Scanner(System.in);
      
      System.out.print("Please enter a positive integer: ");
      int num = keyboard.nextInt();
            
      if (num > 100)
      {//Start of if
         count++;
      }//End of if    
      
      if ((num % 10) == 7)
      {//Start of if
         count++;
      }//End of if
      
      if ((num % 9) != 0)
      {//Start of if
         count++;
      }//End of if
      
      if (count == 1)
      {//Start of if
         System.out.println("That number is acceptable.");
      }//End of if
      else
      {//Start of else
         System.out.println("That number is NOT acceptable.");
      }//End of else
      
   }// End of main
}// End of class