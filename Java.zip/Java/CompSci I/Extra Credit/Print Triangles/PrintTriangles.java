import java.util.Scanner; // Needed for the Scanner class

public class PrintTriangles
{// Start of class
   public static void main(String[] args)
   {// Start of main
   
      int levels = 0;
      
      // Create a Scanner object to read input.
      Scanner keyboard = new Scanner(System.in);
      
      System.out.print("How many levels of triangles should there be? ");
      levels = keyboard.nextInt();      
      
      System.out.println();
      
      for(int l = 1; l <= levels; l++)
      {//Start of 'l' for loop
         for(int s = levels; s > 0; s--)
         {//Start of 's' for loop
            if(l < s)
            {//Start of if
               System.out.print("  ");
            }//End of if
            else
            {//Start of else
               System.out.print(" /\\ ");
            }//End of else
         }//End of 's' for loop
         System.out.println();
         
         for(int s = levels; s > 0; s--)
         {//Start of 's' for loop
            if(l < s)
            {//Start of if
               System.out.print("  ");
            }//End of if
            else
            {//Start of else
               System.out.print("/__\\");
            }//End of else
         }//End of 's' for loop
         System.out.println();
      }//End of 'l' for loop
      
      System.out.println();
                 
   }// End of main
}// End of class