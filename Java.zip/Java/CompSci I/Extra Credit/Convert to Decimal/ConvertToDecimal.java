import java.util.Scanner;

public class ConvertToDecimal
{//Start of class
   public static void main(String[] args)
   {//Start of main
   
      int v = 0;
      int total = 0;
      int pow = 0;
      boolean broken = false;
   
      Scanner keyboard = new Scanner(System.in);
      
      System.out.print("What is the base (2 thru 16) for the number? ");
      int base = keyboard.nextInt();
      
      while (base > 16 || base < 2)
      {//Start of while
         System.out.print("INVALID. Please enter any base from 2 thru 16: ");
         base = keyboard.nextInt();
      }//End of while
   
      System.out.print("Please enter a positive integer in base " + base + ": ");
      String s = keyboard.next();
         
      s = s.toUpperCase();
      
      for (int i = s.length() - 1; i >= 0; i--) 
      {//Start of for loop
        
         char c = s.charAt(i);
      
         if ( (base == 2  && c > 49) ||  
              (base == 3  && c > 50) ||
              (base == 4  && c > 51) ||
              (base == 5  && c > 52) ||
              (base == 6  && c > 53) ||
              (base == 7  && c > 54) ||
              (base == 8  && c > 55) ||
              (base == 9  && c > 56) ||
              (base == 10 && c > 57) ||
              (base == 11 && c > 65) ||
              (base == 12 && c > 66) ||
              (base == 13 && c > 67) ||
              (base == 14 && c > 68) ||
              (base == 15 && c > 69) ||
              (base == 16 && c > 70) )
         {//Start of if
            System.out.println("I'm sorry, but \"" + s + "\" is not a valid digit in that base.");
            broken = true;
            break;
         }//End of if
         
         else
         {//Start of else
            if (c >= '0' && c <= '9')
            {//Start of if
               v = c - '0';
            }//End of if   
            
            else
            {//Start of else if   
               v = 10 + (c - 'A');
            }//End of else if
            
            total += (v * Math.pow(base, pow));
            pow++;
         
         }//End of else
      
      }//End of for loop
      
      if (broken == false)
      {//Start of if
         System.out.printf("The number " + s + " in base " + base + " is equal to decimal %,d.", total);
      }//End of if
         
   }//End of main
   
}//End of class