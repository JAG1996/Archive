import java.util.Scanner; // Needed for the Scanner class

public class ThreeInALine
{// Start of class
   public static void main(String[] args)
   {// Start of main
      
      // Create a Scanner object to read input.
      Scanner keyboard = new Scanner(System.in);
      
      System.out.print("What is the X co-ordinate of the  first point? ");
      double x1 = keyboard.nextDouble();
      
      System.out.print("What is the Y co-ordinate of the  first point? ");
      double y1 = keyboard.nextDouble();
      
      System.out.println();
      
      System.out.print("What is the X co-ordinate of the second point? ");
      double x2 = keyboard.nextDouble();
      
      System.out.print("What is the Y co-ordinate of the second point? ");
      double y2 = keyboard.nextDouble();
      
      System.out.println();
      
      System.out.print("What is the X co-ordinate of the  third point? ");
      double x3 = keyboard.nextDouble();
      
      System.out.print("What is the Y co-ordinate of the  third point? ");
      double y3 = keyboard.nextDouble();
      
      System.out.println();
      
      double calc1 = ((y2 - y1) * (x3 - x2));
      double calc2 = ((y3 - y2) * (x2 - x1)); 
      
      if (calc1 == calc2)
      {//Start of if
         System.out.println(">>> These points are in a line.");
      }//End of if
      else
      {//Start of else
         System.out.println(">>> These points are NOT in a line.");
      }//End of else
      
   }// End of main
}// End of class