import java.util.Scanner; //Needed for the Scanner class

public class QuadraticEquation
{//Start of class
    public static void main(String[] args) 
      {//Start of main
      
        double root1 = 0;
        double root2 = 0;
        
        // Create a Scanner object to read input.
        Scanner keyboard = new Scanner(System.in);
        
        System.out.println("The Quadratic Equation: ax� + bx + c = y");
        System.out.println("-----------------------------------------");
       
        System.out.print("Enter a: ");
        int a = keyboard.nextInt();
       
        System.out.print("Enter b: ");
        int b = keyboard.nextInt();
       
        System.out.print("Enter c: ");
        int c = keyboard.nextInt();
       
        System.out.print("The equation   " + a + ".0x� + " + b + ".0x + " + c + ".0 = y    ");
        double d = b * b - 4 * a * c;
        
        if (d > 0)
        {//Start of if
            System.out.println("has two real solutions (roots):");
            root1 = ((-b) + Math.sqrt(d))/(2*a);
            root2 = ((-b) - Math.sqrt(d))/(2*a);
            System.out.println("x = " + root1);
            System.out.println("x = " + root2);
        }//End of if
        else if(d == 0)
        {//Start of else if
            System.out.println("has one real solution (root):");
            root1 = (-b+Math.sqrt(d))/(2*a);
            System.out.println("x = " + root1);
        }//End of else if
        else
        {//Start of else
            System.out.println("has no real solution (root).");
        }//End of else
        
    }//End of main
}//End of class