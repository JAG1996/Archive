import java.util.Scanner; // Needed for the Scanner class

public class GridPatterns
{// Start of class
   public static void main(String[] args)
   {// Start of main

      // Create a Scanner object to read input.
      Scanner keyboard = new Scanner(System.in);
      
      System.out.print("How many columns wide should the grid be? ");
      int colOutline = keyboard.nextInt();
      
      System.out.print("How many rows high should the grid be? ");
      int rowOutline = keyboard.nextInt();
      
      System.out.print("How many spaces wide should each box be? ");
      int colSpace = keyboard.nextInt();
      
      System.out.print("How many lines high should each box be? ");
      int rowSpace = keyboard.nextInt();
      
      System.out.println();
      
      for (int h = 0; h < rowOutline; h++)
      {//Start of 'h' for loop
         for (int c = 0; c < colOutline; c++)
         {//Start of 'c' for loop
            System.out.print("+");
            for (int z = 0; z < colSpace; z++)
            {//Start of 'z' for loop
               System.out.print("-");
            }//End of 'z' for loop
         }//End of 'c' for loop
         System.out.println("+");
         
         for (int l = 0; l < rowSpace; l++)
         {//Start of 'l' for loop
            for (int s = 0; s < colOutline; s++)
            {//Start of 's' for loop
               System.out.print("|");
               for (int a = 0; a < colSpace; a++)
               {//Start of 'a' for loop
                  System.out.print(" ");
               }//End of 'a' for loop
            }//End of 's' for loop
            System.out.println("|");
         }//End of 'l' for loop
      }//End of 'h' for loop
      
      for (int c = 0; c < colOutline; c++)
         {//Start of 'c' for loop
            System.out.print("+");
            for (int z = 0; z < colSpace; z++)
            {//Start of 'z' for loop
               System.out.print("-");
            }//End of 'z' for loop
         }//End of 'c' for loop
      System.out.print("+");
      
   }// End of main
}// End of class