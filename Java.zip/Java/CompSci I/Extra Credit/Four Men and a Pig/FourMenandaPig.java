public class FourMenandaPig
{// Start of class
   public static void main(String[] args)
   {// Start of main
      
      int morn = 0;
      int man1 = 0;
      int man2 = 0;
      int man3 = 0;
      int man4 = 0;
      int pig1 = 0;
      int pig2 = 0;
      int pig3 = 0;
      int pig4 = 0;
      int pig5 = 0;
      int total1 = 0;
      int total2 = 0;
      int total3 = 0;
      int total4 = 0;
      
      for (int apples = 1; apples <= 10000; apples++)
      {//Start of for loop
         man1 = apples / 4;
         pig1 = apples % 4;
         total1 = man1 * 3;
         
         man2 = total1 / 4;
         pig2 = total1 % 4;;
         total2 = man2 * 3;
         
         man3 = total2 / 4;
         pig3 = total2 % 4;
         total3 = man3 * 3;
         
         man4 = total3 / 4;
         pig4 = total3 % 4;
         total4 = man4 * 3;
         
         morn = total4 / 4;
         pig5 = total4 % 4;
         
         if (pig1 == 1 && pig2 == 1 && pig3 == 1 && pig4 == 1 && pig5 == 1)
         {//Start of if
            System.out.printf("%,d\n", apples);
         }//End of if
      }//End of for loop      
   }// End of main
}// End of class