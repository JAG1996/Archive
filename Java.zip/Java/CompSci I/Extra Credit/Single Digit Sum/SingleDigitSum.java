import java.util.Scanner; // Needed for the Scanner class

public class SingleDigitSum
{// Start of class
   public static void main(String[] args)
   {// Start of main
                      
      // Create a Scanner object to read input.
      Scanner keyboard = new Scanner(System.in);
      
      System.out.print("Please enter a decimal integer: ");
      int num = keyboard.nextInt();  
      
      int total = num;
      
      while (total > 9)
      {//Start of while
         total = (total % 10) + (total / 10);     
      }//End of while      

      System.out.println("The single digit sum of " + num + " is " + total + ".");
      
   }// End of main
}// End of class