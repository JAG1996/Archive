import java.util.Scanner; // Needed for the Scanner class

public class CheckTriangles
{// Start of class
   public static void main(String[] args)
   {// Start of main
      
      String s = "";
      
      double min = 0;
      double mid = 0;
      double max = 0;
      double calc = 0;
         
      // Create a Scanner object to read input.
      Scanner keyboard = new Scanner(System.in);
      
      System.out.print("How long is the  first side? ");
      double side1 = keyboard.nextDouble();
      
      System.out.print("How long is the second side? ");
      double side2 = keyboard.nextDouble();
      
      System.out.print("How long is the  third side? ");
      double side3 = keyboard.nextDouble();
      
      if (side1 >= side2 && side1 >= side3)
      {//Start of if
         max = side1;
         s = "first";
         if (side2 >= side3)
         {//Start of n if
            mid = side2;
            min = side3;
         }//Start of n if
         else
         {//Start of else
            mid = side3;
            min = side2;
         }//End of else
      }//End of if
      
      if (side2 >= side1 && side2 >= side3)
      {//Start of if
         max = side2;
         s = "second";
         if (side1 >= side3)
         {//Start of n if
         mid = side1;
         min = side3;
         }//End of n if
         else
         {//Start of else
         mid = side3;
         min = side1;
         }//End of else
      }//End of if
      
      if (side3 >= side1 && side3 >= side2)
      {//Start of if
         max = side3;
         s = "third";
         if (side1 >= side2)
         {//Start of n if
         mid = side1;
         min = side2;
         }//End of n if
         else
         {//Start of else
         mid = side2;
         min = side1;
         }//End of else
      }//End of if
      
      calc = min + mid;
      
      if (max > calc)
      {//Start of if
         System.out.println("That triangle is invalid.");
         System.out.printf("The " + s + " side (%.3f) is greater than the sum of the other\n", max);
         System.out.printf("two sides (%.3f + %.3f = %.3f).\n", min, mid, calc);
      }//End of if
      else
      {//Start of else
         System.out.println("That is a valid triangle.");
      }//End of else 
           
   }// End of main
}// End of class