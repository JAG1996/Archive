import java.util.Scanner;

public class DisplayReversedInteger // Lab40
{//Start of class
   public static void main(String[] args)
   {//Start of main
      Scanner keyboard = new Scanner(System.in);
      
      //Request and validate the first integer.
      System.out.print("Please enter a positive integer: ");
      int n = keyboard.nextInt();
      while (n < 1)
      {
         System.out.println("Sorry, that needs to be a positive integer.");
         System.out.print("Please enter a positive integer: ");
         n = keyboard.nextInt();
      }
      
      System.out.println(n + " reversed is " + reversed(n) + ".");
   }//End of main
   
   public static int reversed(int value) 
   {//Start of "reversed" method
      int resultNumber = 0;
      for(int i = value; i !=0; i /= 10)
      {//Start of "value" for loop
         resultNumber = resultNumber * 10 + i % 10;
      }//End of "value" for loop
      return resultNumber;        
   }//End of "reversed" method
}//End of class