public class Rectangle // Lab48
{// Start of class

   private double length; //Always in inches
   private double width; //Always in inches
   
   final private double CMPERINCH = 2.54;
   final private double INCHESPERFOOT = 12;
   final private double INCHESPERYARD = 36;
   final private double INCHESPERMETER = 39.37;
   
   final private char INCHES = 'I';
   final private char FEET = 'F';
   final private char YARDS = 'Y';
   final private char CM = 'C';
   final private char METERS = 'M';
   
   public Rectangle()
   {//Start of 'Rectangle' method
      length = 0;
      width = 0;
   }//End of 'Rectangle' method
   
   public Rectangle(char units, double len, double wid)
   {//Start of 'Rectangle' method
      length = toInches(units, len);
      width = toInches(units, wid);
   }//End of 'Rectangle' method
   
   public void setLength(char units, double len)
   {//Start of 'setLength' method
      length = toInches(units, len);
   }//End of 'setLength' method
   
   public void setWidth(char units, double wid)
   {//Start of 'setWidth' method
      width = toInches(units, wid);
   }//End of 'setWidth' method
   
   public double getLength(char units)
   {//Start of 'getLength' method
      return fromInches(units, length);
   }//End of 'getLength' method
   
   public double getWidth(char units)
   {//Start of 'getWidth' method
      return fromInches(units, width);
   }//End of 'getWidth' method
   
   public double getArea(char units)
   {//Start of 'getArea' method
      double retValue = 0;
      
      switch (units)
      {//Start of 'units' switch
         case INCHES:
         case FEET:
         case YARDS:
         case CM:
         case METERS:
            retValue = getWidth(units) * getLength(units);
            break;
         default:
            System.out.println("Error: \"" + units + 
               "\" is not a valid units code.");
            retValue = -1;
      }//End of 'units' switch
      return retValue;
   }//End of 'getArea' method
        
   private double toInches(char units, double inputValue)
   {//Start of 'toInches' method
      double inches = 0;
      
      switch (units)
      {//Start of 'units' switch
         case INCHES:
            inches = inputValue;
            break;
         case FEET:
            inches = inputValue * INCHESPERFOOT;
            break;
         case YARDS:
            inches = inputValue * INCHESPERYARD;
            break;
         case CM:
            inches = inputValue / CMPERINCH;
            break;
         case METERS:
            inches = inputValue * INCHESPERMETER;
            break;
         default:
            System.out.println("Error: \"" + units + 
                  "\" is not a valid units code.");
            inches = -1;
      }//End of 'units' switch
      return inches;
   }//End of 'toInches' method
   
   private double fromInches(char units, double inches)
   {//Start of 'fromInches' method
      double retValue = 0;
      
      switch (units)
      {//Start of 'units' switch
         case INCHES:
            retValue = inches;
            break;
         case FEET:
            retValue = inches / INCHESPERFOOT;
            break;
         case YARDS:
            retValue = inches / INCHESPERYARD;
            break;
         case CM:
            retValue = inches * CMPERINCH;
            break;
         case METERS:
            retValue = inches / INCHESPERMETER;
            break;
         default:
            System.out.println("Error: \"" + units + 
                  "\" is not a valid units code.");
            inches = -1;            
      }//End of 'units' switch
      return retValue;
   }//End of 'fromInches' method
   
}// End of class