public class RectangleTest // Tests the multi-unit Rectangle class
{//Start of class
   public static void main(String[] args)
   {//Start of main
      
      //Make some rectangles.
      Rectangle r1 = new Rectangle();
      r1.setLength('C', 100);
      r1.setWidth('F', 2);
      System.out.println("For the r1 rectangle:");
      System.out.println("- Area in square cm is " + r1.getArea('C') + ".");
      System.out.println("- Area in square meters is " + r1.getArea('M') + ".");
      System.out.println("- Area in square inches is " + r1.getArea('I') + ".");
      System.out.println("- Area in square feet is " + r1.getArea('F') + ".");
      System.out.println("- Area in square yards is " + r1.getArea('Y') + ".");
      System.out.println();
      
      Rectangle r2 = new Rectangle('Y', 5, 3);
      System.out.println("For the r2 rectangle:");
      System.out.println("- Area in square cm is " + r2.getArea('C') + ".");
      System.out.println("- Area in square meters is " + r2.getArea('M') + ".");
      System.out.println("- Area in square inches is " + r2.getArea('I') + ".");
      System.out.println("- Area in square feet is " + r2.getArea('F') + ".");
      System.out.println("- Area in square yards is " + r2.getArea('Y') + ".");
      System.out.println();
       
   }//End of main()   
}//End of class