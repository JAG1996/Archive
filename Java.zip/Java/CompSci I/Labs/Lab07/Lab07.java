import java.util.Scanner;

public class Lab07
{// Start of class
   public static void main(String[] args)
   {// Start of main
   
      // Create a Scanner object to read input.
     Scanner keyboard = new Scanner(System.in);
     
     final double TAX_RATE = 0.0675;
     final double TIP_PERCENT = 0.2;
     
     double meal;
     double tax;
     double tip;
     double total;
     
     System.out.print("Enter the cost of the meal: ");
     meal = keyboard.nextDouble();
     
     tax = meal * TAX_RATE;
     
     tip = (meal + tax) * TIP_PERCENT;
     
     total = meal + tax + tip;
     
     System.out.println("The meal cost: $" + meal);
     System.out.println("Tax:           $" + tax);
     System.out.println("Tip:           $" + tip);
     System.out.println("Total:         $" + total);     
   }//End of main
}// End of class