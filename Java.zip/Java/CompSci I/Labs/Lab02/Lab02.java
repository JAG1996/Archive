public class Lab02
{//Start of the class
   public static void main (String[] args)
   {//Start of main
      System.out.println("Jake Garrett");
      System.out.println("503 S Warminster rd. APT # G6");
      System.out.println("Hatboro, PA 19040");
      System.out.println("215-341-1941");
   }//End of main
}//End of the class