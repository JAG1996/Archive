import java.util.Scanner;
 
public class SharedMultiple // Lab31 
{//Start of class
    static int gcd(int num1, int num2)
    {//Start of GCD
        int remainder = 0, calq1, calq2;
        calq1 = (num1 > num2) ? num1 : num2;
        calq2 = (num1 < num2) ? num1 : num2;
 
        remainder = calq2;
        while(calq1 % calq2 != 0)
        {//Start of while loop
            remainder = calq1 % calq2;
            calq1 = calq2;
            calq2 = remainder;
        }//End of while loop
        return remainder;
    }//End of GCD
 
    static int lcm(int num1, int num2)
    {//Start of LCM
        int calq1;
        calq1 = (num1 > num2) ? num1 : num2; // a is greater number
        while(true)
        {//Start of while loop
            if(calq1 % num1 == 0 && calq1 % num2 == 0)
                return calq1;
            ++calq1;
        }//End of while loop
    }//End of LCM
 
    public static void main(String args[])
    {//Start of main
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the first  positive integer: ");
        int num1 = input.nextInt();
        System.out.print("Enter the second positive integer: ");
        int num2 = input.nextInt();
 
        System.out.println("The smallest shared multiple of " + num1 + " and " + num2 + " is " + lcm(num1, num2) + ".");
        input.close();		
    }//End of main
}//End of class