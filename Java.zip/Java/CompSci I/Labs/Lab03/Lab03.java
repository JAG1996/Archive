import java.util.Scanner;

public class Lab03
{// Start of class
   public static void main(String[] args)
   {// Start of main
      Scanner keyboard = new Scanner(System.in);
      
      System.out.print("Enter an adjective: ");
      String beautiful = keyboard.nextLine();
      
      System.out.print("Enter an adjective: ");
      String evil = keyboard.nextLine();
      
      System.out.print("Enter an adjective: ");
      String ugly = keyboard.nextLine();
      
      System.out.print("Enter an part of the body: ");
      String foot = keyboard.nextLine();
      
      System.out.print("Enter an noun: ");
      String slave = keyboard.nextLine();
      
      System.out.print("Enter an adjective: ");
      String clean = keyboard.nextLine();
      
      System.out.print("Enter an noun: ");
      String sky = keyboard.nextLine();
      
      System.out.print("Enter an noun: ");
      String god = keyboard.nextLine();
      
      System.out.print("Enter an noun: ");
      String wand = keyboard.nextLine();
      
      System.out.print("Enter an noun: ");
      String dress = keyboard.nextLine();
      
      System.out.print("Enter an plural noun: ");
      String slipper = keyboard.nextLine();
      
      System.out.print("Enter an male person: ");
      String charming = keyboard.nextLine();
      
      System.out.print("Enter an plural noun: ");
      String slippers = keyboard.nextLine();
      
      System.out.print("part of the body: ");
      String Foot = keyboard.nextLine();
      
      System.out.print("adverb: ");
      String happily = keyboard.nextLine();
      
      ////////////////////////////
      
      System.out.println();
      System.out.println();
      System.out.println();
      System.out.println("CINDERELLA");
      System.out.println();
      
      System.out.println("There was once a/an " + beautiful + " young girl named Cinderella");
      System.out.println("who lived with her " + evil + " stepmother and two");
      System.out.println("" + ugly + " stepsisters. She waited on them hand and ");
      System.out.println("" + foot + ", but they treated her like a/an " + slave + ".");
      System.out.println("Cinderella heard about a ball the prince was throwing, but she");
      System.out.println("didn't have a/an " + clean + " gown to wear. Then, out of the");
      System.out.println("clear, blue " + sky + ", her fairy " + god + "-mother appeared");
      System.out.println("and waved her magic " + wand + ". Cinderella's ragged clothes");
      System.out.println("turned into a beautiful " + dress + ", and her worn work shoes");
      System.out.println("became a pair of glass " + slipper + ". Cinderella went to the ball");
      System.out.println("and danced with Prince " + charming + ", who fell madly in love");
      System.out.println("with her. But at the stroke of midnight she had to flee, losing one of");
      System.out.println("her glass " + slippers + ". The prince traveled throughout the");
      System.out.println("kingdom, trying the slipper on the " + Foot + " of every young");
      System.out.println("girl, but of course, it fit only one - Cinderella! The two were soon");
      System.out.println("married and lived " + happily + " ever after.");
      
      
   }//End of main
}// End of class