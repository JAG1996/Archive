public class DollarInCoins // Lab27
{// Start of class
   public static void main(String[] args)
   {// Start of main
      
      int numberCount = 1;
      int pennyCount = 100;
      int nickelCount = 0;
      int dimeCount = 0;
      int quarterCount = 0;
                 
      while (numberCount <= 21)          
      {//Start of "pennies and nickels" while loop           
         System.out.printf("%3d: " + quarterCount + " quarters, " 
                                   + dimeCount + " dimes, " 
                                   + nickelCount + " nickels, and " 
                                   + pennyCount + " pennies.\n"
                                   , numberCount);
         pennyCount = pennyCount - 5;
         nickelCount++;
         numberCount++;
      }//End of "pennies and nickels" while loop
      
      pennyCount = 90;
      nickelCount = 0;
      dimeCount = 1;      
      while (numberCount <= 40)
      {//Start of "pennies, nickels and 1 dime" while loop
         System.out.printf("%3d: " + quarterCount + " quarters, " 
                                   + dimeCount + " dimes, " 
                                   + nickelCount + " nickels, and " 
                                   + pennyCount + " pennies.\n"
                                   , numberCount);
         pennyCount = pennyCount - 5;
         nickelCount++;
         numberCount++;
      }//End of "pennies, nickels and 1 dime" while loop

      pennyCount = 80;
      nickelCount = 0;
      dimeCount = 2;      
      while (numberCount <= 57)
      {//Start of "pennies, nickels and 2 dimes" while loop
         System.out.printf("%3d: " + quarterCount + " quarters, " 
                                   + dimeCount + " dimes, " 
                                   + nickelCount + " nickels, and " 
                                   + pennyCount + " pennies.\n"
                                   , numberCount);
         pennyCount = pennyCount - 5;
         nickelCount++;
         numberCount++;
      }//End of "pennies, nickels and 2 dimes" while loop

      pennyCount = 70;
      nickelCount = 0;
      dimeCount = 3;      
      while (numberCount <= 72)
      {//Start of "pennies, nickels and 3 dimes" while loop
         System.out.printf("%3d: " + quarterCount + " quarters, " 
                                   + dimeCount + " dimes, " 
                                   + nickelCount + " nickels, and " 
                                   + pennyCount + " pennies.\n"
                                   , numberCount);
         pennyCount = pennyCount - 5;
         nickelCount++;
         numberCount++;
      }//End of "pennies, nickels and 3 dimes" while loop

      pennyCount = 60;
      nickelCount = 0;
      dimeCount = 4;      
      while (numberCount <= 85)
      {//Start of "pennies, nickels and 4 dimes" while loop
         System.out.printf("%3d: " + quarterCount + " quarters, " 
                                   + dimeCount + " dimes, " 
                                   + nickelCount + " nickels, and " 
                                   + pennyCount + " pennies.\n"
                                   , numberCount);
         pennyCount = pennyCount - 5;
         nickelCount++;
         numberCount++;
      }//End of "pennies, nickels and 4 dimes" while loop

      pennyCount = 50;
      nickelCount = 0;
      dimeCount = 5;      
      while (numberCount <= 96)
      {//Start of "pennies, nickels and 5 dimes" while loop
         System.out.printf("%3d: " + quarterCount + " quarters, " 
                                   + dimeCount + " dimes, " 
                                   + nickelCount + " nickels, and " 
                                   + pennyCount + " pennies.\n"
                                   , numberCount);
         pennyCount = pennyCount - 5;
         nickelCount++;
         numberCount++;
      }//End of "pennies, nickels and 5 dimes" while loop

      pennyCount = 40;
      nickelCount = 0;
      dimeCount = 6;      
      while (numberCount <= 105)
      {//Start of "pennies, nickels and 6 dimes" while loop
         System.out.printf("%3d: " + quarterCount + " quarters, " 
                                   + dimeCount + " dimes, " 
                                   + nickelCount + " nickels, and " 
                                   + pennyCount + " pennies.\n"
                                   , numberCount);
         pennyCount = pennyCount - 5;
         nickelCount++;
         numberCount++;
      }//End of "pennies, nickels and 6 dimes" while loop

      pennyCount = 30;
      nickelCount = 0;
      dimeCount = 7;      
      while (numberCount <= 112)
      {//Start of "pennies, nickels and 7 dimes" while loop
         System.out.printf("%3d: " + quarterCount + " quarters, " 
                                   + dimeCount + " dimes, " 
                                   + nickelCount + " nickels, and " 
                                   + pennyCount + " pennies.\n"
                                   , numberCount);
         pennyCount = pennyCount - 5;
         nickelCount++;
         numberCount++;
      }//End of "pennies, nickels and 7 dimes" while loop

      pennyCount = 20;
      nickelCount = 0;
      dimeCount = 8;      
      while (numberCount <= 117)
      {//Start of "pennies, nickels and 8 dimes" while loop
         System.out.printf("%3d: " + quarterCount + " quarters, " 
                                   + dimeCount + " dimes, " 
                                   + nickelCount + " nickels, and " 
                                   + pennyCount + " pennies.\n"
                                   , numberCount);
         pennyCount = pennyCount - 5;
         nickelCount++;
         numberCount++;
      }//End of "pennies, nickels and 8 dimes" while loop

      pennyCount = 10;
      nickelCount = 0;
      dimeCount = 9;      
      while (numberCount <= 120)
      {//Start of "pennies, nickels and 9 dimes" while loop
         System.out.printf("%3d: " + quarterCount + " quarters, " 
                                   + dimeCount + " dimes, " 
                                   + nickelCount + " nickels, and " 
                                   + pennyCount + " pennies.\n"
                                   , numberCount);
         pennyCount = pennyCount - 5;
         nickelCount++;
         numberCount++;
      }//End of "pennies, nickels and 9 dimes" while loop

      pennyCount = 0;
      nickelCount = 0;
      dimeCount = 10;           
      System.out.printf("%3d: " + quarterCount + " quarters, " 
                                + dimeCount + " dimes, " 
                                + nickelCount + " nickels, and " 
                                + pennyCount + " pennies.\n"
                                , numberCount);
      numberCount++;

      pennyCount = 75;
      nickelCount = 0;
      dimeCount = 0;
      quarterCount = 1;      
      while (numberCount <= 137)
      {//Start of "pennies, nickels, dimes, and 1 quarter" while loop
         System.out.printf("%3d: " + quarterCount + " quarters, " 
                                   + dimeCount + " dimes, " 
                                   + nickelCount + " nickels, and " 
                                   + pennyCount + " pennies.\n"
                                   , numberCount);
         pennyCount = pennyCount - 5;
         nickelCount++;
         numberCount++;
      }//End of "pennies, nickels, dimes, and 1 quarter" while loop
      
      pennyCount = 65;
      nickelCount = 0;
      dimeCount = 1;
      quarterCount = 1;      
      while (numberCount <= 151)
      {//Start of "pennies, nickels, 1 dime, and 1 quarter" while loop
         System.out.printf("%3d: " + quarterCount + " quarters, " 
                                   + dimeCount + " dimes, " 
                                   + nickelCount + " nickels, and " 
                                   + pennyCount + " pennies.\n"
                                   , numberCount);
         pennyCount = pennyCount - 5;
         nickelCount++;
         numberCount++;
      }//End of "pennies, nickels, 1 dime, and 1 quarter" while loop
                 
      pennyCount = 55;
      nickelCount = 0;
      dimeCount = 2;
      quarterCount = 1;      
      while (numberCount <= 163)
      {//Start of "pennies, nickels, 2 dimes, and 1 quarter" while loop
         System.out.printf("%3d: " + quarterCount + " quarters, " 
                                   + dimeCount + " dimes, " 
                                   + nickelCount + " nickels, and " 
                                   + pennyCount + " pennies.\n"
                                   , numberCount);
         pennyCount = pennyCount - 5;
         nickelCount++;
         numberCount++;
      }//End of "pennies, nickels, 2 dimes, and 1 quarter" while loop

      pennyCount = 45;
      nickelCount = 0;
      dimeCount = 3;
      quarterCount = 1;      
      while (numberCount <= 173)
      {//Start of "pennies, nickels, 3 dimes, and 1 quarter" while loop
         System.out.printf("%3d: " + quarterCount + " quarters, " 
                                   + dimeCount + " dimes, " 
                                   + nickelCount + " nickels, and " 
                                   + pennyCount + " pennies.\n"
                                   , numberCount);
         pennyCount = pennyCount - 5;
         nickelCount++;
         numberCount++;
      }//End of "pennies, nickels, 3 dimes, and 1 quarter" while loop

      pennyCount = 35;
      nickelCount = 0;
      dimeCount = 4;
      quarterCount = 1;      
      while (numberCount <= 181)
      {//Start of "pennies, nickels, 4 dimes, and 1 quarter" while loop
         System.out.printf("%3d: " + quarterCount + " quarters, " 
                                   + dimeCount + " dimes, " 
                                   + nickelCount + " nickels, and " 
                                   + pennyCount + " pennies.\n"
                                   , numberCount);
         pennyCount = pennyCount - 5;
         nickelCount++;
         numberCount++;
      }//End of "pennies, nickels, 4 dimes, and 1 quarter" while loop

      pennyCount = 25;
      nickelCount = 0;
      dimeCount = 5;
      quarterCount = 1;      
      while (numberCount <= 187)
      {//Start of "pennies, nickels, 5 dimes, and 1 quarter" while loop
         System.out.printf("%3d: " + quarterCount + " quarters, " 
                                   + dimeCount + " dimes, " 
                                   + nickelCount + " nickels, and " 
                                   + pennyCount + " pennies.\n"
                                   , numberCount);
         pennyCount = pennyCount - 5;
         nickelCount++;
         numberCount++;
      }//End of "pennies, nickels, 5 dimes, and 1 quarter" while loop

      pennyCount = 15;
      nickelCount = 0;
      dimeCount = 6;
      quarterCount = 1;      
      while (numberCount <= 191)
      {//Start of "pennies, nickels, 6 dimes, and 1 quarter" while loop
         System.out.printf("%3d: " + quarterCount + " quarters, " 
                                   + dimeCount + " dimes, " 
                                   + nickelCount + " nickels, and " 
                                   + pennyCount + " pennies.\n"
                                   , numberCount);
         pennyCount = pennyCount - 5;
         nickelCount++;
         numberCount++;
      }//End of "pennies, nickels, 6 dimes, and 1 quarter" while loop

      pennyCount = 5;
      nickelCount = 0;
      dimeCount = 7;
      quarterCount = 1;      
      while (numberCount <= 193)
      {//Start of "pennies, nickels, 7 dimes, and 1 quarter" while loop
         System.out.printf("%3d: " + quarterCount + " quarters, " 
                                   + dimeCount + " dimes, " 
                                   + nickelCount + " nickels, and " 
                                   + pennyCount + " pennies.\n"
                                   , numberCount);
         pennyCount = pennyCount - 5;
         nickelCount++;
         numberCount++;
      }//End of "pennies, nickels, 7 dimes, and 1 quarter" while loop

      pennyCount = 50;
      nickelCount = 0;
      dimeCount = 0;
      quarterCount = 2;      
      while (numberCount <= 204)
      {//Start of "pennies, nickels, 2 quarters" while loop
         System.out.printf("%3d: " + quarterCount + " quarters, " 
                                   + dimeCount + " dimes, " 
                                   + nickelCount + " nickels, and " 
                                   + pennyCount + " pennies.\n"
                                   , numberCount);
         pennyCount = pennyCount - 5;
         nickelCount++;
         numberCount++;
      }//End of "pennies, nickels, and 2 quarters" while loop

      pennyCount = 40;
      nickelCount = 0;
      dimeCount = 1;
      quarterCount = 2;      
      while (numberCount <= 213)
      {//Start of "pennies, nickels, 1 dime, and 2 quarters" while loop
         System.out.printf("%3d: " + quarterCount + " quarters, " 
                                   + dimeCount + " dimes, " 
                                   + nickelCount + " nickels, and " 
                                   + pennyCount + " pennies.\n"
                                   , numberCount);
         pennyCount = pennyCount - 5;
         nickelCount++;
         numberCount++;
      }//End of "pennies, nickels, 1 dime, and 2 quarters" while loop

      pennyCount = 30;
      nickelCount = 0;
      dimeCount = 2;
      quarterCount = 2;      
      while (numberCount <= 220)
      {//Start of "pennies, nickels, 2 dimes, and 2 quarters" while loop
         System.out.printf("%3d: " + quarterCount + " quarters, " 
                                   + dimeCount + " dimes, " 
                                   + nickelCount + " nickels, and " 
                                   + pennyCount + " pennies.\n"
                                   , numberCount);
         pennyCount = pennyCount - 5;
         nickelCount++;
         numberCount++;
      }//End of "pennies, nickels, 2 dimes, and 2 quarters" while loop

      pennyCount = 20;
      nickelCount = 0;
      dimeCount = 3;
      quarterCount = 2;      
      while (numberCount <= 225)
      {//Start of "pennies, nickels, 3 dimes, and 2 quarters" while loop
         System.out.printf("%3d: " + quarterCount + " quarters, " 
                                   + dimeCount + " dimes, " 
                                   + nickelCount + " nickels, and " 
                                   + pennyCount + " pennies.\n"
                                   , numberCount);
         pennyCount = pennyCount - 5;
         nickelCount++;
         numberCount++;
      }//End of "pennies, nickels, 3 dimes, and 2 quarters" while loop

      pennyCount = 10;
      nickelCount = 0;
      dimeCount = 4;
      quarterCount = 2;      
      while (numberCount <= 228)
      {//Start of "pennies, nickels, 4 dimes, and 2 quarters" while loop
         System.out.printf("%3d: " + quarterCount + " quarters, " 
                                   + dimeCount + " dimes, " 
                                   + nickelCount + " nickels, and " 
                                   + pennyCount + " pennies.\n"
                                   , numberCount);
         pennyCount = pennyCount - 5;
         nickelCount++;
         numberCount++;
      }//End of "pennies, nickels, 4 dimes, and 2 quarters" while loop

      pennyCount = 0;
      nickelCount = 0;
      dimeCount = 5;
      quarterCount = 2;           
      System.out.printf("%3d: " + quarterCount + " quarters, " 
                                + dimeCount + " dimes, " 
                                + nickelCount + " nickels, and " 
                                + pennyCount + " pennies.\n"
                                , numberCount);
      numberCount++;

      pennyCount = 25;
      nickelCount = 0;
      dimeCount = 0;
      quarterCount = 3;      
      while (numberCount <= 235)
      {//Start of "pennies, nickels, 3 quarters" while loop
         System.out.printf("%3d: " + quarterCount + " quarters, " 
                                   + dimeCount + " dimes, " 
                                   + nickelCount + " nickels, and " 
                                   + pennyCount + " pennies.\n"
                                   , numberCount);
         pennyCount = pennyCount - 5;
         nickelCount++;
         numberCount++;
      }//End of "pennies, nickels, 3 quarters" while loop

      pennyCount = 15;
      nickelCount = 0;
      dimeCount = 1;
      quarterCount = 3;      
      while (numberCount <= 239)
      {//Start of "pennies, nickels, 1 dime, and 3 quarters" while loop
         System.out.printf("%3d: " + quarterCount + " quarters, " 
                                   + dimeCount + " dimes, " 
                                   + nickelCount + " nickels, and " 
                                   + pennyCount + " pennies.\n"
                                   , numberCount);
         pennyCount = pennyCount - 5;
         nickelCount++;
         numberCount++;
      }//End of "pennies, nickels, 1 dime, and 3 quarters" while loop

      pennyCount = 5;
      nickelCount = 0;
      dimeCount = 2;
      quarterCount = 3;      
      while (numberCount <= 241)
      {//Start of "pennies, nickels, 2 dimes, and 3 quarters" while loop
         System.out.printf("%3d: " + quarterCount + " quarters, " 
                                   + dimeCount + " dimes, " 
                                   + nickelCount + " nickels, and " 
                                   + pennyCount + " pennies.\n"
                                   , numberCount);
         pennyCount = pennyCount - 5;
         nickelCount++;
         numberCount++;
      }//End of "pennies, nickels, 2 dimes, and 3 quarters" while loop
      
      pennyCount = 0;
      nickelCount = 0;
      dimeCount = 0;
      quarterCount = 4;
      System.out.printf("%3d: " + quarterCount + " quarters, " 
                                + dimeCount + " dimes, " 
                                + nickelCount + " nickels, and " 
                                + pennyCount + " pennies.\n"
                                , numberCount);      
   }// End of main
}// End of class