import javax.swing.JOptionPane;

public class Chargelt // Lab52
{// Start of class
   public static void main(String[] args)
   {// Start of main
   
   String input;
   int accountNumber;
   
   Validator val = new Validator();
   
   input = JOptionPane.showInputDialog("Enter your charge account number: ");
   accountNumber = Integer.parseInt(input);
   
   if (val.isValid(accountNumber))
   {//Start of if
      JOptionPane.showMessageDialog(null, "That's a valid account number.");
   }//End of if
   else
   {//Start of else
      JOptionPane.showMessageDialog(null, "That's an INVALID account number.");
   }//End of else  
   System.exit(0);    
   }// End of main
}// End of class