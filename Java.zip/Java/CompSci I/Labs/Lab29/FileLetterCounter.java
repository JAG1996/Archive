import java.util.Scanner;
import java.io.*;

public class FileLetterCounter // Lab29
{// Start of class
   public static void main(String[] args) throws IOException
   {// Start of main
   
      String fileName;
      char letter;
      int counter = 0;
            
      // Create a Scanner object to read input.
      Scanner keyboard = new Scanner(System.in);
      
      System.out.print("Enter the input file name: ");
      fileName = keyboard.nextLine();
      
      System.out.print("Please enter a letter contained in the file: ");
      letter = keyboard.nextLine().charAt(0);
      char result = letter;
      
      File file = new File(fileName);
      Scanner inFile = new Scanner(file);
      
      //Upper case
      letter = Character.toUpperCase(letter);
      try 
      {//Start of try
         BufferedReader reader = new BufferedReader(new FileReader(file));
         String line = null;
         while ((line = reader.readLine()) !=null) 
         {//Start of while loop
            for(int i=0; i<line.length();i++)
            {//Start of for loop
               if(line.charAt(i) == letter)
               {//Start of if statement
                  counter++;
               }//End of if statement
            }//End of for loop
         }//End of while loop
      }//End of try 
      catch (FileNotFoundException e) 
      {
        // File not found
      } 
      catch (IOException e) 
      {
        // Couldn't read the file
      }
      
      //Lower case
      letter = Character.toLowerCase(letter);
      try 
      {//Start of try
         BufferedReader reader = new BufferedReader(new FileReader(file));
         String line = null;
         while ((line = reader.readLine()) !=null) 
         {//Start of while loop
            for(int i=0; i<line.length();i++)
            {//Start of for loop
               if(line.charAt(i) == letter)
               {//Start of if statement
                  counter++;
               }//End of if statement
            }//End of for loop
         }//End of while loop
      }//End of try 
      catch (FileNotFoundException e) 
      {
        // File not found
      } 
      catch (IOException e) 
      {
        // Couldn't read the file
      }
            
      System.out.print("The letter \'" + result + "\' appears " + counter + " times in the file. ");
      
      inFile.close();
      
   }// End of main
}// End of class