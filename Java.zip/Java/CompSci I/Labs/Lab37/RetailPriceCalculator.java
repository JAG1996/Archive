import java.util.Scanner; // Needed for the Scanner class

public class RetailPriceCalculator // Lab37
{// Start of class
   public static void main(String[] args)
   {// Start of main
      double wholesale;
      double markup;
      double retailPrice;
      
      // Create a Scanner object to read input.
      Scanner keyboard = new Scanner(System.in);
      
      System.out.print("Enter the item's wholesale cost: ");
      wholesale = keyboard.nextDouble();
      
      System.out.println("Enter the item's markup percentage");
      System.out.print("(example: enter 50 for 50 percent): ");
      markup = keyboard.nextDouble(); 
      
      markup = markup / 100.0;
      
      retailPrice = calculateRetail(wholesale, markup);
      
      System.out.printf("The item's retail price is $%,.2f\n", retailPrice);
   }//End of main
      
   public static double calculateRetail(double wholesale, double markupPercent)
   {//Start of "calculateRetail" method
      double retail = wholesale + (wholesale * markupPercent);
      return retail;
   }//End of "calculateRetail" method
}// End of class