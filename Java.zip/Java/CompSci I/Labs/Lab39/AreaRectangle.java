import javax.swing.JOptionPane;

public class AreaRectangle // Lab39
{//Start of class
// vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv Do not change anything in the main() method.
   public static void main(String[] args)
   {//Start of main method
      double rectangleLength;    // The rectangle's length
      double rectangleWidth;     // The rectangle's width
      double rectangleArea;      // The rectangle's area
   
      // Get the rectangle's length from the user.
      rectangleLength = getLength();
   
      // Get the rectangle's width from the user.
      rectangleWidth = getWidth();
   
      // Calculate the rectangle's area.
      rectangleArea = calculateArea(rectangleLength, rectangleWidth);
   
      // Display the rectangle data.
      displayData(rectangleLength, rectangleWidth, rectangleArea);
   }//end of main method
// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ Do not change anything in the main() method.

   public static double getLength()
   {//Start of "getLength" method
      String lengthString =
         JOptionPane.showInputDialog("Enter the rectangle's length:");
      double lengthDouble = Double.parseDouble(lengthString);  
      return lengthDouble;
   }//End of "getLength" method

   public static double getWidth()
   {//Start of "getWidth" method
      String widthString =
         JOptionPane.showInputDialog("Enter the rectangle's width.");
      double widthDouble = Double.parseDouble(widthString);
      return widthDouble;
   }//End of "getWidth" method
   
   public static double calculateArea(double l, double w)
   {//Start of "calculateArea" method
      double area = l * w;
      return area;
   }//End of "calculateArea" method
   
   public static void displayData(double rL, double rW, double rA)
   {//Start of "displayData" method
     JOptionPane.showMessageDialog(null, String.format
     ("Length = %.2f\n Width = %.2f\n Area = %.2f", rL, rW, rA));
   }//End of "displayData" method

}//End of class