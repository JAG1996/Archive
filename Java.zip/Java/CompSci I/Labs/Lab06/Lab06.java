import java.util.Scanner;

public class Lab06
{// Start of class
   public static void main(String[] args)
   {// Start of main
   
      // Create a Scanner object to read input.
     Scanner keyboard = new Scanner(System.in);
     
      final double COWPRICE = 10.00;
      final double DUCKPRICE = 2.00;
      final double BABYPRICE = 0.50;
      
      double totalCost = 0.0;
      int totalAnimals = 0;
      int bought;
           
     System.out.println("100 Animals for $100");
     System.out.println("--------------------");
     
     System.out.println();
     System.out.print("How many cows? ");
     bought = keyboard.nextInt();
     totalCost = totalCost + (bought * COWPRICE);
     totalAnimals = totalAnimals + bought;
     System.out.println("So far we have " + totalAnimals + " animals for $" + totalCost + ".");
    
     System.out.println();
     System.out.print("How many ducks? ");
     bought = keyboard.nextInt();
     totalCost = totalCost + (bought * DUCKPRICE);
     totalAnimals = totalAnimals + bought;
     System.out.println("So far we have " + totalAnimals + " animals for $" + totalCost + ".");
     
     System.out.println();
     System.out.print("How many baby chicks? ");
     bought = keyboard.nextInt();
     totalCost = totalCost + (bought * BABYPRICE);
     totalAnimals = totalAnimals + bought;
     System.out.println("Altogether we have " + totalAnimals + " animals for $" + totalCost + ".");
     
   }//End of main
}// End of class