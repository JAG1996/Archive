import java.util.Scanner; // Needed for the Scanner class
//import javax.swing.JOptionPane;

public class XOPattern // Lab24
{// Start of class
   public static void main(String[] args)
   {// Start of main
   
      int wall = 0;
      int pattern = 0;
      int topBorder = 0;
      int sideBorder = 0;
      int bottomBorder = 0;
      
      // Create a Scanner object to read input.
      Scanner keyboard = new Scanner(System.in);
      
      System.out.print("How wide should the pattern be? ");
      int wide = keyboard.nextInt();
      
      System.out.print("How tall should the pattern be? ");
      int tall = keyboard.nextInt();
      
      //Top Border
      System.out.print("+");
      while (topBorder < wide)
      {//Start of "Top Border" while loop
         System.out.print("-");
         topBorder++;
      }//End of "Top Border" while loop 
      System.out.println("+");
      
      //Side Borders and Program Code
      wall = 0;
      while (sideBorder < tall)
      {//Start of "sideBorder" while loop
         if (wall < tall)
         {//Start of "oddWall" if
            System.out.print("|");
            pattern = 0;
            while (pattern < wide)
            {//Start of "pattern" while loop
               if (pattern < wide)
               {//Start of "X" if
                  System.out.print("X");
                  pattern++;
               }//End of "X" if
               if (pattern < wide)
               {//Start of "O" if
                  System.out.print("O");
                  pattern++;
               }//End of "O" if
            }//End of "pattern" while loop
            wall++;
            System.out.println("|");
         }//End of "oddWall" if
         if (wall < tall)
         {//Start of "evenWall" if
            System.out.print("|");
            pattern = 0;
            while (pattern < wide)
            {//Start of "pattern" while loop
               if (pattern < wide)
               {//Start of "O" if
                  System.out.print("O");
                  pattern++;
               }//End of "O" if
               if (pattern < wide)
               {//Start of "X" if
                  System.out.print("X");
                  pattern++;
               }//End of "X" if
            }//End of "pattern" while loop
            wall++;
            System.out.println("|");
         }//End of "evenWall" if      
         sideBorder++;        
      }//End of "sideBorder" while loop   
      
      //Bottom Border
      System.out.print("+");
      while (bottomBorder < wide)
      {//Start of "bottomBorder" while loop
         System.out.print("-");
         bottomBorder++;
      }//End of "bottomBorder" while loop 
      System.out.println("+");

   }// End of main
}// End of class