public class CircleDemo
{//Start of class
   public static void main(String[] args)
   {//Start of main

      // Create some Circle objects.
      Circle c10 = new Circle(10);
      
      Circle c15 = new Circle();
      c15.setRadius(15);
      
      Circle c20 = new Circle(25);
      c20.setRadius(20);
      
      // Display geometric info about the circles.
      System.out.println("Circle c10's area is " + c10.getArea());
      System.out.println("Circle c10's diameter is " + c10.getDiameter());
      System.out.println("Circle c10's circumference is " + c10.getCircumference());
      System.out.println();

      System.out.println("Circle c15's area is " + c15.getArea());
      System.out.println("Circle c15's diameter is " + c15.getDiameter());
      System.out.println("Circle c15's circumference is " + c15.getCircumference());
      System.out.println();

      System.out.println("Circle c20's area is " + c20.getArea());
      System.out.println("Circle c20's diameter is " + c20.getDiameter());
      System.out.println("Circle c20's circumference is " + c20.getCircumference());
      System.out.println();

      System.out.println("- end -");
   }//End of main
}//End of class