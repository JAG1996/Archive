public class Circle // Lab47 Class
{// Start of class

   private double radius;
   private double area;
   private double diameter;
   private double circumference;
   private double PI = 3.14159;
   
   public Circle()
   {//Start of 'Circle' method
      area = (PI * radius * radius);
      diameter = (radius * 2);
      circumference = (2 * PI * radius);
   }//End of 'Circle' method
   
   public Circle(double r)
   {//Start of 'Circle - double' method
      radius = r;
      area = (PI * radius * radius);
      diameter = (radius * 2);
      circumference = (2 * PI * radius);      
   }//End of 'Circle - double' method
   
   public void setRadius(double r)
   {//Start of 'setRadius' method
      radius = r;
      return;
   }//End of 'setRadius' method
   
   public double getRadius()
   {//Start of 'getRadius' method
      return radius;
   }//End of 'getRadius' method
   
   public double getArea()
   {//Start of 'getArea' method
      return area;
   }//End of 'getArea' method
   
   public double getDiameter()
   {//Start of 'getArea' method
      return diameter;
   }//End of 'getArea' method
   
   public double getCircumference()
   {//Start of 'getCircumference' method
      return circumference;
   }//End of 'getCircumference' method
   
}// End of class