import java.util.Scanner; // Needed for the Scanner class
//import javax.swing.JOptionPane;

public class NumberNames // Lab18
{// Start of class
     
   public static void main(String[] args)
   {// Start of main   
      
      int number;
      String numberString = "";
      
      // Create a Scanner object to read input.
      Scanner keyboard = new Scanner(System.in);
   
      System.out.print("Enter a number from 1 to 10: ");
      number = keyboard.nextInt();
      
      switch(number)
      {//Start of switch
         case 1: numberString = "\"one\"";
            break;
         
         case 2: numberString = "\"two\"";
            break;
      
         case 3: numberString = "\"three\"";
            break;
         
         case 4: numberString = "\"four\"";
            break;         
      
         case 5: numberString = "\"five\"";
            break;
         
         case 6: numberString = "\"six\"";
            break;
         
         case 7: numberString = "\"seven\"";
            break;
         
         case 8: numberString = "\"eight\"";
            break;
         
         case 9: numberString = "\"nine\"";
            break;                                    
      
         case 10: numberString = "\"ten\"";
            break;
      }//End of switch
      
      if (number >= 1 && number <= 10)
      {
         System.out.println("The name of that number is " + numberString + ".");
      }
      else
      {
         System.out.println("I'm sorry, but " + number + " is not supported by this program.");
      }        
   }// End of main
}// End of class