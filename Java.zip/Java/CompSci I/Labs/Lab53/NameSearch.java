import java.util.Scanner;
import java.io.*;

public class NameSearch
{// Start of class
   public static void main(String[] args) throws IOException
   {// Start of main
      String[] boyNames = new String[200];
      String[] girlNames = new String[200];
      
      getNamesFromFile(boyNames, "BoyNames.txt");
      getNamesFromFile(girlNames, "GirlNames.txt");
      
      Scanner keyboard = new Scanner(System.in);
      
      System.out.print("Please enter a name: ");
      String searchName = keyboard.nextLine();
      
      boolean foundBoy = sequentialSearch(boyNames, searchName);
      boolean foundGirl = sequentialSearch(girlNames, searchName);
      
      if (foundBoy)
      {//Start of if
         System.out.println(searchName + " is a popular boy's name.");
      }//End of if
      
      if (foundGirl)
      {//Start of if
         System.out.println(searchName + " is a popular girl's name.");
      }//End of if
      
      if(!foundBoy && !foundGirl)
      {//Start of if
         System.out.print(searchName + " is not a popular name.");
      }//End of if
   }// End of main
   
   public static void getNamesFromFile(String[] array, String filename) throws IOException
   {//Start of 'getNamesFromFile' method
      int index = 0;
      
      File file = new File(filename);
      Scanner inputFile = new Scanner(file);
      
      while (inputFile.hasNext() && index < array.length)
      {//Start of while
         array[index] = inputFile.nextLine();
         index++;
      }//End of while
      inputFile.close();  
   }//End of 'getNamesFromFile' method
   
   public static boolean sequentialSearch(String[] array, String name)
   {//Start of 'sequentialSearch' method
      boolean found = false;
      
      for (int n = 0; n < array.length; n++)
      {//Start of for loop
         if (array[n].equalsIgnoreCase(name))
         {//Start of if
            found = true;
            break;
         }//End of if
      }//End of for loop
      
      return found;
   }//End of 'sequentialSearch' method
}// End of class