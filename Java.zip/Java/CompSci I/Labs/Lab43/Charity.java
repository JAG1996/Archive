public class Charity
{// Start of class

   private double total;
   private int count;
   private double smallest;
   private double largest;
   
   public Charity()
   {//Start of 'Charity' method
      total = 0;
      count = 0;
      smallest = 0;
      largest = 0;
   }//End of 'Charity' method

   public void makeContribution(double c)
   {//Start of 'makeContribution' method
      total = total + c;
      count++;
      
      if (count == 1)
      {//Start of if
         smallest = c;
         largest = c;
      }//End of if
      else
      {//Start of else
         if (c < smallest)
         {//Start of embeded if smallest
            smallest = c;
         }//End of embeded if smallest
         
         if (c > largest)
         {//Start of embeded if largest
            largest = c;
         }//End of embeded if largest
      }//End of else
   }//End of 'makeContribution' method

   public int getCount()
   {//Start of 'getCount' method
      return count;
   }//End of 'getCount' method

   public double getSmallest()
   {//Start of 'getSmallest' method
      return smallest;
   }//End of 'getSmallest' method
   
   public double getLargest()
   {//Start of 'getLargest' method
      return largest;
   }//End of 'getLargest' method

   public double getTotal()
   {//Start of 'getTotal' method
      return total;
   }//End of 'getTotal' method

   public double getAverage()
   {//Start of 'getAverage' method
      double average;
      
      if (count == 0)
      {//Start of if
         average = 0;
      }//End of if
      else
      {//Start of else
         average = (total / count);
      }//End of else
      
      return average;
   }//End of 'getAverage' method

}// End of class