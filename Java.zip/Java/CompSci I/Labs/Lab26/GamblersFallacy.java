import java.util.Random;

public class GamblersFallacy // Lab26
{// Start of class
   public static void main(String[] args)
   {// Start of main
      
      Random rand = new Random();
   
      int threeCount = 0;
      int headCount = 0;
      int tailCount = 0;
      
      int toss1 = rand.nextInt(2);
      int toss2 = rand.nextInt(2);
      int toss3 = rand.nextInt(2);
      int toss4 = rand.nextInt(2);
   
      for (int n = 1; n <= 1000; n++)
      {//Start of "tosses" for loop
         toss1 = toss2;
         toss2 = toss3;
         toss3 = toss4;
         toss4 = rand.nextInt(2);
         
         if (toss1 == 1 && toss2 == 1 && toss3 == 1)
         {//Start of "threeCount" if
            threeCount++;
            if (toss4 == 1)
            {//Start of "nested if" if
               headCount++;
            }//End of "nested if" if
            else
            {//Start of "nested if" else
               tailCount++;
            }//End of "nested if" else
         }//End of "threeCount" if
      }//End of "tosses" for loop
      
      System.out.println("In 1,000 tosses, three heads in a row");
      System.out.println("occured " + threeCount + " times. After three heads");
      System.out.println("in a row, the next toss was:");
      System.out.println("- A head " + headCount + " times, and");
      System.out.println("- A tail " + tailCount + " times.");
      
   }// End of main
}// End of class