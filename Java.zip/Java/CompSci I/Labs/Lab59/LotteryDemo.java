import java.util.Scanner;

public class LotteryDemo 
{//Start of class
   public static void main(String[] args)
   {//Start of main
      String input;                    // To hold keyboard input
      int[] userPicks = new int[5];    // User-picked lottery numbers
      int matching;                    // Number of matching digits
      
      // Create a Scanner object for keyboard input.
      Scanner keyboard = new Scanner(System.in);

      // Create a Lottery object.
      Lottery lotto = new Lottery();
      
      // Get the user's picks.
      for (int digit = 1; digit <= 5; digit++)
      {//Start of "for" loop for user's picks.
         System.out.print("Enter digit " + digit + ": ");
         userPicks[digit-1] = keyboard.nextInt();
         while (userPicks[digit-1] < 0 || userPicks[digit-1] > 9)
         {
            System.out.print("ERROR. Enter a single digit (0 - 9): ");
            userPicks[digit-1] = keyboard.nextInt();
         }
      }//End of "for" loop for user's picks.
      
      // Compare.
      matching = lotto.numMatching(userPicks);
      
      // Display the results.
      System.out.print("Your numbers:    ");
      for (int i = 0; i < userPicks.length; i++)
         System.out.print(userPicks[i] + " ");
      System.out.println();
      
      int[] lottoNums = lotto.copy();
      System.out.print("Lottery numbers: ");
      for (int i = 0; i < lottoNums.length; i++)
         System.out.print(lottoNums[i] + " ");
      System.out.println();
   
      System.out.println("Number of matching digits: " +
                         matching);
      if (matching == 5)
         System.out.println("GRAND PRIZE WINNER!!!!");
   }//End of main
}//End of class