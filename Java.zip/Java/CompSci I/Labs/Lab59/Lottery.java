import java.util.Random;

public class Lottery
{// Start of class

   private int[] lotteryNumbers = new int[5];
   
   public Lottery()
   {//Start of 'Lottery' method
      Random rand = new Random();
      for(int n = 0; n < 5; n++)
      {//Start of 'n' for loop
         lotteryNumbers[n] = rand.nextInt(9 + 1);   
      }//End of 'n' for loop
   }//End of 'Lottery' method
   
   public int numMatching(int[] picks)
   {//Start of 'numMatching' method
      int count = 0;
      for(int n = 0; n < 5; n++)
      {//Start of 'n' for loop
      if (picks[n] == lotteryNumbers[n])
      {//Start of if
         count++;
      }//End of if
      }//End of 'n' for loop           
      return count;
   }//End of 'numMatching' method

   public int[] copy()
   {//Start of 'copy' method
      return lotteryNumbers;
   }//End of 'copy' method
   
}// End of class