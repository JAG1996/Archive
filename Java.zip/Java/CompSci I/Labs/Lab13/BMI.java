import java.util.Scanner; // Needed for the Scanner class
//import javax.swing.JOptionPane;

public class BMI  //Lab13
{// Start of class
   public static void main(String[] args)
   {// Start of main
   
      double weight; //User's weight in pounds.
      double height; //User's height in inches.
      double bmi;    //User's Body Mass Index.
        
      // Create a Scanner object to read input.
      Scanner keyboard = new Scanner(System.in);
   
      System.out.println("This program will calculate your body mass index, or BMI.");
     
      System.out.print("Enter your weight in pounds: ");
      weight = keyboard.nextDouble();
     
      System.out.print("Enter your height in inches: ");
      height = keyboard.nextDouble();
     
      bmi = weight * 703 / (height * height);
     
      System.out.printf("Your body mass index (BMI) is %.1f.\n", bmi);
     
      if (bmi < 18.5)
      {
         System.out.println("You are underweight.");
      }
      else
      {
         if (bmi > 25 )
         {
            System.out.println("You are overweight.");
         }
         else
         {
            System.out.println("Your weight is optimal.");
         }
      }   
   }//End of main
}// End of class