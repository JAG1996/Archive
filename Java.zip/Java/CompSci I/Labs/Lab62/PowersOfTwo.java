public class PowersOfTwo
{// Start of class
   public static void main(String[] args)
   {// Start of main
   
   System.out.println("*** Here are the powers of two ***");
   System.out.println("2 to power                      is");
   System.out.println("----------------------------------");
   
   for (long p = 0; p <= 60; p++)
   {//Start if 'p' for loop
      long sq = (long) Math.pow(2, p);
      System.out.printf("    %2d   %,25d\n", p, sq);
      p++;
      if (((p % 3) == 0) && p != 0)
      {//Start of if
      System.out.println();
      }//End of if
      p--;
   }//End of 'p' for loop
   
   }// End of main
}// End of class