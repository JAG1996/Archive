import java.util.Scanner; // Needed for the Scanner class

public class SecondTriangle // Lab34
{// Start of class
   public static void main(String[] args)
   {// Start of main
   
      // Create a Scanner object to read input.
      Scanner keyboard = new Scanner(System.in);
      
      System.out.print("How wide should the triangle be? ");
      int wide = keyboard.nextInt();
                    
      for(int star = 0; star <= wide; star++)
      {//Start of "star" for loop
         for(int space = wide; space > 0; space--)
         {//Start of "space" for loop
            if(star < space)
            {//Start of if
               System.out.print(" ");
            }//End of if
            else
            {//Start of else
               System.out.print("*");
            }//End of else
         }//End of "space" for loop
         System.out.println();
      }//End of "star" for loop
   }// End of main
}// End of class