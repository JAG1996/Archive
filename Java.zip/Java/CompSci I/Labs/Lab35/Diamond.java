import java.util.Scanner; // Needed for the Scanner class

public class Diamond // Lab35
{// Start of class
   public static void main(String[] args)
   {// Start of main
   
      // Create a Scanner object to read input.
      Scanner keyboard = new Scanner(System.in);
      
      System.out.print("How wide should the shape be? ");
      int wide = keyboard.nextInt();
      
      System.out.println();
      
      int numRows = wide + 2;
      int midRow = numRows / 2;
   
      int diff = 0;
      for(int row = 1; row < numRows; row++)
      {//Start of "row" for loop
         for(int column = 1; column < numRows; column++)
         {//Start of "column" for loop
            if((midRow - diff <= column) && (column <= midRow + diff))
            {//Start of if
               System.out.print("*");
            }//End of if
            else
            {//Start of else
               System.out.print(" ");
            }//End of else
         }//End of "column" for loop
         System.out.println();
         if(row < midRow)
         {//Start of if
            diff++;
         }//End of if
         else
         {//Start of else
            diff--;
         }//End of else
      }//End of "row" for loop
   }// End of main
}// End of class