public class Buy100 // Lab25
{// Start of class
   public static void main(String[] args)
   {// Start of main
   
      int solutions = 0;
      
      final double COWPRICE = 10.00;
      final double DUCKPRICE = 2.00;
      final double CHICKPRICE = 0.50;
      
      int cowLimit = (int)(100.00 / COWPRICE);
      
      System.out.println(" Cows    Ducks    Chicks ");
      System.out.println("+-----------------------+");
      
      for (int cowCount = 1; cowCount <= cowLimit; cowCount++)
      {//Start of "cow" loop
         double spent = cowCount * COWPRICE;
         double moneyLeft = 100.00 - spent;
         
         int duckLimit = (int)(moneyLeft / DUCKPRICE);
         
         for (int duckCount = 1; duckCount <= duckLimit; duckCount++)
         {//Start of "duck" loop
            int chickCount = (int) (100.00 - (cowCount + duckCount));
            double totalCost = (cowCount * COWPRICE)
                             + (duckCount * DUCKPRICE)
                             + (chickCount * CHICKPRICE);
            if (totalCost == 100.00)
            {//Start of "totalCost" if
               System.out.printf(" %3d     %3d       %3d \n"
                                , cowCount, duckCount, chickCount);
               solutions++;
            }//End of "totalCost" if
         }//End of "duck" loop
      }//End of "cow" loop
      System.out.println();
      System.out.println("  " + solutions + " solutions were found.");
   }// End of main
}// End of class