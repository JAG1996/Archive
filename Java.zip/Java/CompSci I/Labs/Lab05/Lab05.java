import java.util.Scanner;

public class Lab05
{// Start of class
   public static void main(String[] args)
   {// Start of main
   
      // Create a Scanner object to read input.
     Scanner keyboard = new Scanner(System.in);
     
     int yardsInput;
     int feetInput;
     int inchesInput;
     
     int yardsOutput;
     int feetOutput;
     int inchesOutput;
     
     int tentsInput;
     int inchesTotal;
     
     System.out.print("Enter amount of     yards needed: ");
     yardsInput = keyboard.nextInt();
     
     System.out.print("Enter amount of      feet needed: ");
     feetInput = keyboard.nextInt();

     System.out.print("Enter amount of    inches needed: ");
     inchesInput = keyboard.nextInt();
     
     System.out.print("Enter amount of tents to be made: ");
     tentsInput = keyboard.nextInt();
     
     inchesTotal = tentsInput * 
          (yardsInput * 36 + feetInput * 12 + inchesInput );
     
     yardsOutput = inchesTotal / 36;
     inchesTotal = inchesTotal - (yardsOutput * 36);
     feetOutput = inchesTotal / 12;
     inchesTotal = inchesTotal - (feetOutput * 12);
     inchesOutput = inchesTotal;

     System.out.println();
     System.out.println("----------------------");
     System.out.println("You will need " + yardsOutput + " yards, " + feetOutput + " feet and " + inchesOutput + " inches of material.");
     
   }//End of main
}// End of class