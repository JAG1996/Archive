import java.util.Scanner; // Needed for the Scanner class
//import javax.swing.JOptionPane;

public class PenniesForPay // Lab21
{// Start of class
   public static void main(String[] args)
   {// Start of main
   
      int pennies;
      int totalPay;
      int maxDays;
      int dayCount;
      
      // Create a Scanner object to read input.
      Scanner keyboard = new Scanner(System.in);
      
      System.out.print("How many days will you work? ");
      maxDays = keyboard.nextInt();
      
      while (maxDays < 1)
      {
         System.out.print("The number of days " +
                          "must be at least 1 \n" +
                          "Enter the number of days: ");
         maxDays = keyboard.nextInt();
      }   
      
      dayCount = 1;
      pennies = 1;
      totalPay = 0;
      
      System.out.println("Day\t\tPennies Earned");
      
      while (dayCount <= maxDays)
      {
         System.out.println(dayCount + "\t\t" + pennies);
         
         totalPay += pennies;
         dayCount++;
         pennies *= 2;
      }
      
      System.out.printf("Total pay $%,.2f\n", (totalPay / 100.0));
      
   }// End of main
}// End of class