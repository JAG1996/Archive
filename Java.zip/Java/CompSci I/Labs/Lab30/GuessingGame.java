import java.util.Scanner; //Needed for the Scanner class
import java.util.Random; //Needed for the Random class

public class GuessingGame // Lab30
{// Start of class
   public static void main(String[] args)
   {// Start of main

      int randNum;
      int guess;
      int count = 0;
      
      // Create a Scanner object to read input   
      Scanner keyboard = new Scanner(System.in);   
      
      //Create a Random object to scatter information
      Random rand = new Random();
      randNum = rand.nextInt(100) + 1;
      
      System.out.println("I'm thinking of a number between 1 and 100.");
      System.out.print("Guess what it is: ");
      guess = keyboard.nextInt();
      count++;
      
      while (guess != randNum)
      {//Start of while loop
         if (guess < randNum)
         {//Start of if
            System.out.println("No, that's too low.");
         }//End of if
         if (guess > randNum)
         {//Start of if
            System.out.println("No, that's too high.");
         }//End of if
         System.out.print("Guess again: ");
         guess = keyboard.nextInt();
         count++;
      }//End of while loop
      
      System.out.println("Congratulations! You got it in " + count + " guesses!");
      System.out.println("I was thinking of the number " + randNum + ".");      

   }// End of main
}// End of class