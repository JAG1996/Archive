public class Payroll
{// Start of class

   private String name;
   private int idNumber;
   private double payRate;
   private double hoursWorked;
   
   public Payroll(String n, int i)
   {//Start of 'Payroll' method
      name = n;
      idNumber = i;
   }//End of 'Payroll' method
   
   public void setName(String n)
   {//Start of 'setName' method
      n = name;
      return;
   }//End of 'setName' method
   
   public void setIdNumber(int i)
   {//Start of 'setIdNumber' method
      i = idNumber;
      return;
   }//End of 'setIdNumber' method
   
   public void setPayRate(double p)
   {//Start of 'setPayRate' method
      payRate = p;
      return;
   }//End of 'setPayRate' method
   
   public void setHoursWorked(double h)
   {//Start of 'setHoursWorked' method
      hoursWorked = h;
      return;
   }//End of 'setHoursWorked' method
   
   public String getName()
   {//Start of 'getName' method
      return name;
   }//End of 'getName' method
   
   public int getIdNumber()
   {//Start of 'getIdNumber' method
      return idNumber;
   }//End of 'getIdNumber' method
   
   public double getPayRate()
   {//Start of 'getPayRate' method
      return payRate;
   }//End of 'getPayRate' method
   
   public double getHoursWorked()
   {//Start of 'getHoursWorked' method
      return hoursWorked;
   }//End of 'getHoursWorked' method
   
   public double getGrossPay()
   {//Start of 'getGrossPay' method
   return (hoursWorked * payRate);
   }//End of 'getGrossPay' method 
   
}// End of class