
/**
   This program demonstrates a solution to the
   Payroll Class programming challenge.
*/

public class PayrollTest
{//Start of class
   public static void main(String[] args)
   {//Start of main() method
   
      // Variables for creating the payroll object
      String name = "John Doe";         // An employee's name
      int id = 12345;              // An employee's ID number
      double payRate = 10.0;      // An employee's pay rate
      double hoursWorked = 40;  // The number of hours worked
      
   
      // Create a Payroll object and store the data in it.
      Payroll worker = new Payroll(name, id);
      worker.setPayRate(payRate);
      worker.setHoursWorked(hoursWorked);
      
      // Display the employee's payroll data.
      System.out.println("Employee Payroll Data");
      System.out.println("Name: " + worker.getName());
      System.out.println("ID Number: " + worker.getIdNumber());
      System.out.printf("Hourly pay rate: $%.2f\n", worker.getPayRate());
      System.out.printf("Hours worked: %.1f\n", worker.getHoursWorked());
      System.out.printf("Gross pay: $%.2f\n", worker.getGrossPay());
   }//End of main() method
}//End of class