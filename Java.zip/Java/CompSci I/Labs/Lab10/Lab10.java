import java.util.Scanner;

public class DATax // Lab10
{// Start of class
   public static void main(String[] args)
   {// Start of main
   
      final int KNUTSPERSICKLE = 29;
      final int SICKLESPERGALLEON = 17;
      final double TAX_RATE = 0.045;
   
      // Create a Scanner object to read input.
     Scanner keyboard = new Scanner(System.in);
     
     System.out.print("How many Galleons? ");
     int galleonsSale = keyboard.nextInt();
     
     System.out.print("How many  Sickles? ");
     int sicklesSale = keyboard.nextInt();
          
     System.out.print("How many    Knuts? ");
     int knutsSale = keyboard.nextInt();
     
     int knutsSaleAll = knutsSale + (KNUTSPERSICKLE * sicklesSale) +
                       (KNUTSPERSICKLE * SICKLESPERGALLEON * galleonsSale);
                       
     int knutsTaxAll = (int) Math.round(knutsSaleAll * TAX_RATE);    
     
        }//End of main
}// End of class