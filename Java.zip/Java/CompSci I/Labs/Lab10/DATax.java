import java.util.Scanner;

public class DATax // Lab10
{// Start of class
   public static void main(String[] args)
   {// Start of main
   
      final int KNUTSPERSICKLE = 29;
      final int SICKLESPERGALLEON = 17;
      final double TAX_RATE = 0.045;
   
      // Create a Scanner object to read input.
     Scanner keyboard = new Scanner(System.in);
     
     System.out.print("How many Galleons? ");
     int galleonsSale = keyboard.nextInt();
     
     System.out.print("How many  Sickles? ");
     int sicklesSale = keyboard.nextInt();
          
     System.out.print("How many    Knuts? ");
     int knutsSale = keyboard.nextInt();
     
     int knutsSaleAll = knutsSale + (KNUTSPERSICKLE * sicklesSale) +
                       (KNUTSPERSICKLE * SICKLESPERGALLEON * galleonsSale);
                       
     int knutsTaxAll = (int) Math.round(knutsSaleAll * TAX_RATE);    
     
     int knutsTotalAll = knutsSaleAll + knutsTaxAll;
     
     int galleonsTax = knutsTaxAll / (KNUTSPERSICKLE * SICKLESPERGALLEON);
     knutsTaxAll = knutsTaxAll % (KNUTSPERSICKLE * SICKLESPERGALLEON);
     int sicklesTax = knutsTaxAll / KNUTSPERSICKLE;
     knutsTaxAll = knutsTaxAll % KNUTSPERSICKLE;
     int knutsTax = knutsTaxAll;
     
     int galleonsTotal = knutsTotalAll / (KNUTSPERSICKLE * SICKLESPERGALLEON);
     knutsTotalAll = knutsTotalAll % (KNUTSPERSICKLE * SICKLESPERGALLEON);
     int sicklesTotal = knutsTotalAll / KNUTSPERSICKLE;
     knutsTotalAll = knutsTotalAll % KNUTSPERSICKLE;
     int knutsTotal = knutsTotalAll;
          
    System.out.printf(" Sale: %4d Galleons, %2d Sickles, %2d Knuts\n",
                     galleonsSale, sicklesSale, knutsSale);
    System.out.printf( "  Tax: %4d Galleons, %2d Sickles, %2d Knuts\n",
                     galleonsTax, sicklesTax, knutsTax);
    System.out.println("-------------------------------------------");
    System.out.printf("Total: %4d Galleons, %2d Sickles, %2d Knuts\n",
                      galleonsTotal, sicklesTotal, knutsTotal);
     
        }//End of main
}// End of class