import java.util.Scanner;
import java.io.*;

public class PictureFromData
{// Start of class
   public static void main(String[] args) throws IOException
   {// Start of main
      
      String[][] array = new String[23][63];
            
      for(int r = 0; r < 23; r++)
      {//Start of 'r' for loop
         for(int c = 0; c < 63; c++)
         {//Start of 'c' for loop
            array[r][c] = " ";
         }//End of 'c' for loop
      }//End of 'r' for loop
      
      File file = new File("PictureData.txt");
      Scanner inputFile = new Scanner(file);
      
         for(int i = 0; i < 320; i++)
         {//Start of 'i' for loop
            int row = inputFile.nextInt();
            int column = inputFile.nextInt();
            String s = inputFile.next();
            array[row][column] = s;
         }//End of 'i' for loop
         
         for(int r = 0; r < 23; r++)
         {//Start of 'r' for loop
            for(int c = 0; c < 63; c++)
            {//Start of 'c' for loop
               System.out.print(array[r][c]);
            }//End of 'c' for loop
            System.out.println();
         }//End of 'r' for loop
            
      inputFile.close();
            
   }// End of main
}// End of class