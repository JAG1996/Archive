import java.util.Scanner; // Needed for the Scanner class
//import javax.swing.JOptionPane;

public class PayRates // Lab15
{// Start of class
   public static void main(String[] args)
   {// Start of main
   
      final int HOURSPERWEEK = 40;
      final int WEEKSPERYEAR = 52;
      final int MONTHSPERYEAR = 12;
      
   // Create a Scanner object to read input.
      Scanner keyboard = new Scanner(System.in);
   
      double hourPay;
      double weekPay;
      double monthPay;
      double yearPay;
   
      int howPaid;
   
      System.out.println("How are you paid?");
      System.out.println("- If by the hour .... enter 1");
      System.out.println("- If by the week .... enter 2");
      System.out.println("- If by the month ... enter 3");
      System.out.println("- If by the year .... enter 4");
      System.out.print(">>>>>>>> ");
      howPaid = keyboard.nextInt();
   
      if (howPaid == 1)
      {
         System.out.print("How much are you paid per hour? ");
         hourPay = keyboard.nextDouble();
      
         weekPay = hourPay * HOURSPERWEEK;
         yearPay = weekPay * WEEKSPERYEAR;
         monthPay = yearPay / MONTHSPERYEAR;
      
         System.out.printf("Being paid $%,.2f per hour is equivalent to:\n", hourPay);
         System.out.printf("$%,.2f per week, or \n", weekPay);
         System.out.printf("$%,.2f per month, or \n", monthPay);
         System.out.printf("$%,.2f per year. \n", yearPay);
      }
      else if (howPaid == 2)
      {
         System.out.print("How much are you paid per week? ");
         weekPay = keyboard.nextDouble();
      
         hourPay = weekPay / HOURSPERWEEK;
         yearPay = weekPay * WEEKSPERYEAR;
         monthPay = yearPay / MONTHSPERYEAR;
      
         System.out.printf("Being paid $%,.2f per week is equivalent to:\n", weekPay);
         System.out.printf("$%,.2f per hour, or \n", hourPay);
         System.out.printf("$%,.2f per month, or \n", monthPay);
         System.out.printf("$%,.2f per year. \n", yearPay);
      }
      else if (howPaid == 3)
      {
         System.out.print("How much are you paid per month? ");
         monthPay = keyboard.nextDouble();
      
         yearPay = monthPay * MONTHSPERYEAR;
         weekPay = yearPay / WEEKSPERYEAR;
         hourPay = weekPay / HOURSPERWEEK;
      
         System.out.printf("Being paid $%,.2f per month is equivalent to:\n", monthPay);
         System.out.printf("$%,.2f per hour, or \n", hourPay);
         System.out.printf("$%,.2f per week, or \n", weekPay);
         System.out.printf("$%,.2f per year. \n", yearPay);
      }
      else if (howPaid == 4)
      {
         System.out.print("How much are you paid per year? ");
         yearPay = keyboard.nextDouble();
      
         monthPay = yearPay / MONTHSPERYEAR;
         weekPay = yearPay / WEEKSPERYEAR;
         hourPay = weekPay / HOURSPERWEEK;
      
         System.out.printf("Being paid $%,.2f per year is equivalent to:\n", yearPay);
         System.out.printf("$%,.2f per hour, or \n", hourPay);
         System.out.printf("$%,.2f per week, or \n", weekPay);
         System.out.printf("$%,.2f per month. \n", monthPay);
      }
      else
      {
         System.out.println("This program only supports 1 through 4, but you entered " + howPaid + ".");
      }
   }// End of main
}// End of class