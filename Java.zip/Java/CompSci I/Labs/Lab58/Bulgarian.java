import java.util.ArrayList;
import java.util.Random;

public class Bulgarian
{// Start of class
   public static void main(String[] args)
   {// Start of main
      ArrayList<Integer> piles = createPiles();
      printPiles(piles);   
      
      while (!finalConfig(piles))
      {//Start of while loop
         rearrangePiles(piles);
         printPiles(piles);
      }//End of while loop
      
      System.out.println("Done");          
   }// End of main
   
   public static ArrayList<Integer> createPiles()
   {//Start of 'ArrayList' method
      ArrayList<Integer> piles = new ArrayList<Integer>();
      Random rand = new Random();
      int numberOfCoins = 15;
      
      while (numberOfCoins > 0)
      {//Start of while loop
         int temp = 1 + rand.nextInt(numberOfCoins);
         piles.add(temp);
         numberOfCoins = numberOfCoins - temp;
      }//End of while loop
      
      return piles;
   }//End of 'ArrayList' method
   
   public static void printPiles(ArrayList<Integer> piles)
   {//Start of 'printPiles' method
      System.out.print("The piles are: ");
      for (int n = 0; n < piles.size(); n++)
      {//Start of 'n' for loop
         System.out.printf("%2d ", piles.get(n));
      }//End of 'n' for loop
      System.out.println();
   }//End of 'printPiles' method
   
   public static boolean finalConfig(ArrayList<Integer> piles)
   {//Start of 'finalConfig' method
      if (piles.size() != 5) return false;
      if (piles.get(0) != 1) return false;
      if (piles.get(1) != 2) return false;
      if (piles.get(2) != 3) return false;
      if (piles.get(3) != 4) return false;
      if (piles.get(4) != 5) return false;
      
      return true;
   }//End of 'finalConfig' method
   
   public static void rearrangePiles(ArrayList<Integer> piles)
   {//Start of 'rearrangePiles' method
      int incomingSize = piles.size();
      
      for(int n = piles.size() - 1; n >= 0; n--)
      {//Start of 'n' for loop
         int count = piles.get(n);
         if (count == 1)
         {//Start of if
            piles.remove(n);
         }//End of if
         else
         {//Start of else
            piles.set(n, count - 1);
         }//End of else
      }//End of 'n' for loop
      
      piles.add(incomingSize);
   }//End of 'rearrangePiles' method
}// End of class