import java.util.Scanner;

public class Lab04
{// Start of class
   public static void main(String[] args)
   {// Start of main
   
   double miles;
   double gallons;
   double mpg;
      
      Scanner keyboard = new Scanner(System.in);
      
      System.out.print("Enter the miles driven:");
      miles = keyboard.nextDouble();
            
      System.out.print("Enter the gallons used:");
      gallons = keyboard.nextDouble();
      
      mpg = miles / gallons;
      
      /////////////////////////////
      
      System.out.println("The MPG is " + mpg);
      
   }//End of main
}// End of class