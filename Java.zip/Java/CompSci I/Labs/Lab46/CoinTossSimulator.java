public class CoinTossSimulator // Lab46 Test
{// Start of class
   public static void main(String[] args)
   {// Start of main
      
      final int NUM_TOSSES = 10000;
      final double TARGET = 0.8;
      int count = 0;
      
      Coin penny1 = new Coin(0.01);
      Coin penny2 = new Coin(0.01);
      Coin penny3 = new Coin(0.01);
      Coin penny4 = new Coin(0.01);
      Coin penny5 = new Coin(0.01);
      
      Coin nickel1 = new Coin(0.05);
      Coin nickel2 = new Coin(0.05);
      Coin nickel3 = new Coin(0.05);
      Coin nickel4 = new Coin(0.05);
      
      Coin dime1 = new Coin(0.1);
      Coin dime2 = new Coin(0.1);
      Coin dime3 = new Coin(0.1);
      
      Coin quarter1 = new Coin(0.25);
      Coin quarter2 = new Coin(0.25);
      
      for (int n = 1; n <= NUM_TOSSES; n++)
      {//Start of for loop
         
         penny1.toss();
         penny2.toss();
         penny3.toss();
         penny4.toss();
         penny5.toss();
         
         nickel1.toss();
         nickel2.toss();
         nickel3.toss();
         nickel4.toss();
         
         dime1.toss();
         dime2.toss();
         dime3.toss();
        
         quarter1.toss();
         quarter2.toss();
         
         double total = ( penny1.getCont() 
                        + penny2.getCont()
                        + penny3.getCont()
                        + penny4.getCont()
                        + penny5.getCont()
                        + nickel1.getCont()
                        + nickel2.getCont()
                        + nickel3.getCont()
                        + nickel4.getCont()
                        + dime1.getCont()
                        + dime2.getCont()
                        + dime3.getCont()
                        + quarter1.getCont()
                        + quarter2.getCont()                 
                        );
                        
         if (total >= TARGET)
         {//Start of if
            count++;
         }//End of if
         
      }//End of for loop
      
      double pc = 100.0 * ((double) count / NUM_TOSSES);
      
      System.out.printf("That mixture of coins "
          + "exceeds $%4.2f about %.1f%% of the time.\n", 
            TARGET, pc); 
   }// End of main
}// End of class