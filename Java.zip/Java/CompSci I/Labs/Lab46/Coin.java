import java.util.Random;

public class Coin // Lab46 Class
{// Start of class
   
   private double value;
   private int sideUp;
   private Random rand;
   
   public Coin(double v)
   {//Start of 'Coin' method
      value = v;
      rand = new Random();
      toss();
   }//End of 'Coin' method 
    
   public void toss()
   {//Start of 'toss' method
      sideUp = rand.nextInt(2);
   }//End of 'toss' method
   
   public double getCont()
   {//Start of 'getCont' method
      return (sideUp * value);
   }//End of 'getCont' method  
   
}// End of class