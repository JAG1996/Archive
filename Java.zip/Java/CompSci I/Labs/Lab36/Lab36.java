import java.util.Scanner;

public class Lab36 // Compare Pay Rates (again)
{//Start of class
   public static void main(String[] args)
   {//Start of main
      Scanner keyboard = new Scanner(System.in);
      
      final int HOURSPERWEEK = 40;
      final int WEEKSPERYEAR = 52;
      final int MONTHSPERYEAR = 12;
      
      double hourPay;
      double weekPay;
      double monthPay;
      double yearPay;
      
      int howPaid;
      
      System.out.println("How are you paid?");
      System.out.println("- If by the hour .... enter 1");
      System.out.println("- If by the week .... enter 2");
      System.out.println("- If by the month ... enter 3");
      System.out.println("- If by the year .... enter 4");
      System.out.print(">>>> ");
      howPaid = keyboard.nextInt();
      
      if (howPaid == 1)
      {//Start of hour
         System.out.print("How much are you paid per hour? ");
         hourPay = keyboard.nextDouble();
         
         weekPay = hourPay * HOURSPERWEEK;
         yearPay = weekPay * WEEKSPERYEAR;
         monthPay = yearPay / MONTHSPERYEAR;
         
         showPays(yearPay, monthPay, weekPay, hourPay);                 
      }//End of hour
      else if (howPaid == 2)
      {//Start of week
         System.out.print("How much are you paid per week? ");
         weekPay = keyboard.nextDouble();
         
         hourPay = weekPay / HOURSPERWEEK;
         yearPay = weekPay * WEEKSPERYEAR;
         monthPay = yearPay / MONTHSPERYEAR;
         
         showPays(yearPay, monthPay, weekPay, hourPay);                                 
      }//End of week
      else if (howPaid == 3)
      {//Start of month
         System.out.print("How much are you paid per month? ");
         monthPay = keyboard.nextDouble();
         
         yearPay = monthPay * MONTHSPERYEAR;
         weekPay = yearPay / WEEKSPERYEAR;
         hourPay = weekPay / HOURSPERWEEK;         
         
         showPays(yearPay, monthPay, weekPay, hourPay);                                 
      }//End of month
      else if (howPaid == 4)
      {//Start of year
         System.out.print("How much are you paid per year? ");
         yearPay = keyboard.nextDouble();
         
         monthPay = yearPay / MONTHSPERYEAR;
         weekPay = yearPay / WEEKSPERYEAR;
         hourPay = weekPay / HOURSPERWEEK;
         
         showPays(yearPay, monthPay, weekPay, hourPay);                                 
      }//End of year
      else
      {//Start of error
         System.out.println("I'm sorry, only 1 thru 4 are supported.");
      }//End of error
   }//End of main           

   public static void showPays(double year, double month, double week, double hour)
   {//Start of "showPays" method
      System.out.println("These are equivalent:");
      System.out.println(dollar13(hour) + " per hour");
      System.out.println(dollar13(week) + " per week");
      System.out.println(dollar13(month) + " per month");
      System.out.println(dollar13(year) + " per year");
   }//End of "showPays" method

   public static String dollar13(double amount)
   {//Start of "dollar13" method
      String str = String.format("$%,.2f", amount);
      int s = 13 - str.length();
      for (int n = 1;n <= s; n++)
      {//Start of for loop
         str = " " + str;
      }//End of for loop
      return str;
   }//End of "dollar13" method
}//End of class