import java.util.Scanner; // Needed for the Scanner class
//import javax.swing.JOptionPane;

public class ShippingCharges // Lab16
{// Start of class
   public static void main(String[] args)
   {// Start of main
   
      double weight;
      double distance;
     
         // Create a Scanner object to read input.
      Scanner keyboard = new Scanner(System.in);
   
      System.out.print("Enter the weight, in pounds: ");
      weight = keyboard.nextDouble();
        
      System.out.print("Enter the distance to ship, in miles: ");
      distance = keyboard.nextDouble();
   
      double priceRateVariable = (distance / 500);
      int priceRateVariableDouble = (int) (priceRateVariable + 1);
           
            // 2 pounds or less
      
      if (weight <= 2)
      {
         double priceRate = 1.1;
         double charges = (priceRate * priceRateVariableDouble);
      
         System.out.printf("The shipping charges are $%,.2f", charges);   
      }
      
            // Between 2 pounds and 6 pounds
      
      else if (weight > 2 && weight <= 6)
      {
         double priceRate = 2.2;
         double charges = (priceRate * priceRateVariableDouble);
      
         System.out.printf("The shipping charges are $%,.2f", charges);   
      }
         
            // Between 6 pounds and 10 pounds
      
      else if (weight > 6 && weight <= 10)
      {
         double priceRate = 3.7;
         double charges = (priceRate * priceRateVariableDouble);
      
         System.out.printf("The shipping charges are $%,.2f", charges);   
      }
         
            // Over 10 pounds
               
      else if (weight > 10)
      {
         double priceRate = 3.8;
         double charges = (priceRate * priceRateVariableDouble);
      
         System.out.printf("The shipping charges are $%,.2f", charges);   
      }
      
   }// End of main
}// End of class