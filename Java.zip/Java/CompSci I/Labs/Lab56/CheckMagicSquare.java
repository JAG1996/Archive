public class CheckMagicSquare
{
   public static void main(String[] args)
   {
      // Here is a "non-magic" two-dimensional array.
      int[][] normalArray = { {1, 2, 3},
                              {4, 5, 6},
                              {7, 8, 8} };
   
      // Here is a magic square in a two-dimensional array.
      int[][] magicArray = { {4, 3, 8},
                             {9, 5, 1},
                             {2, 7, 6} };
   
      // Display the normal array.
      showArray(normalArray);
   
      // Test the normal array and display the result.
      if (isMagicSquare(normalArray))
         System.out.println("This is a Lo Shu magic square.");
      else   
         System.out.println("This not is a Lo Shu magic square.");
    
      // Display the magic array.
      showArray(magicArray);
   
      // Test the magic array and display the result.
      if (isMagicSquare(magicArray))
         System.out.println("This is a Lo Shu magic square.");
      else   
         System.out.println("This not is a Lo Shu magic square.");
   }

   /**
      The showArray method accepts a two-dimensional
      int array and displays its contents.
      @param array The two-dimensional array reference.
    */

   private static void showArray(int[][] array)
   {//Start of method
      for(int n = 0; n < array.length; n++)
      {//Start of 'n' for loop
         for(int z = 0; z < array.length; z++)
         {//Start of 'z' for loop
            System.out.print(array[n][z]);
            System.out.print(" ");
         }//End of 'z' for loop
         System.out.println();
      }//End of 'n' for loop
      return;
   }//End of method

   /**
      The isMagicSquare method accepts a two-dimensional
      int array as an argument, and returns true if the
      array meets all the requirements of a magic square.
      Otherwise it returns false.  The requirements are:
      - The array contains each of the numbers 1 through 9.
      - Each row adds up to 15.
      - Each column adds up to 15.
      - Each diagonal adds up to 15.
    */

   private static boolean isMagicSquare(int[][] array)
   {//Start of method
      
      int total = 0;
      
      for (int r = 0; r < 3; r++)
      {//Start of for
         total = 0;
         for (int c = 0; c < 3; c++)
         {//Start of for
            total += array[r][c];
         }//End of for
         if (total != 15)
         {//Start of if
            break;
         }//End of if
      }//End of for
      
      if (total == 15)
      {//Start of outer if
         for (int c = 0; c < 3; c++)
         {//Start of for
            total = 0;
            for (int r = 0; r < 3; r++)
            {//Start of for
               total += array[r][c];
            }//End of for
            if (total != 15)
            {//Start of if
               break;
            }//End of if
         }//End of for
      }//End of outer if
      
      if (total == 15)
      {//Start of outer if
         total = array[0][0] + array[1][1] + array[2][2];
         if (total != 15)
         {//Start of if
            return false;
         }//End of if
      }//End of outer if
      
      if (total == 15)
      {//Start of outer if
         total = array[0][2] + array[1][1] + array[2][0];
         if (total != 15)
         {//Start of if
            return false;
         }//End of if
      }//End of outer if
      
      if (total == 15)
      {//Start of if
         return true;
      }//End of if
      
      else
      {//Start of else
         return false;
      }//End of else
      
   }//End of method

}