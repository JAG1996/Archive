import javax.swing.JOptionPane;

public class StockCom // Lab11
{// Start of class
   public static void main(String[] args)
   {// Start of main
          
     double stock = 600;
     double price = 21.77;
     double commission = 0.02;     
              
     double stockTotal = (stock * price);
     double commissionPercent = ((stock * price) * commission);
     double amountTotal = ((stock * price) + commissionPercent);
      
     String shares;
     String pricePerShare;
     String totalTotal;
     
     JOptionPane.showMessageDialog(null, String.format
     ("The amount Kathryn paid for the stock alone is $%,5.2f\n", stockTotal));

     JOptionPane.showMessageDialog(null, String.format
     ("The amount of commission is $%,5.2f\n", commissionPercent));

     JOptionPane.showMessageDialog(null, String.format
     ("The amount Kathryn paid total is $%,5.2f\n", amountTotal));
     
     shares =
     JOptionPane.showInputDialog ("Enter number of shares:");
     double sharesDouble = Double.parseDouble( shares );
          
     pricePerShare = 
     JOptionPane.showInputDialog ("Enter the price per share:");
     double pricePerShareDouble = Double.parseDouble( pricePerShare );
     
     double stockCost = (sharesDouble * pricePerShareDouble);
     double totalCommission = ((sharesDouble * pricePerShareDouble) * commission);
     double totalCost = ((sharesDouble * pricePerShareDouble) + totalCommission);
     
     JOptionPane.showMessageDialog(null, String.format
     ("Stock cost: $%,8.2f\n Commission: $%,5.2f\n Total: $%,8.2f\n", stockCost, totalCommission, totalCost));
               
     System.exit(0); 
   }//End of main
}// End of class