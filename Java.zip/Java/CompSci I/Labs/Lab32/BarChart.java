import java.util.Scanner; // Needed for the Scanner class

public class BarChart // Lab32
{// Start of class
   public static void main(String[] args)
   {// Start of main
   
      double store1;
      double store2;
      double store3;
      double store4;
      double store5;
            
      String chart1 = "";
      String chart2 = "";
      String chart3 = "";
      String chart4 = "";
      String chart5 = "";
                 
      // Create a Scanner object to read input.
      Scanner keyboard = new Scanner(System.in);
      
      System.out.print("Enter today's sales for store 1: ");
      store1 = keyboard.nextDouble();
      
      System.out.print("Enter today's sales for store 2: ");
      store2 = keyboard.nextDouble();
      
      System.out.print("Enter today's sales for store 3: ");
      store3 = keyboard.nextDouble();
      
      System.out.print("Enter today's sales for store 4: ");
      store4 = keyboard.nextDouble();
      
      System.out.print("Enter today's sales for store 5: ");
      store5 = keyboard.nextDouble();

      //Store 1
      int barCount = 0;
      int basicCount = 0;
      int chartCount = 0;
      while (barCount < store1)
      {//Start of while loop
         barCount = barCount + 100;
         basicCount++;
      }//End of while loop
      if (barCount != store1)
      {//Start of if
         barCount = barCount - 100;
         basicCount--;
      }//End of if
      while (chartCount != basicCount)
      {//Start of while loop
         chartCount++;
         chart1 = chart1 + "*";
      }//End of while loop

      //Store 2
      barCount = 0;
      basicCount = 0;
      chartCount = 0;
      while (barCount < store2)
      {//Start of while loop
         barCount = barCount + 100;
         basicCount++;
      }//End of while loop
      if (barCount != store2)
      {//Start of if
         barCount = barCount - 100;
         basicCount--;
      }//End of if
      while (chartCount != basicCount)
      {//Start of while loop
         chartCount++;
         chart2 = chart2 + "*";
      }//End of while loop

      //Store 3
      barCount = 0;
      basicCount = 0;
      chartCount = 0;
      while (barCount < store3)
      {//Start of while loop
         barCount = barCount + 100;
         basicCount++;
      }//End of while loop
      if (barCount != store3)
      {//Start of if
         barCount = barCount - 100;
         basicCount--;
      }//End of if
      while (chartCount != basicCount)
      {//Start of while loop
         chartCount++;
         chart3 = chart3 + "*";
      }//End of while loop

      //Store 4
      barCount = 0;
      basicCount = 0;
      chartCount = 0;
      while (barCount < store4)
      {//Start of while loop
         barCount = barCount + 100;
         basicCount++;
      }//End of while loop
      if (barCount != store4)
      {//Start of if
         barCount = barCount - 100;
         basicCount--;
      }//End of if
      while (chartCount != basicCount)
      {//Start of while loop
         chartCount++;
         chart4 = chart4 + "*";
      }//End of while loop

      //Store 5
      barCount = 0;
      basicCount = 0;
      chartCount = 0;
      while (barCount < store5)
      {//Start of while loop
         barCount = barCount + 100;
         basicCount++;
      }//End of while loop
      if (barCount != store5)
      {//Start of if
         barCount = barCount - 100;
         basicCount--;
      }//End of if
      while (chartCount != basicCount)
      {//Start of while loop
         chartCount++;
         chart5 = chart5 + "*";
      }//End of while loop
                  
      System.out.println("SALES BAR CHART");
      System.out.println("Store 1: " + chart1);
      System.out.println("Store 2: " + chart2);
      System.out.println("Store 3: " + chart3);
      System.out.println("Store 4: " + chart4);
      System.out.println("Store 5: " + chart5);
               
   }// End of main
}// End of class