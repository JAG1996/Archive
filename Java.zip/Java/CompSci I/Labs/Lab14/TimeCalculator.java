import java.util.Scanner; // Needed for the Scanner class
import javax.swing.JOptionPane;

public class TimeCalculator // Lab14
{// Start of class
   public static void main(String[] args)
   {// Start of main
   
      String seconds;
   
      double secondsInput;
   
   // Create a Scanner object to read input.
      Scanner keyboard = new Scanner(System.in);
   
      seconds = 
         JOptionPane.showInputDialog ("Enter the number of seconds:");
      secondsInput = Double.parseDouble( seconds );
   
      double minutes = (secondsInput / 60);
      double hours = (secondsInput / 3600);
      double days = (secondsInput / 86400);
      
      if (secondsInput < 60)
      {
         JOptionPane.showMessageDialog(null, "There are " + seconds + " seconds.");
      }
      else
      {
         if(secondsInput < 3600)
         {
            JOptionPane.showMessageDialog(null, "There are " + minutes + " minutes in " + seconds + " seconds.");
         }
         else
         {
            if (secondsInput < 86400)
            {
               JOptionPane.showMessageDialog(null, "There are " + hours + " hours in " + seconds + " seconds.");
            }
            else
            {
               if (secondsInput > 86399)
               {
                  JOptionPane.showMessageDialog(null, "There are " + days + " days in " + seconds + " seconds.");                      
               }  
            }
         }
      }   
      System.exit(0);
   }// End of main
}// End of class