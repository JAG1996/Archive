public class SumOfLeastValues
{//Start of class
   public static void main(String[] args)
   {//Start of main() method.
      // Here is the 8 by 5 array of values.
      int[][] values =  { {45,    22,   67,   99,   13}, 
                          {15,    51,   31,   61,    8},
                          {28,    38,   50,   79,   61},
                          {27,    91,   30,    7,   14},
                          {44,    36,   39,   40,   30},
                          {29,    16,   44,   28,   92},
                          {28,     9,   39,   73,   55},
                          {85,    94,   47,   48,   11}  };
      
      int total = 0;
      
      for(int row = 0; row < 8; row++)
      {//Start of 'row' for loop
         int smallest = values[row][0];
         for (int col = 1; col < 5; col++)
         {//Start of embedded 'col' for loop
            if (values[row][col] < smallest)
            {//Start of if
               smallest = values[row][col];
            }//End of if
         }//End of embedded 'col' for loop
         total += smallest;
      }//End of 'row' for loop
      
      System.out.println("The sum of the smallest values is " + total + ".");
   }//End of main() method
}//End of class