import java.util.Scanner;

public class Lab08
{// Start of class
   public static void main(String[] args)
   {// Start of main
   
  final int HOURSPERWEEK = 40;
  final int MONTHSPERYEAR = 12;
  final int WEEKSPERYEAR = 52;
   
      // Create a Scanner object to read input.
     Scanner keyboard = new Scanner(System.in);
     
     double  hourPay;
     double  weekPay;
     double monthPay;
     double  yearPay;
     
     System.out.print("How much are you paid per hour? ");
     hourPay = keyboard.nextDouble();
     
     weekPay  = hourPay * HOURSPERWEEK;
     yearPay  = weekPay * WEEKSPERYEAR;
     monthPay = yearPay / MONTHSPERYEAR;
     
     System.out.printf("Being paid an hourly rate of:     $%,.2f\n", hourPay);
     System.out.printf("Is equivalent to a weekly pay of: $%,.2f\n", weekPay);
     System.out.printf("Or a monthly pay of:              $%,.2f\n", monthPay);
     System.out.printf("Or a yearly pay of:               $%,.2f\n", yearPay);

   }//End of main
}// End of class