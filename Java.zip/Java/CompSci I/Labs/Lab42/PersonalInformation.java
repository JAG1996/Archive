public class PersonalInformation // Lab42 A
{// Start of class

        private String name;
        private String address;
        private int age;
        private String phone;
        
        public PersonalInformation()
        {
            name = "";
            address = "";
            age = 0;
            phone = "";
        }
        
        public PersonalInformation(String myName, String myAddress, int myAge, String myPhone)
        {
         name = myName;
         address = myAddress;
         age = myAge;
         phone = myPhone;
        }
        
        public void setName(String myName)
        {
            name = myName;
        }
        
        public void setAge(int myAge)
        {
            age = myAge;
        }
        
        public void setAddress(String myAddress)
        {
            address = myAddress;
        }
        
        public void setPhone(String myPhone)
        {
            phone = myPhone;
        }
        
        public String getName()
        {
            return name;
        }
        
        public int getAge()
        {
            return age;
        }
        
        public String getAddress()
        {
            return address;
        }
        
        public String getPhone()
        {
            return phone;
        }
}// End of class