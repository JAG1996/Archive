public class SavingsAccountTest // Lab44
{//Start of class
   public static void main(String args[])
   {//Start of main method
      double interestRate;       // Annual interest rate
      double balance;            // Starting balance
      double deposits;           // Amount of deposits for a month
      double withdrawn;          // Amount withdrawn in a month
      double intEarned = 0.0;    // Interest earned
      double totalDeposits = 0;  // Deposit accumulator
      double totalWithdrawn = 0; // Withdrawal accumulator
      final int MONTHS = 24;     // Months in the simulation
      final double INITIALBALANCE = 1000.00; //Strating balance

      balance = INITIALBALANCE;

      // ANNUAL rate of interest.
      interestRate = 0.04;
      
      // Create a SavingsAccount object.
      SavingsAccount savings =
             new SavingsAccount(balance, interestRate);
             
      // Get the deposits and withdrawals for each month.
      for (int i = 1; i <= MONTHS; i++)
      {//Start of "for" loop
         // Get the deposits
         deposits = 100;
         totalDeposits += deposits;

         // Get the withdrawals.
         withdrawn = 50;
         totalWithdrawn += withdrawn;
         
         // Add the deposits to the account.
         savings.deposit(deposits);
         
         // Subtract the withdrawals.
         savings.withdraw(withdrawn);
         
         // Add the monthly interest.
         savings.addInterest();
         
         // Accumulate the amount of interest earned.
         intEarned += savings.getLastInterest();
      }//End of loop

      // Display the totals and the balance.    
      System.out.printf("Initial balance:\t$%8.2f\n", INITIALBALANCE);
      System.out.printf("Total deposited:\t$%8.2f\n", totalDeposits);
      System.out.printf("Total withdrawn:\t$%8.2f\n", totalWithdrawn);
      System.out.printf("Interest earned:\t$%8.2f\n", intEarned);
      System.out.printf("Ending balance: \t$%8.2f\n", savings.getBalance());
   }//End of main method
}//End of class