public class SavingsAccount // Lab44
{// Start of class
   
   private double withdraw;
   private double deposit;
   private double lastInterest;
   private double interestRate;
   private double internalBalance;

   public SavingsAccount(double balance, double intRate)
   {//Start of 'SavingsAccount' method
      interestRate = intRate;
      internalBalance = balance;
   }//End of 'SavingsAccount' method

   public void withdraw(double amount)
   {//Start of 'withdraw' method
      withdraw = amount;
      internalBalance -= withdraw;
      return;
   }//End of 'withdraw' method
   
   public void deposit(double amount)
   {//Start of 'deposit' method
      deposit = amount;
      internalBalance += deposit;
      return;
   }//End of 'deposit' method
   
   public void addInterest()
   {//Start of 'addInterest' method
      lastInterest = (interestRate / 12);
      lastInterest *= internalBalance;
      internalBalance += lastInterest;
      return;
   }//End of 'addInterest' method
   
   public double getBalance()
   {//Start of 'getBalance' method
      return internalBalance;
   }//End of 'getBalance' method
   
   public double getInterestRate()
   {//Start of 'getInterestRate' method
      return interestRate;
   }//End of 'getInterestRate' method
   
   public double getLastInterest()
   {//Start of 'getLastInterest' method
      return lastInterest;
   }//End of 'getLastInterest' method
   
}// End of class