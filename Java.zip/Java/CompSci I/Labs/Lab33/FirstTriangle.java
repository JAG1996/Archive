import java.util.Scanner; // Needed for the Scanner class

public class FirstTriangle // Lab33
{// Start of class
   public static void main(String[] args)
   {// Start of main
   
      // Create a Scanner object to read input.
      Scanner keyboard = new Scanner(System.in);
      
      System.out.print("How wide should the triangle be? ");
      int wide = keyboard.nextInt();
      
      for (int count = 0; count <= wide; count++)
      {//Start of "wide" for loop
         for (int innerCount = 0; innerCount < count; innerCount++)
         {//Start of "innerCount" for loop 
            System.out.print("*");
         }//End of "innerCount" for loop
            System.out.println();
      }//End of "wide" for loop
   }// End of main
}// End of class