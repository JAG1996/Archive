public class ASCIITable // Lab41
{// Start of class
   public static void main(String[] args)
   {// Start of main
      System.out.println("This will print out the ASCII character set.");
      System.out.println();
      System.out.print("    |");
      for (int col = 0; col <= 15; col++)
      {//Start of "col" for loop
         System.out.printf(" %1s_ |", getDigit(col));
      }//End of "col" for loop
      System.out.println();
      
      System.out.print("----+");
      for (int col = 0; col <= 15; col++)
      {//Start of "col" for loop
         System.out.printf("----+");
      }//End of "col" for loop
      System.out.println();
      
      for(int row = 0; row <= 15; row++)
      {//Start of "row" for loop
         System.out.printf(" _%1s |", getDigit(row));
         for (int col = 0; col <= 15; col++)
         {//Start of "col" for loop
            char ch = (char) ((col * 16) + row);
            if (Character.isISOControl(ch))
            {//Start of if
               System.out.print(" cc |");
            }//End of if
            else
            {//Start of else
               System.out.print("  " + ch + " |");
            }//End of else
         }//End of "col" for loop
         System.out.println();
      }//End of "row" for loop
   }//End of main
   
   public static String getDigit(int d)
   {//Start of "getDigit" method
      String digit ="?";
      
      switch (d)
      {//Start of switch
         case 0:  
            digit = "0"; 
            break;
         case 1:  
            digit = "1"; 
            break;
         case 2:  
            digit = "2"; 
            break;
         case 3:  
            digit = "3"; 
            break;
         case 4:  
            digit = "4"; 
            break;
         case 5:  
            digit = "5"; 
            break;
         case 6:  
            digit = "6"; 
            break;
         case 7:  
            digit = "7"; 
            break;
         case 8:  
            digit = "8"; 
            break;
         case 9:  
            digit = "9"; 
            break;
         case 10: 
            digit = "A"; 
            break;
         case 11: 
            digit = "B"; 
            break;
         case 12: 
            digit = "C"; 
            break;
         case 13: 
            digit = "D"; 
            break;
         case 14: 
            digit = "E"; 
            break;
         case 15: 
            digit = "F"; 
            break;                                                
      }//End of switch
         
      return digit;
   }//End of "getDigit" method
}// End of class