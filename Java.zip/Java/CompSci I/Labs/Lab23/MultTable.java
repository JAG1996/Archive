import java.util.Scanner; // Needed for the Scanner class

public class MultTable // Lab23
{// Start of class
   public static void main(String[] args)
   {// Start of main
   
      // Create a Scanner object to read input.
      Scanner keyboard = new Scanner(System.in);
      
      System.out.println("This will print out a multiplication table.");
      
      System.out.print("What is the starting row? ");
      int startRow = keyboard.nextInt();
   
      System.out.print("What is the ending row? ");
      int endRow = keyboard.nextInt();
      
      System.out.print("What is the starting column? ");
      int startColumn = keyboard.nextInt();
      
      System.out.print("What is the ending column? ");
      int endColumn = keyboard.nextInt();   
      
      System.out.println();
      
      System.out.print(" X  |");
      for (int column = startColumn; column <= endColumn; column++)
      {//Start of "for" loop
         System.out.printf("%4d|", column);
      }//End of "for" loop
      System.out.println();
   
      System.out.print("----|");
      for (int column = startColumn; column <= endColumn; column++)
      {//Start of "column" for loop
         System.out.printf("----|");
      }//End of "column" for loop
      System.out.println();
   
      for (int row = startRow; row <= endRow; row++)
      {//Start of "row" for loop
         System.out.printf("%4d|", row);
         for (int column = startColumn; column <= endColumn; column++)
         {//Start of "column" for loop
            int product = row * column;
            System.out.printf("%4d|", product);
         }//End of "column" for loop
         System.out.println();
      }//End of "row" for loop
                       
   }// End of main
}// End of class