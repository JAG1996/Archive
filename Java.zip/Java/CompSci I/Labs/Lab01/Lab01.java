public class Lab01
{//Start of the class
   public static void main (String[] args)
   {//Start of main
      System.out.println("Hello, world!");
   }//End of main
}//End of the class