public class CToFTable // Lab20
{// Start of class
   public static void main(String[] args)
   {// Start of main
      double fahrenheit;
      double celsius;
      
      System.out.println("Celsius       Fahrenheit");
      System.out.println("------------------------");
      
      celsius = 0;
      while (celsius <= 20)
      {//Start of while
         fahrenheit = ((9.0/5.0) * celsius) + 32;
         System.out.printf(" %4.1f             %4.1f\n", celsius, fahrenheit);
         celsius = celsius + 1.0;
      }//End of while      
   }// End of main
}// End of class