import java.util.Scanner;

public class Lab09
{// Start of class
   public static void main(String[] args)
   {// Start of main
   
      // Create a Scanner object to read input.
     Scanner keyboard = new Scanner(System.in);
     
     System.out.println("Enter the name of your favorite city: ");
     String message = keyboard.nextLine();
    
     int stringSize = message.length();
     String upper = message.toUpperCase();
     String lower = message.toLowerCase();
     char letter = message.charAt(0);
     
     System.out.println("Number of characters in that city's name is " + stringSize + ".");
     System.out.println("That city in upper case letters is " + upper + ".");
     System.out.println("That city in lower case letters is " + lower + ".");
     System.out.println("The first character in that city's name is " + letter + ".");
   }//End of main
}// End of class