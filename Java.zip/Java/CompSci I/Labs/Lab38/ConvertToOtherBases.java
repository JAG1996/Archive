import java.util.Scanner; // Needed for the Scanner class

public class ConvertToOtherBases // Lab38
{// Start of class
   public static void main(String[] args)
   {// Start of main
   
      // Create a Scanner object to read input.
      Scanner keyboard = new Scanner(System.in);
      
      System.out.print("Please enter a positive integer in decimal: ");
      int number = keyboard.nextInt();
      
      while (number < 1)
      {//Start of "number" validation while loop
         System.out.println();
         System.out.println("Sorry, but " + number + " is not a positive integer.");
         System.out.print("Please enter a positive integer in decimal: ");
         number = keyboard.nextInt();
      }//End of "number" validation while loop
      
      System.out.print("What base (2 to 16) do you want to convert to? ");
      int base = keyboard.nextInt();
      
      while (base > 16 || base < 2)
      {//Start of "base" validation while loop
         System.out.println();
         System.out.println("Sorry, but base " + base + " is not supported.");
         System.out.print("What base (2 to 16) do you want to convert to? ");
         base = keyboard.nextInt();      
      }//End of "base" validation while loop
      
      int n = number;
      String outputString = "";
      
      while (n > 0)
      {//Start of "n" validation while loop
         int r = n % base;
         outputString = getDigit(r) + outputString;
         n = n / base;
      }//End of "n" validation while loop

      System.out.println("Decimal " + number + " is expressed in base " + base + " as " + outputString + ".");
   }// End of main
   
   public static String getDigit(int d)
   {//Start of "getDigit" method
      String digit ="?";
      
         switch (d)
         {//Start of switch
            case 0:
               digit = "0"; break;
            case 1:
               digit = "1"; break;
            case 2:
               digit = "2"; break;
            case 3:
               digit = "3"; break;
            case 4:
               digit = "4"; break;
            case 5:
               digit = "5"; break;
            case 6:
               digit = "6"; break;
            case 7:
               digit = "7"; break;
            case 8:
               digit = "8"; break;
            case 9:
               digit = "9"; break;
            case 10:
               digit = "A"; break;
            case 11:
               digit = "B"; break;
            case 12:
               digit = "C"; break;
            case 13:
               digit = "D"; break;
            case 14:
               digit = "E"; break;
            case 15:
               digit = "F"; break;                                                
         }//End of switch
         
      return digit;
   }//End of "getDigit" method
}// End of class