import java.util.Scanner;

public class AddupCoins
{// Start of class
   public static void main(String[] args)
   {// Start of main
   
      // Create a Scanner object to read input.
     Scanner keyboard = new Scanner(System.in);
     
     double quarterInput;
     double dimeInput;
     double nickelInput;
     double pennyInput;
     
     double quarterWorth = 0.25;
     double dimeWorth = 0.1;
     double nickelWorth = 0.05;
     double pennyWorth = 0.01;
     double total;
     
     double quarterTotal;
     double dimeTotal;
     double nickelTotal;
     double pennyTotal;
     
     System.out.println("This program will calculate");
     System.out.println("the value of your coins.");
     System.out.println();
     
     System.out.print("How many quarters do you have? ");
     quarterInput = keyboard.nextInt();
     
     System.out.print("How many dimes do you have? ");
     dimeInput = keyboard.nextInt();
  
     System.out.print("How many nickels do you have? ");
     nickelInput = keyboard.nextInt();
 
     System.out.print("How many pennies do you have? ");
     pennyInput = keyboard.nextInt();
     
     quarterTotal = (quarterInput * quarterWorth);
     dimeTotal = (dimeInput * dimeWorth);
     nickelTotal = (nickelInput * nickelWorth);
     pennyTotal = (pennyInput * pennyWorth);
     
     System.out.printf("%,8.0f quarters is worth $%,8.2f\n"
     , quarterInput, quarterTotal);
     
     System.out.printf("%,8.0f dimes    is worth $%,8.2f\n"
     , dimeInput, dimeTotal);
     
     System.out.printf("%,8.0f nickels  is worth $%,8.2f\n"
     , nickelInput, nickelTotal);
     
     System.out.printf("%,8.0f pennies  is worth $%,8.2f\n"
     , pennyInput, pennyTotal);
     
     total = (quarterTotal + 
     dimeTotal + nickelTotal + pennyTotal);
             
     System.out.println("------------------------------------");
     System.out.printf("              Total value: $%,8.2f\n", total);

   }//End of main
}// End of class