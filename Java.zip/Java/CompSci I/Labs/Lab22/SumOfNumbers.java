import java.util.Scanner; // Needed for the Scanner class
//import javax.swing.JOptionPane;

public class SumOfNumbers // Lab
{// Start of class
   public static void main(String[] args)
   {// Start of main
   
      int number;
      int sum = 0;
      int counter = 1;
      
      // Create a Scanner object to read input.
      Scanner keyboard = new Scanner(System.in);
         
      System.out.print("Enter a positive nonzero number: ");
      number = keyboard.nextInt();      
   
      while (number < 1)
      {//Start of while
         System.out.print("Invalid. Enter a positive nonzero number: " );
         number = keyboard.nextInt();   
      }//End of while
      while (counter != number)
      {//Start of while
         sum += counter;
         counter++;
      }//End of while
      
      sum = (sum + number);
      System.out.print("The sum of all integers from 1 to " + number + " is " + sum);
      
   }// End of main
}// End of class