import java.util.Scanner;
import java.io.*;

public class UCFileConverter // Lab28
{// Start of class
   public static void main(String[] args) throws IOException
   {// Start of main
   
      String inFilename;
      String outFilename;
      String inputLine;
      String outputLine;
      
      // Create a Scanner object to read input.
      Scanner keyboard = new Scanner(System.in);
      
      System.out.print("Enter the input file name: ");
      inFilename = keyboard.nextLine();
      
      System.out.print("Enter the output file name: ");
      outFilename = keyboard.nextLine();
      
      File file = new File(inFilename);
      Scanner inFile = new Scanner(file);
      
      PrintWriter outFile = new PrintWriter(outFilename);
      
      while (inFile.hasNext())
      {//Start of while loop
         inputLine = inFile.nextLine();
         outputLine = inputLine.toUpperCase();
         outFile.println(outputLine);
      }//End of while loop
      
      inFile.close();
      outFile.close();
      
   }// End of main
}// End of class