import java.util.Random;

public class TwoDiceDistribution // Lab51
{// Start of class
   public static void main(String[] args)
   {// Start of main
      
      int[] count = new int[13];
      int d1;
      int d2;
      int dSum;
      
      Random rand = new Random();
      
      for (int n = 1; n <= 360; n++)
      {//Start of 'n' for loop
         d1 = rand.nextInt(6) + 1;
         d2 = rand.nextInt(6) + 1;
         dSum = d1 + d2;
         count[dSum] = count[dSum] + 1;
      }//End of 'n' for loop
      
      System.out.println("Here are the results:");
      
      for (int s = 2; s <= 12; s++)
      {//Start of 's' for loop
         System.out.printf(" Sum %2d: ", s);
//         System.out.printf(count[s]);
         for (int n = 1; n <= count[s]; n++)
         {//Start of embedded 'n' for loop
            System.out.print("x");
         }//End of embedded 'n' for loop
         System.out.println();
      }//End of 's' for loop
      
   }// End of main
}// End of class