public class CheckList // Lab49
{// Start of class

   private boolean readCatalog;
   private boolean checkPrerequisites;
   private boolean registerForCourse;
   private boolean checkTimeAndPlace;
   private boolean getTextbook;
   private boolean readSyllabus;
   
   public CheckList()
   {//Start of 'CourseCheckList' method
      readCatalog = false;
      checkPrerequisites = false;
      registerForCourse = false;
      checkTimeAndPlace = false;
      getTextbook = false;
      readSyllabus = false;
   }//End of 'CourseCheckList' method
   
   public CheckList(boolean rc, boolean cp, boolean rfc, boolean ctp, boolean gt, boolean rs)
   {//Start of 'CourseCheckList' overloaded method
      readCatalog = rc;
      checkPrerequisites = cp;
      registerForCourse = rfc;
      checkTimeAndPlace = ctp;
      getTextbook = gt;
      readSyllabus = rs;
   }//End of 'CourseCheckList' overloaded method
   
   public void iReadCatalog()
   {//Start of 'iReadCatalog' method
      readCatalog = true;
   }//End of 'iReadCatalog' method
   
   public void iCheckedPrerequisites()
   {//Start of 'iCheckedPrerequisites' method
      checkPrerequisites = true;
   }//End of 'iCheckedPrerequisites' method
   
   public void iRegisteredForCourse()
   {//Start of 'iRegisteredForCourse' method
      registerForCourse = true;
   }//End of 'iRegisteredForCourse' method
   
   public void iCheckedTimeAndPlace()
   {//Start of 'iCheckedTimeAndPlace' method
      checkTimeAndPlace = true;
   }//End of 'iCheckedTimeAndPlace' method
   
   public void iGotTextbook()
   {//Start of 'iGotTextbook' method
      getTextbook = true;
   }//End of 'iGotTextbook' method
   
   public void iReadSyllabus()
   {//Start of 'iReadSyllabus' method
      readSyllabus = true;
   }//End of 'iReadSyllabus' method
   
   public boolean didIReadCatalog()
   {//Start of 'didIReadCatalog' method
      return readCatalog;
   }//End of 'didIReadCatalog' method
   
   public boolean didICheckPrerequisites()
   {//Start of 'didICheckPrerequisites' method
      return checkPrerequisites;
   }//End of 'didICheckPrerequisites' method
   
   public boolean didIRegisterForCourse()
   {//Start of 'didIRegisterForCourse' method
      return registerForCourse;
   }//End of 'didIRegisterForCourse' method
   
   public boolean didICheckTimeAndPlace()
   {//Start of 'didICheckTimeAndPlace' method
      return checkTimeAndPlace;
   }//End of 'didICheckTimeAndPlace' method
   
   public boolean didIGetTextbook()
   {//Start of 'didIGetTextbook' method
      return getTextbook;
   }//End of 'didIGetTextbook' method
   
   public boolean didIReadSyllabus()
   {//Start of 'didIReadSyllabus' method
      return readSyllabus;
   }//End of 'didIReadSyllabus' method
   
}// End of class