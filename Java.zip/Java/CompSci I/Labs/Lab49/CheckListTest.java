public class CheckListTest
{//Start of class
   public static void main(String[] args)
   {//Start of main
      CheckList calculus = new CheckList();
      CheckList speech   = new CheckList();
      CheckList german   = new CheckList(true, true, false, false, false, false);
   
      speech.iReadCatalog();
      speech.iCheckedPrerequisites();
      speech.iRegisteredForCourse();
      german.iGotTextbook();
      speech.iCheckedTimeAndPlace();
      speech.iGotTextbook();
      calculus.iReadCatalog();
      speech.iReadSyllabus();
   
      System.out.println("--- Checklist for Calculus:");
      reportStatus(calculus);
      System.out.println();
      
      System.out.println("--- Checklist for Speech:");
      reportStatus(speech);
      System.out.println();

      System.out.println("--- Checklist for German:");
      reportStatus(german);
   }//End of main
   
   public static void reportStatus(CheckList ccl)
   {
      String str;

      str = ccl.didIReadCatalog() ? "Done" : "Not yet"; 
      System.out.println("Read the catalog:              " + str);
      
      str = ccl.didICheckPrerequisites() ? "Done" : "Not yet"; 
      System.out.println("Check the prerequisites:       " + str);
      
      str = ccl.didIRegisterForCourse() ? "Done" : "Not yet"; 
      System.out.println("Register for the course:       " + str);
      
      str = ccl.didICheckTimeAndPlace() ? "Done" : "Not yet"; 
      System.out.println("Check the time and place:      " + str);
      
      str = ccl.didIGetTextbook() ? "Done" : "Not yet"; 
      System.out.println("Get the textbook:              " + str);
      
      str = ccl.didIReadSyllabus() ? "Done" : "Not yet"; 
      System.out.println("Read the syllabus:             " + str);
   }
}//End of class