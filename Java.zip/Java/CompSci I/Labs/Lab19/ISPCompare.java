import java.util.Scanner;        // For Scanner class

public class ISPCompare // Internet Service Provider Lab19
{//Start of class
   public static void main(String[] args)
   {//Start of main
      final double PACKAGE_A_BASE = 9.95;        // Package A base charge
      final double PACKAGE_B_BASE = 13.95;       // Package B base charge
      final double PACKAGE_C_BASE = 19.95;       // Package C base charge
      final double PACKAGE_A_HOURS = 10.0;       // Package A hour limit
      final double PACKAGE_B_HOURS = 20.0;       // Package B hour limit
      final double PACKAGE_A_ADDITIONAL = 2.00;  // Package A cost of additional hour
      final double PACKAGE_B_ADDITIONAL = 1.00;  // Package B cost of additional hour
   
      char ispPackage;        // Customer package
      double hours = 0;       // Hours used
      double charges = 0.0;   // Charges
      String input;           // To hold keyboard input
   
      Scanner keyboard = new Scanner(System.in);
   
      // Get the package.
      System.out.print("Enter the customer's package (A, B, or C): ");
      input = keyboard.nextLine();
      ispPackage = input.toUpperCase().charAt(0);
      
      if (ispPackage < 'A' || ispPackage > 'C') //Check package letter.
      {
         System.out.print("Invalid package. Enter A, B, or C.");
         System.exit(0);
      }
   
      if (ispPackage == 'A' || ispPackage == 'B' || ispPackage == 'C') //Get the number of hours
      {
         System.out.print("Enter the number of hours used: ");
         hours = keyboard.nextDouble();
      }
   
      switch(ispPackage)  //Calculate the charges
      {//Start of switch
         case 'A' :
            charges = PACKAGE_A_BASE;
            if (hours > PACKAGE_A_HOURS)
            {
               charges = charges + ( (hours - PACKAGE_A_HOURS) * PACKAGE_A_ADDITIONAL);
            }    
            break;
            
         case 'B' :
            charges = PACKAGE_B_BASE;
            if (hours > PACKAGE_B_HOURS)
            {
               charges = charges + ( (hours - PACKAGE_B_HOURS) * PACKAGE_B_ADDITIONAL);
            }    
            break;
            
         case 'C' :
            charges = PACKAGE_C_BASE;
      }//End of switch
      
      System.out.printf("The charges are $%,.2f.\n", charges);
      
      double savedB = (charges - PACKAGE_B_BASE);
      double savedC = (charges - PACKAGE_C_BASE);
               
   
      switch (ispPackage) // Calculate the savings
      {//Start of switch
         case 'A' :             
            if (charges <= 13.95)
            {
               System.out.println("You would not have saved anything by using another plan.");
            }
            else if (charges > 13.95 && charges <= 19.95)
            {
               System.out.printf("You could have saved $%,.2f by using plan B.\n", savedB);
            }
            else if (charges > 19.95)
            {
               System.out.printf("You could have saved $%,.2f by using plan B.\n", savedB);
               System.out.printf("You could have saved $%,.2f by using plan C.\n", savedC);
            }   
            break;
      
         case 'B' :             
            if (charges <= 19.95)
            {
               System.out.println("You would not have saved anything by using another plan.");
            }
            else if (charges > 19.95)
            {
               System.out.printf("You could have saved $%,.2f by using plan C.\n", savedC);
            }
            break;
          
         case 'C' :             
            if (charges >= 19.95)
            {
               System.out.println("You would not have saved anything by using another plan.");
            }
            break;
                              
      }//End of switch
   }//End of main
}//End of class