import java.util.Random;

public class PiggyBankTest
{//Start of class
   public static void main(String[] args)
   {//Start of main
      Random rand = new Random();
      int totalIn = 0;
      int countIn = 0;
      int totalOut = 0;
      int countOut = 0;
      
      System.out.println("Creating a piggy bank with 8 coins totalling $0.82:");
      System.out.println("2 pennies, 2 nickels, 2 dimes, and 2 quarters.");
      PiggyBank myPB = new PiggyBank(2, 2, 2, 2);
      totalIn = 82;
      countIn = 8;
            
      System.out.println("Adding 10 random coins...");
      for (int n = 1; n <= 10; n++)
      {
         countIn++;
         int r = rand.nextInt(4);
         switch (r)
         {//Start of switch
            case 0: //penny
               System.out.println("Depositing a penny.");
               myPB.addPenny();
               totalIn = totalIn + 1;
               break;      
            case 1: //nickel
               System.out.println("Depositing a nickel.");
               myPB.addNickel();
               totalIn = totalIn + 5;
               break;      
            case 2: //dime
               System.out.println("Depositing a dime.");
               myPB.addDime();
               totalIn = totalIn + 10;
               break;      
            case 3: //quarter
               System.out.println("Depositing a quarter.");
               myPB.addQuarter();
               totalIn = totalIn + 25;
               break;      
         }//End of switch
      }//End of for loop        
      System.out.printf("%d coins worth $%.2f are in the piggy bank.\n\n", 
                        countIn, totalIn/100.0);
      
      System.out.println("Now we're going to shake the coins out...");
      while (true)
      {//Start of while "shake out" loop
         int value = myPB.shakeOut();
         if (value == 0) break;
         countOut++;
         switch (value)
         {//Start of switch
            case 1:
               System.out.println("We got a penny.");
               totalOut = totalOut + 1;
               break;
            case 5:
               System.out.println("We got a nickel.");
               totalOut = totalOut + 5;
               break;
            case 10:
               System.out.println("We got a dime.");
               totalOut = totalOut + 10;
               break;
            case 25:
               System.out.println("We got a quarter.");
               totalOut = totalOut + 25;
               break;
         }//end of switch
      }//End of while "shake out" loop

      System.out.printf("We shook out %d coins worth $%.2f.\n", countOut, totalOut/100.0);

   }//End of main
}//End of class