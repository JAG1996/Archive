import java.util.Random;

public class PiggyBank // Lab50
{// Start of class

   private int pennyCount;
   private int nickelCount;
   private int dimeCount;
   private int quarterCount;
   private Random rand = new Random();
   
   public PiggyBank()
   {//Start of 'PiggyBank' method
      pennyCount = 0;
      nickelCount = 0;
      dimeCount = 0;
      quarterCount = 0;
   }//End of 'PiggyBank' method
   
   public PiggyBank(int p, int n, int d, int q)
   {//Start of 'PiggyBank' overload method
      pennyCount = p;
      nickelCount = n;
      dimeCount = d;
      quarterCount = q;
   }//End of 'PiggyBank' overload method
   
   public void addPenny()
   {//Start of 'addPenny' method
      pennyCount++;
      return;
   }//End of 'addPenny' method
   
   public void addNickel()
   {//Start of 'addNickel' method
      nickelCount++;
      return;
   }//End of 'addNickel' method
   
   public void addDime()
   {//Start of 'addDime' method
      dimeCount++;
      return;
   }//End of 'addDime' method
   
   public void addQuarter()
   {//Start of 'addQuarter' method
      quarterCount++;
      return;
   }//End of 'addQuarter' method
   
   public int shakeOut()
   {//Start of 'shakeOut' method
      int NOC = (pennyCount + nickelCount + dimeCount + quarterCount);
      
      if (NOC >= 1)
      {//Start of 'NOC' if
         int CSO = rand.nextInt(NOC) + 1;
         if (CSO <= pennyCount)
         {//Start of 'pennyCount' if
            pennyCount--;
            return 1;
         }//End of 'pennyCount' if
         
         else if (CSO <= (pennyCount + nickelCount))
         {//Start of 'nickelCount' else if
            nickelCount--;
            return 5;
         }//End of 'nickelCount' else if
         
         else if (CSO <= (pennyCount + nickelCount + dimeCount))
         {//Start of 'dimeCount' else if
            dimeCount--;
            return 10;
         }//End of 'dimeCount' else if
         
         else
         {//Start of 'quarterCount' else
            quarterCount--;
            return 25;
         }//End of 'quarterCount' else 
      }//End of 'NOC' if
      
      else
      {//Start of 'NOC' else
         return 0;
      }//End of 'NOC' else
      
   }//End of 'shakeOut' method
   
}// End of class