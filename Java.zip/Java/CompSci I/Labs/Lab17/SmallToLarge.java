import java.util.Scanner; // Needed for the Scanner class
//import javax.swing.JOptionPane;

public class SmallToLarge
{// Start of class
   public static void main(String[] args)
   {// Start of main
   
   int one;
   int two;
   int three;
   
   // Create a Scanner object to read input.
   Scanner keyboard = new Scanner(System.in);
   
   System.out.print("Enter the first number: ");
   one = keyboard.nextInt();
   
   System.out.print("Enter the second number: ");
   two = keyboard.nextInt();
   
   System.out.print("Enter the third number: ");
   three = keyboard.nextInt();
   
   System.out.println("Those numbers in order from smallest to largest are");
   
   //First Number
   
   if (one <= two && one <= three)
   {
      System.out.println(one);   
   }
   else if (two <= one && two <= three)
   {
      System.out.println(two); 
   }
   else if (three <= one && three <= two)
   {
      System.out.println(three); 
   }
   
   //Second Number
   
   if (one <= two && one >= three)
   {
      System.out.println(one);   
   }
   else if (one >= two && one <= three)
   {
      System.out.println(one);   
   }
   else if (two <= one && two >= three)
   {
      System.out.println(two); 
   }
   else if (two >= one && two <= three)
   {
      System.out.println(two); 
   }
   else if (three <= one && three >= two)
   {
      System.out.println(three); 
   }
   else if (three >= one && three <= two)
   {
      System.out.println(three); 
   }
   
   //Third Number
   
   if (one >= two && one >= three)
   {
      System.out.print(one);   
   }
   else if (two >= one && two >= three)
   {
      System.out.print(two); 
   }
   else if (three >= one && three >= two)
   {
      System.out.print(three); 
   }
      
   }// End of main
}// End of class